#!/bin/bash
# lib/rocky.sh - present Rocky Linux as RHEL to the Rafay controller installer (--rocky / --rocky-restore).
#
# Rafay's preflight-check.sh (and radm) accept only Ubuntu and RHEL. Rocky Linux is binary compatible with RHEL,
# so for the installer we replace the distribution release files with RHEL equivalents of the same version:
#
#   /etc/os-release          Rocky: symlink -> ../usr/lib/os-release    RHEL-looking regular file (ID="rhel")
#   /etc/redhat-release      Rocky: symlink -> rocky-release            "Red Hat Enterprise Linux release X.Y (Name)"
#   /etc/system-release      Rocky: symlink -> rocky-release            symlink -> redhat-release (as on RHEL)
#   /etc/system-release-cpe  Rocky: cpe:/o:rocky:rocky:X::baseos        cpe:/o:redhat:enterprise_linux:X::baseos
#
# Not touched: /usr/lib/os-release and /etc/rocky-release (they stay the record of the real OS, so detection keeps
# working on re-runs) and the RPM database (dnf takes $releasever from the rocky-release package, so the Rocky repos
# and EPEL keep working).
#
# Backups: the originals are copied as-is (symlinks stay symlinks) to $ROCKY_BACKUP_DIR/<path> the first time only.
# A backup is never overwritten, so re-running --rocky cannot replace an original with a disguised copy.
# Restore with ./rafayInstallPrep.sh --rocky-restore, or without backups: sudo dnf reinstall -y rocky-release
#
# Note: a rocky-release package update (dnf update) puts the Rocky files back. Re-apply with --rocky-apply.
#
# Needs: sudo, print_info / print_success / print_error from rafayInstallPrep.sh. Sets LAST_DETAIL for the ledger.

ROCKY_BACKUP_DIR="${ROCKY_BACKUP_DIR:-/var/lib/rafayInstallPrep/rocky-backup}"
ROCKY_FILES=(/etc/os-release /etc/redhat-release /etc/system-release /etc/system-release-cpe)
ROCKY_MARKER_KEY="RAFAY_PREP_DISGUISE"   # last line of the disguised /etc/os-release

# True when the host is really Rocky Linux, whether or not it is disguised
rocky_real_os() {
    [[ -f /etc/rocky-release ]] && return 0
    grep -qsE '^ID="?rocky"?$' /usr/lib/os-release
}

# Real VERSION_ID (e.g. 9.4), read in a subshell so os-release variables don't leak into the script
rocky_version_id() {
    local src
    for src in /usr/lib/os-release "$ROCKY_BACKUP_DIR/etc/os-release.resolved"; do
        [[ -r "$src" ]] && grep -qsE '^ID="?rocky"?$' "$src" && { ( . "$src"; echo "$VERSION_ID" ); return; }
    done
    sed -nE 's/.*release ([0-9]+(\.[0-9]+)?).*/\1/p' /etc/rocky-release 2>/dev/null | head -n1
}

rocky_is_disguised() {
    grep -qs "^${ROCKY_MARKER_KEY}=" /etc/os-release
}

# True if $1 is a file this script wrote (on real Rocky, RHEL content can only come from --rocky)
_rocky_is_ours() {
    case "$1" in
        /etc/os-release)         rocky_is_disguised ;;
        /etc/redhat-release)     [[ ! -L "$1" ]] && grep -qs '^Red Hat Enterprise Linux release' "$1" ;;
        /etc/system-release)     [[ -L "$1" && "$(readlink "$1")" == redhat-release ]] ;;
        /etc/system-release-cpe) grep -qs ':redhat:' "$1" ;;
        *) return 1 ;;
    esac
}

# RHEL release name for a major version
rocky_rhel_codename() {
    case "$1" in
        8) echo "Ootpa" ;;
        9) echo "Plow" ;;
        10) echo "Coughlan" ;;
        *) echo "" ;;
    esac
}

# One line per file: path, what it is now (symlink target or first line), and whether a backup exists
rocky_status() {
    local f b now
    for f in "${ROCKY_FILES[@]}"; do
        b="$ROCKY_BACKUP_DIR$f"
        if [[ -L "$f" ]]; then now="-> $(readlink "$f")"
        elif [[ -f "$f" ]]; then now="$(grep -m1 '^PRETTY_NAME=' "$f" 2>/dev/null || head -n1 "$f" 2>/dev/null)"
        else now="(missing)"; fi
        printf '  %-24s %-55s backup: %s\n' "$f" "$now" "$([[ -e "$b" || -L "$b" ]] && echo yes || echo no)" >&3
    done
}

# Write $2 (content) to $1 atomically: rename(2) replaces a symlink itself, never its target
_rocky_put() {
    local dest="$1" content="$2" tmp
    tmp=$(mktemp) || return 1
    printf '%s\n' "$content" > "$tmp"
    sudo install -m 0644 -o root -g root "$tmp" "$dest.rafay.tmp" && sudo mv -fT "$dest.rafay.tmp" "$dest"
    local rc=$?
    rm -f "$tmp"
    return $rc
}

_rocky_symlink() {   # _rocky_symlink <target> <link>
    sudo ln -sfn "$1" "$2.rafay.tmp" && sudo mv -fT "$2.rafay.tmp" "$2"
}

_rocky_backup() {
    local f b saved=0 kept=0
    sudo mkdir -p "$ROCKY_BACKUP_DIR" || return 1
    sudo chmod 0755 "$ROCKY_BACKUP_DIR"
    for f in "${ROCKY_FILES[@]}"; do
        b="$ROCKY_BACKUP_DIR$f"
        if [[ -e "$b" || -L "$b" ]]; then
            kept=$((kept + 1)); continue            # never overwrite an original
        fi
        [[ -e "$f" || -L "$f" ]] || continue
        if _rocky_is_ours "$f"; then
            print_error "$f is already disguised but has no backup in $ROCKY_BACKUP_DIR; not backing up the disguised copy."
            print_info "The originals can be recreated with: sudo dnf reinstall -y rocky-release (then run --rocky-apply)"
            continue
        fi
        sudo mkdir -p "$(dirname "$b")" || return 1
        sudo cp -a --no-dereference "$f" "$b" || return 1           # as-is (symlink stays a symlink)
        sudo cp -L "$f" "$b.resolved" 2>/dev/null                   # plus the content it pointed to
        saved=$((saved + 1))
    done
    if [[ $saved -gt 0 ]]; then
        sudo tee "$ROCKY_BACKUP_DIR/README" >/dev/null <<EOF
Original Rocky Linux release files, saved by rafayInstallPrep.sh --rocky on $(date -u +%Y-%m-%dT%H:%M:%SZ)
($(hostname), Rocky Linux $(rocky_version_id)).

<path>           the original as-is (symlinks are kept as symlinks)
<path>.resolved  the content it pointed to, for reference

Restore:  ./rafayInstallPrep.sh --rocky-restore
Manual:   for f in ${ROCKY_FILES[*]}; do sudo cp -a --no-dereference $ROCKY_BACKUP_DIR\$f \$f; done
Without these backups:  sudo dnf reinstall -y rocky-release

Original listing:
$(ls -l "${ROCKY_FILES[@]}" 2>&1)
EOF
    fi
    ROCKY_BACKUP_SAVED=$saved
    ROCKY_BACKUP_KEPT=$kept
}

# Replace the release files with RHEL equivalents of the same version (idempotent)
rocky_apply() {
    if ! rocky_real_os; then
        print_error "--rocky: this host is not Rocky Linux (no /etc/rocky-release); nothing changed."
        return 2
    fi
    local ver major name
    ver=$(rocky_version_id)
    major=${ver%%.*}
    name=$(rocky_rhel_codename "$major")
    if [[ -z "$ver" || -z "$name" ]]; then
        print_error "--rocky: unsupported Rocky Linux version '${ver:-unknown}' (expected 8, 9 or 10); nothing changed."
        return 2
    fi
    [[ "$major" == 9 || "$major" == 10 ]] || \
        print_info "Rocky Linux $ver maps to RHEL $major; the Rafay preflight only lists RHEL 9 and 10 as supported."

    _rocky_backup || { print_error "Could not back up the release files to $ROCKY_BACKUP_DIR; nothing changed."; return 2; }

    local pretty="Red Hat Enterprise Linux $ver ($name)"
    # preflight-check.sh reads `grep ^ID=` and an UNANCHORED `grep VERSION_ID` (accepts rhel-9* / rhel-10*):
    # no line other than VERSION_ID= may contain the text "VERSION_ID", or the version comes back as two lines.
    _rocky_put /etc/os-release "NAME=\"Red Hat Enterprise Linux\"
VERSION=\"$ver ($name)\"
ID=\"rhel\"
ID_LIKE=\"fedora\"
VERSION_ID=\"$ver\"
PLATFORM_ID=\"platform:el$major\"
PRETTY_NAME=\"$pretty\"
ANSI_COLOR=\"0;31\"
LOGO=\"fedora-logo-icon\"
CPE_NAME=\"cpe:/o:redhat:enterprise_linux:$major::baseos\"
HOME_URL=\"https://www.redhat.com/\"
DOCUMENTATION_URL=\"https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/$major\"
BUG_REPORT_URL=\"https://issues.redhat.com/\"
REDHAT_BUGZILLA_PRODUCT=\"Red Hat Enterprise Linux $major\"
REDHAT_BUGZILLA_PRODUCT_VERSION=$ver
REDHAT_SUPPORT_PRODUCT=\"Red Hat Enterprise Linux\"
REDHAT_SUPPORT_PRODUCT_VERSION=\"$ver\"
$ROCKY_MARKER_KEY=\"Rocky Linux $ver presented as RHEL by rafayInstallPrep.sh --rocky; originals in $ROCKY_BACKUP_DIR\"" \
        && _rocky_put /etc/redhat-release "Red Hat Enterprise Linux release $ver ($name)" \
        && _rocky_symlink redhat-release /etc/system-release \
        && _rocky_put /etc/system-release-cpe "cpe:/o:redhat:enterprise_linux:$major::baseos" \
        || { print_error "Writing the RHEL release files failed; restore with ./rafayInstallPrep.sh --rocky-restore"; return 2; }
    command -v restorecon >/dev/null 2>&1 && sudo restorecon -F "${ROCKY_FILES[@]}" 2>/dev/null

    rocky_status
    print_info "Backups (${ROCKY_BACKUP_SAVED} new, ${ROCKY_BACKUP_KEPT} already present): $ROCKY_BACKUP_DIR"
    print_info "Undo with ./rafayInstallPrep.sh --rocky-restore. A rocky-release update (dnf update) undoes it too; re-apply with --rocky-apply."
    LAST_DETAIL="Rocky $ver -> \"$pretty\"; backups in $ROCKY_BACKUP_DIR"
    print_success "Rocky Linux $ver now identifies as $pretty"
}

# Put the backed-up originals back
rocky_restore() {
    local f b restored=0 missing=()
    for f in "${ROCKY_FILES[@]}"; do
        b="$ROCKY_BACKUP_DIR$f"
        if [[ -e "$b" || -L "$b" ]]; then
            sudo cp -a --no-dereference "$b" "$f.rafay.tmp" && sudo mv -fT "$f.rafay.tmp" "$f" \
                || { print_error "Restoring $f failed"; return 2; }
            restored=$((restored + 1))
        else
            missing+=("$f")
        fi
    done
    command -v restorecon >/dev/null 2>&1 && sudo restorecon -F "${ROCKY_FILES[@]}" 2>/dev/null
    rocky_status
    if [[ $restored -eq 0 ]]; then
        print_error "No backups in $ROCKY_BACKUP_DIR. Recreate the originals with: sudo dnf reinstall -y rocky-release"
        return 2
    fi
    [[ ${#missing[@]} -eq 0 ]] || print_info "No backup for: ${missing[*]} (left as is)"
    if rocky_is_disguised; then
        print_error "/etc/os-release still identifies as RHEL after the restore."
        return 2
    fi
    LAST_DETAIL="restored $restored file(s) from $ROCKY_BACKUP_DIR"
    print_success "Original Rocky Linux release files restored ($restored); backups kept in $ROCKY_BACKUP_DIR"
}
