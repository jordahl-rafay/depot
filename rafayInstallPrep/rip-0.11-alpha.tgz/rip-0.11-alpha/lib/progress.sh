#!/bin/bash
# Progress display for long-running commands (sourced by rafayInstallPrep.sh).
#
#   run_window [--track FILE] [--pct-output] "Title" command [args...]
#
# Modes (PROGRESS_MODE, from config ui.progress_mode or RAFAY_PROGRESS):
#   window  - header line (spinner, elapsed, %) + the last PROGRESS_LINES lines of output, redrawn in place
#   full    - stream all output to the terminal
#   spinner - header line only
# Output always goes to $LOG_FILE as well. Falls back to "spinner" when fd 3 is not a terminal
# (in that case it prints no live updates, only the final status line).
#
#   --track FILE    show % complete from the read position of whichever process has FILE open
#                   (exact for sequential readers such as pigz/gzip/md5sum)
#   --pct-output    show the last "(NN%)" found in the command output (aria2c summaries)
#
# Returns the command's exit status.

PROGRESS_MODE="${RAFAY_PROGRESS:-${PROGRESS_MODE:-window}}"
PROGRESS_LINES="${PROGRESS_LINES:-6}"

_pw_cols() { local c; c=$( { stty size </dev/tty; } 2>/dev/null | awk '{print $2}'); echo "${c:-100}"; }
_pw_rows() { local r; r=$( { stty size </dev/tty; } 2>/dev/null | awk '{print $1}'); echo "${r:-30}"; }
_pw_fmt_time() { local s=$1; ((s >= 3600)) && printf '%dh%02dm%02ds' $((s/3600)) $((s%3600/60)) $((s%60)) \
    || { ((s >= 60)) && printf '%dm%02ds' $((s/60)) $((s%60)) || printf '%ds' "$s"; }; }

# Percentage of FILE read by any process that has it open (via /proc/<pid>/fdinfo "pos:").
_pw_file_pct() {
    local file=$1 size fd pos best=-1
    size=$(stat -c %s "$file" 2>/dev/null) || return
    ((size > 0)) || return
    for fd in $(find /proc/[0-9]*/fd -maxdepth 1 -lname "$file" 2>/dev/null); do
        pos=$(awk '/^pos:/{print $2}' "${fd/\/fd\//\/fdinfo\/}" 2>/dev/null)
        [[ -n "$pos" ]] && ((pos > best)) && best=$pos
    done
    ((best >= 0)) && echo $((best * 100 / size))
}

# Last N display lines of the output file: \r-progress split into lines, ANSI stripped, truncated to width.
_pw_tail() {
    local out=$1 n=$2 width=$3
    tail -c 16384 "$out" 2>/dev/null | tr '\r' '\n' | sed -e 's/\x1b\[[0-9;?]*[A-Za-z]//g' -e '/^[[:space:]]*$/d' \
        | tail -n "$n" | cut -c1-"$width"
}

run_window() {
    local track="" pct_output=false
    while [[ "$1" == --* ]]; do
        case "$1" in
            --track) track=$(readlink -f "$2" 2>/dev/null || echo "$2"); shift 2 ;;
            --pct-output) pct_output=true; shift ;;
            *) break ;;
        esac
    done
    local title=$1; shift
    local mode=$PROGRESS_MODE
    [[ -t 3 ]] || mode=spinner_quiet

    local out pid rc start spin='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏' i=0 drawn=0 lines width pct elapsed header
    [[ "$(locale charmap 2>/dev/null)" == "UTF-8" ]] || spin='-\|/'
    out=$(mktemp "${TMPDIR:-/tmp}/rafay_progress.XXXXXX")
    start=$(date +%s)
    echo "===== [$title] started $(date) : $* =====" >> "$LOG_FILE"

    if [[ "$mode" == full ]]; then
        printf '\033[1;36m┌ %s\033[0m\n' "$title" >&3
        "$@" 2>&1 | tee -a "$out" >&3
        rc=${PIPESTATUS[0]}
    else
        ( "$@" ) > "$out" 2>&1 &
        pid=$!
        # Ctrl-C: stop the command, restore the cursor, abort the run
        trap 'kill '"$pid"' 2>/dev/null; printf "\033[?25h\n" >&3; echo "Interrupted: '"$title"'" >&3; exit 130' INT TERM
        lines=$PROGRESS_LINES
        (( lines > $(_pw_rows) - 6 )) && lines=$(( $(_pw_rows) - 6 ))
        ((lines < 1)) && lines=1
        [[ "$mode" == window || "$mode" == spinner ]] && printf '\033[?25l' >&3   # hide cursor

        while kill -0 "$pid" 2>/dev/null; do
            if [[ "$mode" == window || "$mode" == spinner ]]; then
                width=$(( $(_pw_cols) - 4 ))
                elapsed=$(( $(date +%s) - start ))
                pct=""
                if [[ -n "$track" ]]; then
                    pct=$(_pw_file_pct "$track")
                elif $pct_output; then
                    pct=$(tail -c 4096 "$out" 2>/dev/null | grep -oE '\([0-9]{1,3}%\)' | tail -1 | tr -d '()%')
                fi
                local label="$title"
                (( ${#label} > width - 20 )) && label="${label:0:width-23}..."   # never wrap the header line
                local ch="${spin:i % ${#spin}:1}"; i=$((i + 1))   # outside $( ) so the counter advances
                header=$(printf '\033[1;33m%s\033[0m \033[1m%s\033[0m \033[2m(%s%s)\033[0m' \
                    "$ch" "$label" "$(_pw_fmt_time "$elapsed")" "${pct:+, ${pct}%}")
                ((drawn > 0)) && printf '\033[%dA' "$drawn" >&3
                printf '\r\033[K%s\n' "$header" >&3
                drawn=1
                if [[ "$mode" == window ]]; then
                    local body n=0
                    body=$(_pw_tail "$out" "$lines" "$width")
                    while IFS= read -r l; do
                        printf '\r\033[K  \033[2m│ %s\033[0m\n' "$l" >&3; n=$((n + 1))
                    done <<< "$body"
                    while ((n < lines)); do printf '\r\033[K  \033[2m│\033[0m\n' >&3; n=$((n + 1)); done
                    drawn=$((lines + 1))
                fi
            fi
            sleep 0.25
        done
        wait "$pid"; rc=$?
        trap - INT TERM
        if ((drawn > 0)); then                       # collapse the window
            printf '\033[%dA' "$drawn" >&3
            for ((n = 0; n < drawn; n++)); do printf '\r\033[K\n' >&3; done
            printf '\033[%dA' "$drawn" >&3
        fi
        [[ "$mode" != spinner_quiet ]] && printf '\033[?25h' >&3
    fi

    elapsed=$(_pw_fmt_time $(( $(date +%s) - start )))
    cat "$out" >> "$LOG_FILE"
    echo "===== [$title] finished rc=$rc after $elapsed =====" >> "$LOG_FILE"
    if [[ "$mode" == spinner_quiet ]]; then          # not a terminal: plain text, no escape codes
        if ((rc == 0)); then echo "  OK   $title ($elapsed)" >&3
        else echo "  FAIL $title (exit $rc, $elapsed). Last output:" >&3
             _pw_tail "$out" 15 200 | sed 's/^/    | /' >&3; echo "    Full output: $LOG_FILE" >&3; fi
    elif ((rc == 0)); then
        printf '  \033[1;32m✔\033[0m %s \033[2m(%s)\033[0m\n' "$title" "$elapsed" >&3
    else
        printf '  \033[1;31m✖ %s failed (exit %d, %s). Last output:\033[0m\n' "$title" "$rc" "$elapsed" >&3
        _pw_tail "$out" 15 "$(( $(_pw_cols) - 6 ))" | sed 's/^/    │ /' >&3
        printf '    \033[2mFull output: %s\033[0m\n' "$LOG_FILE" >&3
    fi
    rm -f "$out"
    return "$rc"
}
