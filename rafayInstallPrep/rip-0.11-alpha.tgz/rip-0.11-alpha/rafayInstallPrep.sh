#!/bin/bash
#
# Script: rafayInstallPrep.sh
# Unified preparation script for Rafay Controller installation on Ubuntu and RHEL.
# Features: JSON-backed configuration, OS auto-detection, Python-powered DNS & Wildcard
# validation, automated drive analysis, idempotent hosts management, and step exclusion.

# --- Configuration Loading ---
CONFIG_FILE="rafay_prep_config.json"
if command -v python3 >/dev/null 2>&1 && [ -f "$CONFIG_FILE" ]; then
    eval "$(python3 -m tools.config_loader --config "$CONFIG_FILE" --export-shell 2>/dev/null)"
fi

# Fallback Defaults (if config file is missing or values are unset)
DEFAULT_TB_URL="${DEFAULT_TB_URL:-https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/3.1/rafay-airgapped-controller-v3.1-38-2.tar.gz}"
DEFAULT_TB_MD5="${DEFAULT_TB_MD5:-a4c248c2ab91e444607cf5d7e2548bbb}"
DEFAULT_RFQDN="${DEFAULT_RFQDN:-rctrl01.rafay.lab}"
DEFAULT_RHOSTNAME="${DEFAULT_RHOSTNAME:-rctrl01}"
DEFAULT_WILDCARD_BASE="${DEFAULT_WILDCARD_BASE:-$DEFAULT_RFQDN}"
DEFAULT_WILDCARD_IP="${DEFAULT_WILDCARD_IP:-}"
DEFAULT_WILDCARD_SCOPE="${DEFAULT_WILDCARD_SCOPE:-auto}"
DEFAULT_NODE_IP="${DEFAULT_NODE_IP:-}"
DATA_DIR="${DEFAULT_DATA_DIR:-rafayInstallPrep}"

# --- Help (printed before logging starts, so it goes straight to the terminal) ---
print_usage() {
    cat <<USAGE
Usage:
  ./rafayInstallPrep.sh [options]                 Prepare this node (interactive, 16 steps)
  ./rafayInstallPrep.sh --validate [opts]         Post-install validation (after reboot); writes a Markdown report + .ansi console copy
  ./rafayInstallPrep.sh --rocky-apply             Only present Rocky Linux as RHEL (what --rocky does after step 1)
  ./rafayInstallPrep.sh --rocky-restore           Put back the Rocky Linux release files saved by --rocky
  ./rafayInstallPrep.sh -h | --help               Show this help

Run as your normal user (not with sudo): privileged commands use sudo internally and you are
asked for your sudo password once. If started with sudo, the script re-launches itself as you.

Prep options:
  -c <CONFIG>    Configuration file (default: $CONFIG_FILE)
  -f <FQDN>      Node FQDN / hostname (default: $DEFAULT_RFQDN)
  -n <HOSTNAME>  Short hostname (default: $DEFAULT_RHOSTNAME)
  -I <NODE_IP>   Node IP for the FQDN in /etc/hosts (default: auto-detect from the default route)
  -w <WILDCARD>  Console/API wildcard base, may differ from the FQDN (default: $DEFAULT_WILDCARD_BASE)
  -i <IP>        Expected wildcard answer (public IP for a public wildcard, internal/LB IP for a private one)
  -s <SCOPE>     Wildcard scope: auto | public | private (default: ${DEFAULT_WILDCARD_SCOPE:-auto})
  -d <DRIVE>     Data drive (auto-detected if omitted)
  -o <OS>        Force OS type (ubuntu, rhel)
  -x <STEPS>     Exclude steps, comma-separated (e.g. 1,2,12)
  -u <URL>       Controller tarball URL
  -m <MD5>       Controller tarball MD5
  --rocky        Rocky Linux only: after step 1, make the host identify as RHEL of the same version for the
                 Rafay preflight and radm (/etc/os-release, redhat-release, system-release, system-release-cpe).
                 Originals are saved as-is to /var/lib/rafayInstallPrep/rocky-backup; undo with --rocky-restore.
                 Re-apply only (e.g. after a rocky-release update): ./rafayInstallPrep.sh --rocky-apply

Progress display for long-running steps (apt/dnf, download, MD5, extraction):
  config ui.progress_mode = window (default: live ${DEFAULT_PROGRESS_LINES:-6}-line output window) | spinner | full
  override per run:  RAFAY_PROGRESS=full ./rafayInstallPrep.sh

Recommended workflow:
  1. ./rafayInstallPrep.sh
  2. sudo reboot
  3. ./rafayInstallPrep.sh --validate        (run again after the radm install for controller checks)

Individual modules (run from this directory; sudo where changes or full reads are needed):
  DNS validator
    sudo python3 -m tools.dns_validator [-f FQDN] [-w WILDCARD] [-n NODE_IP] [-i WILDCARD_IP]
                                        [-s auto|public|private] [--no-fix | --yes]
                                        [--json | --json-out FILE] [--md-out FILE] [-c CONFIG]
  Post-install validator
    sudo python3 -m tools.post_validator [--stage auto|prep|radm] [-o REPORT.md] [--skip-dns]
                                         [-f FQDN] [-w WILDCARD] [-n NODE_IP] [-i WILDCARD_IP] [-s SCOPE]
  radm config.yaml values (what Step 16 sets; comments kept)
    python3 -m tools.radm_config [-c CONFIG] [-f config.yaml] [-a ARCHIVE_DIR] [--dry-run | --check]
  Hostname / hosts manager
    sudo python3 -m tools.config_manager --set-hosts --fqdn FQDN --hostname SHORT [--ip NODE_IP]
                                         [--old-hostname NAME] [--cloud-init] [--dry-run]
  System inspector
    python3 -m tools.system_inspector [--json | --export-shell]
  Storage analyzer
    python3 -m tools.storage_analyzer [--json | --export-shell]
  Config loader
    python3 -m tools.config_loader [-c CONFIG] [--dump-json | --export-shell]
  Host state capture & diff
    sudo python3 -m tools.state_capture capture --label S0 [-f FQDN] [--no-walk]
    python3 -m tools.state_capture diff BEFORE.tar.gz AFTER.tar.gz [-o report.md]
    python3 -m tools.state_capture list

Every module accepts -h for its full option list. Exit codes: 0 = pass, 1 = warnings, 2 = failures.
USAGE
}

for arg in "$@"; do
    case "$arg" in -h|--help) print_usage; exit 0 ;; esac
done

# --- Privileges: run as the normal user; only privileged commands use sudo ---
# Started with sudo? Re-launch as the invoking user so downloads, extracted files and reports stay
# owned by (and writable for) that user. The user's sudo ticket from this invocation is reused below.
if [[ $EUID -eq 0 && -n "${SUDO_USER:-}" && "$SUDO_USER" != "root" && -z "${RAFAY_ALLOW_ROOT:-}" ]]; then
    echo "Re-running as '$SUDO_USER' (privileged commands use sudo; files here stay owned by $SUDO_USER)."
    exec runuser -u "$SUDO_USER" -- env RAFAY_PROGRESS="${RAFAY_PROGRESS:-}" HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)" \
        bash "$0" "$@"
fi

# Give back ownership of paths a previous root run left behind in this directory
ensure_owned() {
    local p
    for p in "$@"; do
        if [[ -e "$p" && ! -O "$p" && $EUID -ne 0 ]]; then
            echo "Taking ownership of $p (left behind by an earlier root run)"
            sudo chown -R "$(id -u):$(id -g)" "$p"
        fi
    done
}

# Ask for the sudo password once (if needed) and keep the credential alive during long steps
if [[ $EUID -ne 0 ]]; then
    if ! command -v sudo >/dev/null 2>&1; then
        echo "sudo is required (run as a user with sudo rights)." >&2; exit 1
    fi
    if ! sudo -n true 2>/dev/null; then
        echo "Some steps need root privileges; enter your sudo password once:"
        sudo -v || { echo "sudo authentication failed." >&2; exit 1; }
    fi
    ( while kill -0 $$ 2>/dev/null; do sudo -n true 2>/dev/null; sleep 50; done ) &
    SUDO_KEEPALIVE_PID=$!
    trap 'kill $SUDO_KEEPALIVE_PID 2>/dev/null' EXIT
fi

# Long options handled by this script (getopts below only knows short ones)
ROCKY_MODE=false
ROCKY_ACTION=""   # apply | restore: standalone, appends to the existing ledger and exits
_args=()
for arg in "$@"; do
    case "$arg" in
        --rocky) ROCKY_MODE=true ;;
        --rocky-apply) ROCKY_ACTION=apply ;;
        --rocky-restore) ROCKY_ACTION=restore ;;
        *) _args+=("$arg") ;;
    esac
done
set -- "${_args[@]}"
unset _args

if [[ "${1:-}" == "--validate" ]]; then
    shift
    # Root is needed to read e.g. /etc/kubernetes/admin.conf; the report is handed back to the user.
    exec sudo python3 -m tools.post_validator --config "$CONFIG_FILE" "$@"
fi

# Data Directory Initialization
ensure_owned "$DATA_DIR"
mkdir -p "$DATA_DIR" || { echo "Cannot create $DATA_DIR in $(pwd)" >&2; exit 1; }
INSTANCE_INFO_DIR="$DATA_DIR/instance.info"
CHANGES_INFO_DIR="$DATA_DIR/changes.info"
LOG_FILE="$DATA_DIR/rafay_install_prep.log"
LEDGER="$CHANGES_INFO_DIR/changes.tsv"

# Change ledger: one TSV line per step (time, step, status, change, detail); read by tools.post_validator
record_change() {
    mkdir -p "$CHANGES_INFO_DIR"
    local action="${3//$'\t'/ }" detail="${4//$'\t'/ }"
    printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$2" "$action" "$detail" >> "$LEDGER"
}

# Initialize Log
echo "--- Rafay Unified Preparation Log started at $(date) ---" > "$LOG_FILE"
exec 3>&1
exec >> "$LOG_FILE" 2>&1

# --- UI Helpers ---
print_header() { echo -e "\n\033[1;34m>>> $1\033[0m" >&3; }
print_success() { echo -e "\033[1;32m✔ $1\033[0m" >&3; }
print_info() { echo -e "\033[1;33mℹ $1\033[0m" >&3; }
print_error() { echo -e "\033[1;31m✖ $1\033[0m" >&3; }

# Long-running commands: live output window / spinner / full output (see lib/progress.sh)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROGRESS_MODE="${RAFAY_PROGRESS:-${DEFAULT_PROGRESS_MODE:-window}}"
PROGRESS_LINES="${DEFAULT_PROGRESS_LINES:-6}"
# shellcheck source=lib/progress.sh
source "$SCRIPT_DIR/lib/progress.sh"
# shellcheck source=lib/rocky.sh
source "$SCRIPT_DIR/lib/rocky.sh"

# --rocky-apply / --rocky-restore: only (un)disguise Rocky Linux, then stop. Appends to the current ledger
# (a full run starts a new one), so --validate keeps the history of the prep run.
if [[ -n "$ROCKY_ACTION" ]]; then
    LAST_DETAIL=""
    if [[ "$ROCKY_ACTION" == apply ]]; then
        print_header "Presenting Rocky Linux as RHEL (--rocky-apply)"
        rocky_apply; rc=$?
        status=$([ $rc -eq 0 ] && echo ok || echo "failed(rc=$rc)")
        title="Present Rocky Linux as RHEL (--rocky-apply)"
    else
        print_header "Restoring the original Rocky Linux release files (--rocky-restore)"
        rocky_restore; rc=$?
        status=$([ $rc -eq 0 ] && echo restored || echo "failed(rc=$rc)")
        title="Restore Rocky Linux release files (--rocky-restore)"
    fi
    record_change R "$status" "$title" "$LAST_DETAIL"
    exit $rc
fi

# Pick the system CA bundle (Ubuntu and RHEL keep it in different places)
ca_bundle() {
    local f
    for f in /etc/ssl/certs/ca-certificates.crt /etc/pki/tls/certs/ca-bundle.crt; do
        [ -f "$f" ] && { echo "$f"; return; }
    done
}

# --- OS Detection ---
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_ID=$ID
        OS_LIKE=$ID_LIKE
    else
        OS_ID="unknown"
    fi

    if [[ "$OS_ID" == "ubuntu" ]]; then
        OS_TYPE="ubuntu"
        PKG_MGR="apt"
    elif [[ "$OS_ID" == "rhel" || "$OS_ID" == "centos" || "$OS_ID" == "rocky" || "$OS_LIKE" == *"rhel"* ]]; then
        OS_TYPE="rhel"
        PKG_MGR="dnf"
    else
        OS_TYPE="unknown"
    fi
}

# --- Fallback Storage Analysis ---
detect_data_drive() {
    ROOT_DISK=$(lsblk -no PKNAME $(findmnt -n -o SOURCE / 2>/dev/null) 2>/dev/null)
    if [ -z "$ROOT_DISK" ]; then
        ROOT_DISK=$(lsblk -no PKNAME $(findmnt -n -o SOURCE /boot 2>/dev/null | head -n1) 2>/dev/null)
    fi
    POTENTIAL_DRIVE=$(lsblk -b -d -n -o NAME,SIZE,TYPE 2>/dev/null | grep disk | grep -v "$ROOT_DISK" | sort -rnk2 | head -n1 | awk '{print $1}')
    if [ -n "$POTENTIAL_DRIVE" ]; then
        DETECTED_DRIVE="/dev/$POTENTIAL_DRIVE"
    else
        DETECTED_DRIVE=""
    fi
}

check_lvm_expansion() {
    CAN_EXPAND_LVM=false
    ROOT_LV=$(findmnt -n -o SOURCE / 2>/dev/null)
    if [[ "$ROOT_LV" == /dev/mapper/* ]]; then
        LV_NAME=$(basename "$ROOT_LV")
        if sudo lvs "$ROOT_LV" >/dev/null 2>&1; then
            VG_NAME=$(sudo lvs --noheadings -o vg_name "$ROOT_LV" 2>/dev/null | xargs)
            FREE_SPACE=$(sudo vgs --noheadings -o vg_free "$VG_NAME" 2>/dev/null | xargs)
            if [[ "$FREE_SPACE" != "0" && -n "$FREE_SPACE" ]]; then
                CAN_EXPAND_LVM=true
                LVM_VG_NAME="$VG_NAME"
                LVM_LV_PATH="$ROOT_LV"
                LVM_FREE_SPACE="$FREE_SPACE"
            fi
        fi
    fi
}

check_selinux() {
    SELINUX_ACTIVE=false
    if command -v getenforce >/dev/null 2>&1; then
        if [[ "$(getenforce)" != "Disabled" ]]; then
            SELINUX_ACTIVE=true
        fi
    fi
}

check_apparmor() {
    APPARMOR_ACTIVE=false
    if [ -f /sys/module/apparmor/parameters/enabled ]; then
        if [[ "$(cat /sys/module/apparmor/parameters/enabled 2>/dev/null)" == "Y" ]]; then
            APPARMOR_ACTIVE=true
        fi
    elif command -v aa-status >/dev/null 2>&1; then
        if sudo aa-status --enabled >/dev/null 2>&1; then
            APPARMOR_ACTIVE=true
        fi
    fi
}

# --- Usage ---
usage() {
    print_usage >&3
    exit 1
}

# --- Argument Parsing ---
EXCLUDED_STEPS=""
detect_os

while getopts "c:u:m:f:n:w:i:I:s:d:o:x:h" opt; do
    case $opt in
        c) CONFIG_FILE="$OPTARG"
           if command -v python3 >/dev/null 2>&1 && [ -f "$CONFIG_FILE" ]; then
               eval "$(python3 -m tools.config_loader --config "$CONFIG_FILE" --export-shell 2>/dev/null)"
           fi
           ;;
        u) TB_URL="$OPTARG" ;;
        m) TB_MD5="$OPTARG" ;;
        f) RFQDN="$OPTARG" ;;
        n) RHOSTNAME="$OPTARG" ;;
        w) WILDCARD_BASE="$OPTARG" ;;
        i) WILDCARD_IP="$OPTARG" ;;
        I) NODE_IP="$OPTARG" ;;
        s) WILDCARD_SCOPE="$OPTARG" ;;
        d) DRIVE="$OPTARG" ;;
        o) OS_TYPE="$OPTARG" ;;
        x) EXCLUDED_STEPS="$OPTARG" ;;
        h) usage ;;
        *) usage ;;
    esac
done

TB_URL="${TB_URL:-$DEFAULT_TB_URL}"
TB_MD5="${TB_MD5:-$DEFAULT_TB_MD5}"
RFQDN="${RFQDN:-$DEFAULT_RFQDN}"
# Kubernetes node names must be RFC 1123 (lowercase alphanumerics, '-' and '.')
if ! [[ "$RFQDN" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$ ]]; then
    print_error "Invalid FQDN '$RFQDN': must be lowercase letters, digits, '-' and '.' (RFC 1123)."
    exit 1
fi
RHOSTNAME="${RHOSTNAME:-$DEFAULT_RHOSTNAME}"
WILDCARD_BASE="${WILDCARD_BASE:-${DEFAULT_WILDCARD_BASE:-$RFQDN}}"
WILDCARD_IP="${WILDCARD_IP:-$DEFAULT_WILDCARD_IP}"
WILDCARD_SCOPE="${WILDCARD_SCOPE:-$DEFAULT_WILDCARD_SCOPE}"
NODE_IP="${NODE_IP:-$DEFAULT_NODE_IP}"

if $ROCKY_MODE && ! rocky_real_os; then
    print_error "--rocky is only for Rocky Linux hosts (no /etc/rocky-release found). Nothing was changed."
    exit 1
fi

# Detect Storage & Drive
if command -v python3 >/dev/null 2>&1; then
    eval "$(python3 -m tools.storage_analyzer --export-shell 2>/dev/null)"
    eval "$(python3 -m tools.system_inspector --export-shell 2>/dev/null)"
else
    detect_data_drive
    check_lvm_expansion
    check_selinux
    check_apparmor
fi

if [ -z "$DRIVE" ]; then
    DRIVE="$DETECTED_DRIVE"
fi

# --- Step Execution Wrapper ---
should_run_step() {
    local step=$1
    if [[ ",$EXCLUDED_STEPS," == *",$step,"* ]]; then
        return 1
    fi
    return 0
}

# --- Analysis Phase ---
if command -v python3 >/dev/null 2>&1; then
    python3 -m tools.system_inspector >&3
    python3 -m tools.storage_analyzer >&3
else
    print_header "System Analysis"
    echo "  Detected OS:     $OS_TYPE" >&3
    echo "  Data Drive:      ${DRIVE:-NOT FOUND}" >&3
    echo "  Rafay FQDN:      $RFQDN" >&3
    echo "  Hostname:        $RHOSTNAME" >&3
    if $CAN_EXPAND_LVM; then
        echo "  LVM Expansion:   Potential found ($LVM_FREE_SPACE free in $LVM_VG_NAME)" >&3
    else
        echo "  LVM Expansion:   None needed or not LVM-based" >&3
    fi

    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        if $APPARMOR_ACTIVE; then
            echo "  AppArmor:        Enabled" >&3
        else
            echo "  AppArmor:        Disabled" >&3
        fi
    elif [[ "$OS_TYPE" == "rhel" ]]; then
        if $SELINUX_ACTIVE; then
            echo "  SELinux:         Enabled ($(getenforce 2>/dev/null))" >&3
        else
            echo "  SELinux:         Disabled" >&3
        fi
    fi
fi

# Management interface / node IP (shown in the step list; re-detected in step 6)
MGMT_DEV=$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}')
MGMT_IP=$([[ -n "$MGMT_DEV" ]] && ip -4 -o addr show dev "$MGMT_DEV" scope global 2>/dev/null | awk '{split($4,a,"/"); print a[1]; exit}')

MOUNT_POINT="${DEFAULT_MOUNT_POINT:-/data}"
if mountpoint -q "$MOUNT_POINT" 2>/dev/null; then
    DISK_STEP_DESC="already mounted at $MOUNT_POINT ($(findmnt -n -o SOURCE "$MOUNT_POINT")); will be skipped"
elif [ -z "$DRIVE" ] && should_run_step 5; then
    print_error "No suitable data drive found and $MOUNT_POINT is not mounted. Specify one with -d <DRIVE> or exclude step 5 (-x 5)."
    exit 1
else
    DISK_STEP_DESC="$DRIVE -> $MOUNT_POINT"
fi

echo -e "\nProposed Steps to Run:" >&3
steps=(
    "1: Update system packages"
    "2: Reset Firewall (install iptables if missing, disable ufw/firewalld, flush iptables)"
    "3: Install prerequisites (bzip2, pigz, aria2c, dnsutils, jq, iSCSI initiator + iscsid) & time sync (if time_sync.enabled)"
    "4: Gather instance info"
    "5: Prepare data disk ($DISK_STEP_DESC)"
    "6: Set Hostname & /etc/hosts ($RFQDN -> ${NODE_IP:-${MGMT_IP:-<undetected>}} on ${MGMT_DEV:-?}; removes old hostname entries)"
    "7: Configure systemd-resolved (Ubuntu: upstream resolv.conf link, DNSSEC=no, Cache=no-negative)"
    "8: Expand Root LVM (if applicable)"
    "9: Disable Security Modules (SELinux + fapolicyd on RHEL / AppArmor on Ubuntu)"
    "10: Disable Swap (mask swap.target) & apply sysctl floors"
    "11: Configure NetworkManager (RHEL dns=none; unmanaged CNI devices when NM is active)"
    "12: Validate DNS & Wildcard Resolution (Local & Remote)"
    "13: Run Rafay Preflight Checks"
    "14: Download Controller Tarball"
    "15: Extract Tarball"
    "16: Finalize Setup (install radm; copy config.yaml and set POC/GAAP/SMTP/archive/partner values)"
)
if $ROCKY_MODE; then   # runs right after step 1, so a rocky-release update there can't undo it
    steps=("${steps[0]}"
           "R: Present Rocky Linux $(rocky_version_id) as RHEL for the Rafay preflight/radm (--rocky; originals saved to $ROCKY_BACKUP_DIR)"
           "${steps[@]:1}")
fi

for s in "${steps[@]}"; do
    num=$(echo $s | cut -d: -f1)
    if should_run_step "$num"; then
        echo "  [RUN] $s" >&3
    else
        echo "  [SKIP] $s" >&3
    fi
done

echo -e "\nDo you want to proceed with these actions? (y/n)" >&3
read -r response <&3
if [[ ! "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
    print_info "Aborting."
    exit 0
fi

# --- Implementation of Steps ---

# dnf is Python: with its output going to a file (the progress window reads one) it block-buffers, so the window
# stays empty until dnf exits. Unbuffered output shows its lines as they happen. (apt-get writes lines directly.)
dnf_run() { sudo PYTHONUNBUFFERED=1 dnf "$@"; }

step_1_packages() {
    print_header "Step 1: Updating system packages"
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        run_window "apt-get update" sudo apt-get update || return 2
        run_window "apt-get upgrade" sudo DEBIAN_FRONTEND=noninteractive apt-get -y \
            -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold upgrade || return 2
    else
        run_window "dnf update" dnf_run update -y || return 2
    fi
    print_success "Packages updated"
}

step_2_firewall() {
    print_header "Step 2: Resetting Firewall"
    local actions=()
    # ufw (required by the Rafay preflight checks): "ufw disable" flushes its rules and sets ENABLED=no in
    # /etc/ufw/ufw.conf; disabling the unit keeps it from loading anything at boot.
    if command -v ufw >/dev/null 2>&1; then
        sudo ufw disable > /dev/null 2>&1 || true
        sudo systemctl disable --now ufw > /dev/null 2>&1 || true
        if sudo ufw status 2>/dev/null | grep -q "Status: inactive"; then
            actions+=("ufw disabled")
        else
            print_error "ufw is still active: $(sudo ufw status 2>/dev/null | head -1)"
            return 1
        fi
    else
        print_info "ufw is not installed; nothing to disable."
        actions+=("ufw not installed")
    fi
    # iptables: the Rafay preflight checks its rules (it skips the check when iptables is missing, as on Rocky
    # minimal images), and the flush below needs it. RHEL/Rocky: iptables-nft (the nftables-backed iptables).
    if ! sudo sh -c 'command -v iptables' >/dev/null 2>&1; then
        if [[ "$OS_TYPE" == "ubuntu" ]]; then
            run_window "apt-get install iptables" sudo DEBIAN_FRONTEND=noninteractive apt-get install -y iptables \
                || { print_error "Could not install iptables"; return 1; }
        else
            run_window "dnf install iptables-nft" dnf_run install -y iptables-nft \
                || { print_error "Could not install iptables-nft"; return 1; }
        fi
        actions+=("iptables installed")
    fi
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        sudo iptables -F
        sudo apt remove -yq iptables-persistent --purge 2>/dev/null || true
        actions+=("iptables flushed" "iptables-persistent removed")
    else
        sudo systemctl stop firewalld 2>/dev/null || true
        sudo systemctl disable firewalld 2>/dev/null || true
        sudo iptables -F
        actions+=("firewalld disabled" "iptables flushed")
    fi
    LAST_DETAIL="${actions[*]}"
    print_success "Firewall reset (${actions[*]})"
}

# Time sync (config time_sync): install + configure chrony when enabled, otherwise skip.
configure_time_sync() {
    if [[ "${TIME_SYNC_ENABLED:-false}" != "true" ]]; then
        print_info "Time sync: disabled in config (time_sync.enabled); skipping."
        TIME_SYNC_DETAIL="time sync skipped (time_sync.enabled=false)"
        return 0
    fi
    local conf svc s
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        run_window "apt-get install chrony" sudo DEBIAN_FRONTEND=noninteractive apt-get install -y chrony || return 1
        conf=/etc/chrony/chrony.conf; svc=chrony
    else
        run_window "dnf install chrony" dnf_run install -y chrony || return 1
        conf=/etc/chrony.conf; svc=chronyd
    fi
    if [[ -n "${TIME_SYNC_SERVERS:-}" ]]; then
        sudo cp -n "$conf" "$conf.rafay-orig"
        # Drop our previous block, comment out the distro's pool/server lines, append the configured servers
        sudo sed -i -E -e '/^# BEGIN rafayInstallPrep/,/^# END rafayInstallPrep/d' \
            -e 's/^(pool|server)[[:space:]]/# [rafayInstallPrep] &/' "$conf"
        {
            echo "# BEGIN rafayInstallPrep (time_sync.servers)"
            for s in $TIME_SYNC_SERVERS; do echo "server $s iburst"; done
            echo "# END rafayInstallPrep"
        } | sudo tee -a "$conf" > /dev/null
    fi
    sudo systemctl disable --now systemd-timesyncd 2>/dev/null || true   # one time daemon only
    sudo systemctl enable "$svc" > /dev/null 2>&1
    sudo systemctl restart "$svc" || return 1
    sudo chronyc -a makestep > /dev/null 2>&1 || true                     # correct a large initial offset now
    if [[ -n "${TIME_SYNC_TIMEZONE:-}" ]]; then
        sudo timedatectl set-timezone "$TIME_SYNC_TIMEZONE" || print_error "Unknown timezone '$TIME_SYNC_TIMEZONE'"
    fi
    TIME_SYNC_DETAIL="chrony ($svc) enabled; servers: ${TIME_SYNC_SERVERS:-distro default}; timezone: ${TIME_SYNC_TIMEZONE:-unchanged}"
    print_success "Time sync configured (chrony; servers: ${TIME_SYNC_SERVERS:-distro default})"
}

step_3_prereqs() {
    print_header "Step 3: Installing prerequisites"
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        run_window "apt-get install bzip2 pigz dnsutils python3 jq open-iscsi" sudo DEBIAN_FRONTEND=noninteractive \
            apt-get install -y bzip2 pigz dnsutils python3 jq open-iscsi || return 2
        # aria2 from apt (universe). The snap is a fallback only: snap confinement stops it writing outside
        # the invoking user's home (e.g. root-run downloads into /home/<user>/...).
        if ! command -v aria2c >/dev/null 2>&1; then
            run_window "apt-get install aria2" sudo DEBIAN_FRONTEND=noninteractive apt-get install -y aria2 \
                || run_window "snap install aria2c (fallback)" sudo snap install aria2c || return 2
        fi
    else
        ARIA_RPM="${ARIA_RPM:-https://github.com/asdo92/aria2-static-builds/releases/download/v1.37.0/aria2-1.37.0-linux-gnu-64bit-build1.rpm}"
        run_window "dnf install epel-release bzip2 pigz bind-utils python3 jq iscsi-initiator-utils" \
            dnf_run install -y epel-release bzip2 pigz bind-utils python3 jq iscsi-initiator-utils || return 2
        run_window "dnf install aria2c" dnf_run install -y "$ARIA_RPM" || return 2
    fi
    print_success "Prerequisites installed"
    # iSCSI initiator: Longhorn (the controller's internal storage) attaches its volumes over iSCSI
    if sudo systemctl enable --now iscsid; then
        print_success "iscsid enabled and running"
    else
        print_error "Could not enable/start iscsid (continuing; see $LOG_FILE)"
    fi
    TIME_SYNC_DETAIL=""
    configure_time_sync || print_error "Time sync configuration failed (continuing; see $LOG_FILE)"
    LAST_DETAIL="${TIME_SYNC_DETAIL:-time sync failed}"
}

step_4_gathering() {
    print_header "Step 4: Gathering instance information"
    mkdir -p "$INSTANCE_INFO_DIR"
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        sudo cat /etc/netplan/*.yaml > "$INSTANCE_INFO_DIR/netplan_config.yaml" 2>/dev/null
    else
        sudo cat /etc/sysconfig/network-scripts/ifcfg-* > "$INSTANCE_INFO_DIR/network_config.txt" 2>/dev/null
        nmcli device show > "$INSTANCE_INFO_DIR/nmcli_show.txt" 2>/dev/null
    fi
    lsblk > "$INSTANCE_INFO_DIR/lsblk.txt"
    sudo gdisk -l "$DRIVE" > "$INSTANCE_INFO_DIR/gdisk_initial.txt" 2>/dev/null
    cat /proc/cpuinfo > "$INSTANCE_INFO_DIR/cpuinfo.txt"
    print_success "Information saved to $INSTANCE_INFO_DIR/"
}

partition_disk() { printf 'label: gpt\n,\n' | sudo sfdisk "$1" && sudo udevadm settle; }

step_5_disk() {
    local mp="$MOUNT_POINT"
    print_header "Step 5: Preparing data disk"
    mkdir -p "$CHANGES_INFO_DIR"

    # 1. Mount point already in use: never repartition or reformat, just record what is there
    if mountpoint -q "$mp" 2>/dev/null; then
        local src fstype
        src=$(findmnt -n -o SOURCE "$mp"); fstype=$(findmnt -n -o FSTYPE "$mp")
        print_info "$mp is already mounted ($src, $fstype); skipping disk preparation."
        if awk -v m="$mp" '$1 !~ /^#/ && $2 == m' /etc/fstab | grep -q .; then
            LAST_DETAIL="already mounted: $src ($fstype) at $mp; fstab entry present"
        else
            print_error "$mp has no /etc/fstab entry and will not be mounted after a reboot."
            LAST_DETAIL="already mounted: $src ($fstype) at $mp; WARNING: no fstab entry"
        fi
        LAST_STATUS=already-configured   # still validated by tools.post_validator
        cat /etc/fstab > "$CHANGES_INFO_DIR/fstab.txt"
        findmnt "$mp" > "$CHANGES_INFO_DIR/mount_data.txt"
        return 0
    fi

    if [ -z "$DRIVE" ]; then
        print_error "No data drive found and $mp is not mounted. Specify one with -d <DRIVE> (or exclude step 5 with -x 5)."
        return 2
    fi

    # 2. Refuse to touch a drive that is mounted anywhere
    local mounted
    mounted=$(lsblk -nrpo NAME,MOUNTPOINT "$DRIVE" 2>/dev/null | awk 'NF > 1 {print $1 " -> " $2}')
    if [[ -n "$mounted" ]]; then
        print_error "$DRIVE is in use (${mounted//$'\n'/, }); refusing to repartition it."
        return 2
    fi

    # 3. Existing partitions / filesystem signatures: explicit confirmation before destroying data
    if lsblk -nrpo NAME,FSTYPE "$DRIVE" 2>/dev/null | awk 'NR > 1 || $2 != "" {found=1} END {exit !found}'; then
        print_info "$DRIVE already contains partitions or a filesystem:"
        lsblk -o NAME,SIZE,FSTYPE,LABEL,UUID "$DRIVE" >&3
        echo -e "\n\033[1;31mALL DATA on $DRIVE will be destroyed.\033[0m Type the device name ($DRIVE) to continue, anything else to skip:" >&3
        local answer
        read -r answer <&3
        if [[ "$answer" != "$DRIVE" ]]; then
            print_info "Skipping disk preparation (not confirmed)."
            LAST_STATUS=skipped
            LAST_DETAIL="declined to wipe $DRIVE"
            return 0
        fi
        run_window "wipefs $DRIVE" sudo wipefs -a "$DRIVE" || return 2
    fi

    # 4. Partition, format, mount by UUID
    run_window "Partition $DRIVE (GPT, single partition)" partition_disk "$DRIVE" || return 2
    PARTITION=$(lsblk -nrpo NAME,TYPE "$DRIVE" | awk '$2 == "part" {print $1; exit}')
    [[ -n "$PARTITION" ]] || { print_error "No partition found on $DRIVE after partitioning."; return 2; }
    run_window "mkfs.ext4 $PARTITION" sudo mkfs.ext4 -F "$PARTITION" || return 2

    sudo cp -n /etc/fstab /etc/fstab.orig 2>/dev/null || true
    sudo mkdir -p "$mp"
    DISK_UUID=$(sudo blkid -s UUID -o value "$PARTITION")
    [[ -n "$DISK_UUID" ]] || { print_error "Could not read the UUID of $PARTITION."; return 2; }
    # Comment out older entries for this mount point so re-runs never stack duplicate lines
    sudo sed -i -E "\#^[^\#[:space:]]+[[:space:]]+${mp}[[:space:]]#s|^|# [rafayInstallPrep] replaced: |" /etc/fstab
    echo -e "UUID=$DISK_UUID\t$mp\text4\tdefaults\t0 0" | sudo tee -a /etc/fstab > /dev/null
    sudo systemctl daemon-reload
    sudo mount "$mp" || { print_error "Mounting $mp failed."; return 2; }

    cat /etc/fstab > "$CHANGES_INFO_DIR/fstab.txt"
    findmnt "$mp" > "$CHANGES_INFO_DIR/mount_data.txt"
    sudo gdisk -l "$DRIVE" > "$CHANGES_INFO_DIR/gdisk_final.txt" 2>/dev/null
    LAST_DETAIL="formatted $PARTITION (UUID=$DISK_UUID) mounted at $mp"
    print_success "Data disk $PARTITION formatted and mounted at $mp"
}

# Management interface = the interface carrying the default route; the node IP is its primary global IPv4.
# Sets MGMT_DEV / MGMT_IP. Never returns loopback (127.x, e.g. Ubuntu's 127.0.1.1 hostname line) or link-local.
detect_management_ip() {
    MGMT_DEV=$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}')
    MGMT_IP=""
    [[ -n "$MGMT_DEV" ]] && MGMT_IP=$(ip -4 -o addr show dev "$MGMT_DEV" scope global 2>/dev/null \
        | awk '{split($4, a, "/"); print a[1]; exit}')
    if [[ -z "$MGMT_IP" ]]; then
        # No default route: use the source address the kernel picks toward the cloud metadata / DNS service
        read -r MGMT_IP MGMT_DEV < <(ip -4 route get 169.254.169.254 2>/dev/null \
            | awk '{for(i=1;i<NF;i++){if($i=="src")s=$(i+1); if($i=="dev")d=$(i+1)}} END{print s, d}')
    fi
    [[ "$MGMT_IP" =~ ^(127\.|169\.254\.) ]] && MGMT_IP=""
}

# True if $1 is a global (non-loopback, non-link-local) IPv4 address assigned to this host
is_local_global_ip() {
    [[ -n "$1" && ! "$1" =~ ^(127\.|169\.254\.) ]] && ip -4 -o addr show scope global 2>/dev/null | grep -q " inet $1/"
}

step_6_hostname() {
    print_header "Step 6: Configuring Hostname & /etc/hosts"
    local old_hostname ip
    old_hostname="$(hostname)"   # captured before the change so its /etc/hosts entries can be removed
    detect_management_ip
    if [[ -n "$NODE_IP" ]]; then
        is_local_global_ip "$NODE_IP" || { print_error "Configured node IP $NODE_IP is not a global address on this host."; return 2; }
        ip="$NODE_IP"
    else
        ip="$MGMT_IP"
        [[ -n "$ip" ]] || { print_error "Could not determine the management interface address (no default route?). Pass -I <NODE_IP>."; return 2; }
    fi
    print_info "Node IP: $ip (${NODE_IP:+configured; }management interface ${MGMT_DEV:-unknown})"
    if command -v python3 >/dev/null 2>&1; then
        # Removes entries for the old hostname / FQDN / short name, maps FQDN -> node IP,
        # and stops cloud-init from resetting the hostname or /etc/hosts at boot.
        if ! sudo python3 -m tools.config_manager --set-hosts --cloud-init --fqdn "$RFQDN" --hostname "$RHOSTNAME" \
                ${ip:+--ip "$ip"} --old-hostname "$old_hostname" >&3; then
            print_error "Failed to update /etc/hosts"
            return 1
        fi
    else
        sudo cp -n /etc/hosts /etc/hosts.orig 2>/dev/null || true
        local name
        for name in "$old_hostname" "$RFQDN" "$RHOSTNAME"; do
            [[ -z "$name" || "$name" == localhost* ]] && continue
            sudo sed -i -E "/^[^#]*[[:space:]]${name//./\\.}([[:space:]]|$)/d" /etc/hosts
        done
        echo -e "$ip\t$RFQDN\t$RHOSTNAME" | sudo tee -a /etc/hosts
    fi
    sudo hostnamectl set-hostname "$RFQDN"
    mkdir -p "$CHANGES_INFO_DIR"
    cat /etc/hosts > "$CHANGES_INFO_DIR/hosts.txt"
    echo "Hostname: $(hostname)" > "$CHANGES_INFO_DIR/hostname.txt"
    local hi
    hi="$(hostname -i 2>/dev/null)"
    LAST_DETAIL="old=$old_hostname new=$RFQDN ip=$ip hostname-i=${hi// /,}"
    if [[ "$hi" != "$ip" ]]; then
        print_error "hostname -i returns '$hi', expected '$ip' (radm's reboot scripts depend on it)"
        return 1
    fi
    print_success "Hostname set to $RFQDN ($ip)"
}

step_7_resolved() {
    if [[ "$OS_TYPE" == "ubuntu" ]]; then
        print_header "Step 7: Configuring systemd-resolved"
        # Link to the upstream (non-stub) file: pods/CoreDNS inherit the node's resolv.conf
        # and cannot reach the 127.0.0.53 stub listener from their network namespaces.
        sudo systemctl enable --now systemd-resolved 2>/dev/null || true
        sudo rm -f /etc/resolv.conf
        sudo ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf
        # No DNSSEC validation (private zones / stripped
        # records), and never cache NXDOMAIN so DNS records added mid-install resolve immediately.
        # DNS= is left to radm (it points resolved at its Consul DNS).
        sudo mkdir -p /etc/systemd/resolved.conf.d
        printf '%s\n' "# Generated by rafayInstallPrep: resolver settings for Kubernetes nodes" \
            "[Resolve]" "DNSSEC=no" "Cache=no-negative" \
            | sudo tee /etc/systemd/resolved.conf.d/90-rafay.conf > /dev/null
        sudo systemctl restart systemd-resolved
        ls -l /etc/resolv.conf > "$CHANGES_INFO_DIR/resolv_conf_link.txt" 2>/dev/null
        LAST_DETAIL="/etc/resolv.conf -> /run/systemd/resolve/resolv.conf; resolved.conf.d/90-rafay.conf (DNSSEC=no, Cache=no-negative)"
        print_success "systemd-resolved configured (upstream link, DNSSEC=no, Cache=no-negative)"
    fi
}

step_8_expand_lvm() {
    if $CAN_EXPAND_LVM; then
        print_header "Step 8: Expanding Root LVM"
        run_window "lvextend $LVM_LV_PATH (+100%FREE)" sudo lvextend -l +100%FREE "$LVM_LV_PATH" \
            || { print_error "LVM expansion failed"; return 1; }
        if [[ $(findmnt -n -o FSTYPE /) == "xfs" ]]; then
            run_window "xfs_growfs /" sudo xfs_growfs /
        else
            run_window "resize2fs $LVM_LV_PATH" sudo resize2fs "$LVM_LV_PATH"
        fi && print_success "Root LVM expanded" || { print_error "Filesystem resize failed"; return 1; }
    fi
}

step_9_selinux() {
    print_header "Step 9: Disabling SELinux"
    if command -v getenforce >/dev/null 2>&1; then
        if [[ "$(getenforce)" != "Disabled" ]]; then
            print_info "Setting SELinux to permissive mode..."
            sudo setenforce 0
            print_info "Disabling SELinux permanently in /etc/selinux/config..."
            sudo sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config
            print_success "SELinux disabled (reboot required for full effect)"
        else
            print_success "SELinux is already disabled"
        fi
    fi
}

step_9_apparmor() {
    print_header "Step 9: Disabling AppArmor"
    local grub_d="/etc/default/grub.d"
    local cfg_file="$grub_d/99-disable-apparmor.cfg"
    local needs_grub_update=false

    if [ ! -f "$cfg_file" ] || ! grep -q 'apparmor=0' "$cfg_file"; then
        needs_grub_update=true
    fi

    if $APPARMOR_ACTIVE || systemctl is-active --quiet apparmor 2>/dev/null || $needs_grub_update; then
        print_info "Stopping and disabling AppArmor service..."
        sudo systemctl stop apparmor 2>/dev/null || true
        sudo systemctl disable apparmor 2>/dev/null || true

        if command -v aa-teardown >/dev/null 2>&1; then
            print_info "Tearing down AppArmor profiles..."
            sudo aa-teardown 2>/dev/null || true
        fi

        if $needs_grub_update; then
            print_info "Configuring GRUB drop-in ($cfg_file)..."
            sudo mkdir -p "$grub_d"
            cat << 'EOF' | sudo tee "$cfg_file" > /dev/null
# ==============================================================================
# RAFAY CONTROLLER - APPARMOR KERNEL DISABLEMENT
# Generated by: rafayInstallPrep
#
# PURPOSE:
# Rafay air-gapped controller preflight checks require AppArmor to be disabled
# at the kernel runtime level (preventing container runtime permission conflicts).
#
# Cloud images (such as Ubuntu 24.04 OCI/AWS/Azure) override /etc/default/grub
# via /etc/default/grub.d/50-cloudimg-settings.cfg. This file is sorted as '99-'
# to guarantee it evaluates last and persistently appends 'apparmor=0'.
# ==============================================================================
GRUB_CMDLINE_LINUX="$GRUB_CMDLINE_LINUX apparmor=0"
EOF

            print_info "Updating GRUB bootloader..."
            run_window "update-grub" sudo update-grub || return 1
        else
            print_info "GRUB drop-in $cfg_file already present."
        fi

        mkdir -p "$CHANGES_INFO_DIR"
        echo "AppArmor service disabled, $cfg_file configured with apparmor=0" > "$CHANGES_INFO_DIR/apparmor_disabled.txt"
        print_success "AppArmor disabled (reboot required for full effect)"
    else
        print_success "AppArmor is already disabled"
    fi
}

step_9_security() {
    if [[ "$OS_TYPE" == "rhel" ]]; then
        step_9_selinux
        # fapolicyd blocks CNI plugin binaries from executing
        if systemctl list-unit-files fapolicyd.service >/dev/null 2>&1 && \
           systemctl cat fapolicyd.service >/dev/null 2>&1; then
            sudo systemctl disable --now fapolicyd 2>/dev/null && print_success "fapolicyd stopped and disabled"
            LAST_DETAIL="SELinux disabled; fapolicyd disabled"
        fi
    elif [[ "$OS_TYPE" == "ubuntu" ]]; then
        step_9_apparmor
    fi
}

# Raise-only sysctl floors from config host_tuning.sysctl_floors
SYSCTL_FLOORS_FILE=/etc/sysctl.d/90-rafay-sysctl-floors.conf
apply_sysctl_floors() {
    local tmp kv key want cur changed=()
    ((${#SYSCTL_FLOORS[@]})) || { print_info "No sysctl floors configured."; return 0; }
    tmp=$(mktemp)
    {
        echo "# Generated by rafayInstallPrep: kernel parameter floors for Kubernetes nodes."
        echo "# Raise-only: a key is listed only when the running value was below the floor."
        echo "# Keys radm manages itself (inotify, fs.file-max, nf_conntrack_max) are not set here."
    } > "$tmp"
    for kv in "${SYSCTL_FLOORS[@]}"; do
        key=${kv%%=*}; want=${kv#*=}
        cur=$(sysctl -n "$key" 2>/dev/null) || { echo "# $key: not available on this kernel" >> "$tmp"; continue; }
        # Keep a floor this file set on an earlier run (otherwise a re-run would drop it)
        if (( cur < want )) || grep -qE "^${key//./\\.} = ${want}$" "$SYSCTL_FLOORS_FILE" 2>/dev/null; then
            echo "$key = $want" >> "$tmp"
            (( cur < want )) && changed+=("$key $cur->$want")
        else
            echo "# $key: current $cur >= floor $want (unchanged)" >> "$tmp"
        fi
    done
    sudo install -m 0644 "$tmp" "$SYSCTL_FLOORS_FILE" && rm -f "$tmp"
    # Remove floors files written under earlier names
    local old
    for old in /etc/sysctl.d/90-rafay-*floors.conf; do
        [[ -e "$old" && "$old" != "$SYSCTL_FLOORS_FILE" ]] && sudo rm -f "$old"
    done
    sudo sysctl -p "$SYSCTL_FLOORS_FILE" > /dev/null
    print_info "sysctl floors: ${#changed[@]} raised${changed:+ (${changed[*]})}"
    FLOORS_DETAIL="floors raised: ${changed[*]:-none}"
}

step_10_disable_swap() {
    print_header "Step 10: Disabling Swap & Applying Kernel Floors"
    print_info "Turning off swap..."
    sudo swapoff -a
    # Comment out only active swap entries (3rd field = swap), never comments or unrelated lines
    sudo sed -i -E 's|^([^#[:space:]]+[[:space:]]+[^[:space:]]+[[:space:]]+swap[[:space:]].*)$|# [rafayInstallPrep] \1|' /etc/fstab
    # Mask swap.target so systemd cannot re-activate swap units, zram or
    # GPT auto-discovered swap at boot
    sudo systemctl mask swap.target > /dev/null 2>&1
    apply_sysctl_floors
    LAST_DETAIL="swapoff; fstab swap entries commented; swap.target masked; ${FLOORS_DETAIL:-}"
    print_success "Swap disabled (swap.target masked)"
}

step_11_nm_dns_none() {
    local did=()
    if [[ "$OS_TYPE" == "rhel" ]]; then
        print_header "Step 11: Configuring NetworkManager"
        print_info "Writing /etc/NetworkManager/conf.d/90-dns-none.conf..."
        echo -e "[main]\ndns=none" | sudo tee /etc/NetworkManager/conf.d/90-dns-none.conf > /dev/null
        did+=("dns=none")
    fi
    # Keep NetworkManager away from CNI / kube-proxy interfaces
    if systemctl is-active --quiet NetworkManager 2>/dev/null && [[ -n "${NM_UNMANAGED_DEVICES:-}" ]]; then
        [[ ${#did[@]} -eq 0 ]] && print_header "Step 11: Configuring NetworkManager"
        printf '%s\n' "# Generated by rafayInstallPrep: CNI / kube-proxy interfaces are not managed by NetworkManager" \
            "[keyfile]" "unmanaged-devices+=$NM_UNMANAGED_DEVICES" \
            | sudo tee /etc/NetworkManager/conf.d/90-rafay-k8s-unmanaged.conf > /dev/null
        did+=("unmanaged-devices")
    fi
    if ((${#did[@]})); then
        print_info "Reloading NetworkManager..."
        sudo systemctl reload NetworkManager
        LAST_DETAIL="NetworkManager: ${did[*]}"
        print_success "NetworkManager configured (${did[*]})"
    else
        LAST_STATUS=not-applicable
        LAST_DETAIL="NetworkManager not active"
    fi
}

step_12_dns_validation() {
    print_header "Step 12: Validating DNS & Wildcard Resolution (Kubernetes Best Practice)"
    mkdir -p "$CHANGES_INFO_DIR"
    if command -v python3 >/dev/null 2>&1; then
        local json_report="$CHANGES_INFO_DIR/dns_validation.json"
        
        # The validator owns all DNS output: report, remediation plan (local fixes +
        # external actions), fix prompt, re-validation, and final verdict.
        sudo python3 -m tools.dns_validator \
            --config "$CONFIG_FILE" \
            --fqdn "$RFQDN" \
            --wildcard-base "$WILDCARD_BASE" \
            ${NODE_IP:+--node-ip "$NODE_IP"} \
            ${WILDCARD_IP:+--wildcard-ip "$WILDCARD_IP"} \
            --wildcard-scope "$WILDCARD_SCOPE" \
            --json-out "$json_report" \
            --md-out "$CHANGES_INFO_DIR/dns_validation.md" <&3 >&3

        if [ $? -eq 2 ]; then
            echo -e "\nDo you want to proceed with the installation anyway? (y/n)" >&3
            read -r response <&3
            if [[ ! "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
                print_info "Aborting installation to allow DNS resolution to be corrected."
                exit 1
            fi
        fi
    else
        print_info "Python 3 not detected; skipping deep DNS validation suite."
    fi
}

# --rocky: make the release files read as RHEL (lib/rocky.sh). Runs after step 1 and stays in place for radm.
step_rocky_disguise() {
    print_header "Step R: Presenting Rocky Linux as RHEL (--rocky)"
    rocky_apply
}

step_13_preflight() {
    print_header "Step 13: Running Rafay Preflight Checks"
    PREFLIGHT_URL="${PREFLIGHT_URL:-https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/Publish/preflight-check.sh}"
    curl -sSL "$PREFLIGHT_URL" | sudo bash | tee "$CHANGES_INFO_DIR/preflight_check.txt" | tee /dev/fd/3
    print_info "Preflight report saved to $CHANGES_INFO_DIR/preflight_check.txt"
    echo -e "\nPress any key to continue with download..." >&3
    read -n 1 -s <&3
}

md5sum_to() { md5sum "$1" > "$2"; }

step_14_download() {
    print_header "Step 14: Downloading Controller Tarball"
    FNAME=$(basename "$TB_URL")
    ensure_owned "$FNAME" "$FNAME.aria2"
    local ca; ca=$(ca_bundle)
    # --summary-interval makes aria2c print "(NN%)" progress lines when not attached to a terminal
    run_window --pct-output "Download $FNAME" aria2c ${ca:+--ca-certificate="$ca"} -x 16 \
        --summary-interval=2 --console-log-level=warn --enable-color=false "$TB_URL" \
        || { print_error "Download failed"; return 2; }
    run_window --track "$FNAME" "Verify MD5 of $FNAME" md5sum_to "$FNAME" "$DATA_DIR/tarball.md5" \
        || { print_error "MD5 calculation failed"; return 2; }
    ACTUAL_MD5=$(awk '{print $1}' "$DATA_DIR/tarball.md5")
    if [ "$ACTUAL_MD5" != "$TB_MD5" ]; then
        print_error "MD5 mismatch! Expected: $TB_MD5, Actual: $ACTUAL_MD5"
        return 2
    fi
    LAST_DETAIL="file=$FNAME md5=$ACTUAL_MD5 expected=$TB_MD5"
    print_success "Download verified"
}

# Top-level directory stored in the tarball (empty if its entries are not under a single directory).
# Reads only the first entry, so it returns immediately even for multi-GB archives.
tarball_dir() {
    local first
    first=$(tar -I pigz -tf "$1" 2>/dev/null | awk 'NF && $0 != "./" {print; exit}')
    first=${first#./}
    [[ "$first" == */* ]] && echo "${first%%/*}"
}

# Directory the controller was extracted to (recorded by step 15; recomputed if needed)
extract_dir() {
    local f="$DATA_DIR/extract_dir" fname dir
    [[ -s "$f" ]] && { cat "$f"; return; }
    fname=$(basename "$TB_URL")
    [[ -f "$fname" ]] && dir=$(tarball_dir "$fname")
    echo "${dir:-${fname%.tar.gz}}"
}

step_15_extract() {
    print_header "Step 15: Extracting Tarball"
    local dir
    FNAME=$(basename "$TB_URL")
    [[ -f "$FNAME" ]] || { print_error "$FNAME not found (run step 14 first)."; return 2; }
    dir=$(tarball_dir "$FNAME")
    if [[ -n "$dir" ]]; then
        # Extract with the archive's own directory name
        ensure_owned "$dir"
        # Progress = pigz's read position in the tarball (exact, from /proc/<pid>/fdinfo)
        run_window --track "$FNAME" "Extract $FNAME -> ./$dir" tar -I pigz -xvf "$FNAME" \
            || { print_error "Extraction failed"; return 2; }
    else
        # Entries are not under one directory: keep them together in a directory named after the tarball
        dir="${FNAME%.tar.gz}"
        ensure_owned "$dir"
        mkdir -p "$dir"
        run_window --track "$FNAME" "Extract $FNAME -> ./$dir" tar -I pigz -xvf "$FNAME" -C "./$dir" \
            || { print_error "Extraction failed"; return 2; }
    fi
    [[ -d "$dir" ]] || { print_error "Expected directory ./$dir after extraction."; return 2; }
    echo "$dir" > "$DATA_DIR/extract_dir"
    LAST_DETAIL="extracted to ./$dir"
    print_success "Extraction complete: ./$dir"
}

step_16_finalize() {
    print_header "Step 16: Finalizing Setup"
    local dir
    dir=$(extract_dir)
    ensure_owned ./config.yaml
    cp "./$dir/config.yaml-airgap-tmpl" ./config.yaml 2>/dev/null || true
    sudo mv "./$dir/radm" /usr/bin/ 2>/dev/null || true
    print_success "radm binary moved to /usr/bin/"
    LAST_DETAIL="controller directory ./$dir"
    # Fill in the site values (POC size, GAAP, SMTP sink, archive directory, partner/star-domain); comments kept
    local archive changes
    archive="$(cd "./$dir" 2>/dev/null && pwd)"
    if [[ ! -f ./config.yaml ]]; then
        print_error "./config.yaml not found ($dir/config.yaml-airgap-tmpl missing?); values not set."
        return 1
    fi
    # Exit codes: 0 set; 3 set, but the file has lint problems; other = not written (e.g. a value radm rejects)
    local rc=0
    changes=$(python3 -m tools.radm_config --config "$CONFIG_FILE" --file ./config.yaml \
              --archive-dir "${archive:-$(pwd)/$dir}" 2>&1) || rc=$?
    echo "$changes"
    case $rc in
        0)  print_success "config.yaml values set: $(tail -1 <<<"$changes")"
            LAST_DETAIL+="; config.yaml: $(tail -1 <<<"$changes")" ;;
        3)  print_error "config.yaml values set, but the file has problems radm may reject:"
            grep '^config.yaml lint:' <<<"$changes" | sed 's/^config.yaml lint: /    /' >&3
            LAST_DETAIL+="; config.yaml set with lint problems"
            return 1 ;;
        *)  print_error "config.yaml not updated (fix rafay_prep_config.json, then re-run step 16):"
            grep '^config.yaml not updated:' <<<"$changes" | sed 's/^config.yaml not updated: /    /' >&3
            LAST_DETAIL+="; config.yaml values not set"
            return 1 ;;
    esac
}

# --- Execution ---
# Each step is recorded in the change ledger ($LEDGER) for tools.post_validator.
declare -A STEP_TITLES
for s in "${steps[@]}"; do STEP_TITLES["${s%%:*}"]="${s#*: }"; done

run_step() {
    local num=$1 fn=$2 rc
    if ! should_run_step "$num"; then
        record_change "$num" skipped "${STEP_TITLES[$num]}" "excluded with -x"
        return 0
    fi
    LAST_DETAIL=""
    LAST_STATUS=""
    "$fn"
    rc=$?
    record_change "$num" "$([ $rc -eq 0 ] && echo "${LAST_STATUS:-ok}" || echo "failed(rc=$rc)")" "${STEP_TITLES[$num]}" "$LAST_DETAIL"
    if [ $rc -eq 2 ]; then   # fatal: later steps depend on this one
        print_error "Step $num failed; stopping. Details: $LOG_FILE (ledger: $LEDGER)"
        exit 1
    fi
}

# Start a fresh ledger for this run (previous runs are kept with a timestamp suffix)
[ -f "$LEDGER" ] && mv "$LEDGER" "$LEDGER.$(date -u +%Y%m%dT%H%M%SZ)"

run_step 1 step_1_packages
$ROCKY_MODE && run_step R step_rocky_disguise
run_step 2 step_2_firewall
run_step 3 step_3_prereqs
run_step 4 step_4_gathering
run_step 5 step_5_disk
run_step 6 step_6_hostname
run_step 7 step_7_resolved
run_step 8 step_8_expand_lvm
run_step 9 step_9_security
run_step 10 step_10_disable_swap
run_step 11 step_11_nm_dns_none
run_step 12 step_12_dns_validation
run_step 13 step_13_preflight
run_step 14 step_14_download
run_step 15 step_15_extract
run_step 16 step_16_finalize

print_header "Preparation Complete"
print_info "Review ./config.yaml (Step 16 set size, GAAP, SMTP, archive directory and partner values) before running radm."
print_info "Please upload your logo to the path contained in your config.yaml."
print_info "Change ledger: $LEDGER"
print_info "Next: reboot, then run './rafayInstallPrep.sh --validate' for the post-install report."
print_info "Reboot recommended. Reboot now? (y/n)"
read -r response <&3
[[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]] && sudo reboot
