"""Audits /etc/resolv.conf and system resolver configuration for Kubernetes compliance."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional
import ipaddress
import re
import socket

from tools.common.reporter import CheckSection, CheckItem


@dataclass
class ResolvConfParsed:
    path: Path
    nameservers: List[str] = field(default_factory=list)
    search_domains: List[str] = field(default_factory=list)
    options: List[str] = field(default_factory=list)
    raw_lines: List[str] = field(default_factory=list)


def parse_resolv_conf(path: Path = Path("/etc/resolv.conf")) -> ResolvConfParsed:
    """Parse /etc/resolv.conf into structured lists."""
    parsed = ResolvConfParsed(path=path)
    if not path.is_file():
        return parsed

    try:
        content = path.read_text(encoding="utf-8")
    except Exception:
        return parsed

    for line in content.splitlines():
        parsed.raw_lines.append(line)
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";")):
            continue

        parts = stripped.split()
        keyword = parts[0].lower()
        args = parts[1:]

        if keyword == "nameserver" and args:
            parsed.nameservers.append(args[0])
        elif keyword in ("search", "domain") and args:
            parsed.search_domains.extend(args)
        elif keyword == "options" and args:
            parsed.options.extend(args)

    return parsed


def audit_resolver_config(
    section: CheckSection,
    resolv_conf_path: Path = Path("/etc/resolv.conf"),
    max_nameservers: int = 3,
    max_search_domains: int = 3,
    wildcard_base: Optional[str] = None,
) -> ResolvConfParsed:
    """Audit resolver configuration against Kubernetes & glibc best practices."""
    parsed = parse_resolv_conf(resolv_conf_path)

    # 1. Nameserver Count Check
    ns_count = len(parsed.nameservers)
    if ns_count == 0:
        section.add(
            CheckItem(
                name="Nameserver Configuration",
                status="FAIL",
                detail="No nameservers found in /etc/resolv.conf.",
                expected="At least 1 valid upstream nameserver",
                actual="0 nameservers",
                why="DNS resolution is impossible without at least one nameserver defined.",
                metadata={"issue": "resolv.no_nameservers", "path": str(resolv_conf_path)},
            )
        )
    elif ns_count > max_nameservers:
        section.add(
            CheckItem(
                name="Nameserver Cap (glibc Limit)",
                status="WARN",
                detail=f"Found {ns_count} nameservers. glibc only queries the first {max_nameservers}.",
                expected=f"<= {max_nameservers} nameservers",
                actual=f"{ns_count} nameservers {parsed.nameservers}",
                why="Linux glibc silently ignores all nameservers beyond the 3rd. Extra entries can cause unpredictable failover behaviors.",
                metadata={
                    "issue": "resolv.too_many_nameservers",
                    "path": str(resolv_conf_path),
                    "nameservers": parsed.nameservers,
                    "limit": max_nameservers,
                },
            )
        )
    else:
        section.add(
            CheckItem(
                name="Nameserver Cap (glibc Limit)",
                status="PASS",
                detail=f"{ns_count} nameserver(s) configured: {parsed.nameservers}",
                expected=f"<= {max_nameservers} nameservers",
                actual=f"{ns_count} nameservers",
                why="Complies with the 3-nameserver limit enforced by the glibc resolver.",
            )
        )

    # 2. Search Domain Budget Check
    sd_count = len(parsed.search_domains)
    total_sd_chars = sum(len(d) + 1 for d in parsed.search_domains)
    if sd_count > max_search_domains:
        section.add(
            CheckItem(
                name="Kubernetes Search Domain Budget",
                status="WARN",
                detail=f"Found {sd_count} host search domains. Pods may exceed glibc's 6-domain cap.",
                expected=f"<= {max_search_domains} search domains",
                actual=f"{sd_count} domains {parsed.search_domains}",
                why="Kubernetes injects 3 cluster search domains into every pod. Total domains cannot exceed 6, and excess domains cause severe ndots:5 latency degradation.",
                metadata={
                    "issue": "resolv.too_many_search",
                    "path": str(resolv_conf_path),
                    "search_domains": parsed.search_domains,
                    "limit": max_search_domains,
                },
            )
        )
    else:
        section.add(
            CheckItem(
                name="Kubernetes Search Domain Budget",
                status="PASS",
                detail=f"{sd_count} domain(s) configured: {parsed.search_domains or ['None']}",
                expected=f"<= {max_search_domains} search domains",
                actual=f"{sd_count} domains",
                why="Leaves ample headroom for the 3 cluster search domains Kubernetes injects into pods.",
            )
        )

    if total_sd_chars > 256:
        section.add(
            CheckItem(
                name="Search Domain String Length",
                status="WARN",
                detail=f"Total search string length ({total_sd_chars} bytes) exceeds glibc's 256-byte limit.",
                expected="<= 256 bytes",
                actual=f"{total_sd_chars} bytes",
                why="glibc truncates search domain strings exceeding 256 bytes.",
                metadata={
                    "issue": "resolv.search_too_long",
                    "path": str(resolv_conf_path),
                    "search_domains": parsed.search_domains,
                },
            )
        )

    # 3. Search Domain vs Wildcard Collision
    if wildcard_base and parsed.nameservers:
        audit_search_wildcard_collision(section, parsed, wildcard_base)

    # 4. Stub Loopback Resolver Check (127.0.0.53 / systemd-resolved)
    has_loopback = False
    for ns in parsed.nameservers:
        try:
            ip = ipaddress.ip_address(ns)
            if ip.is_loopback:
                has_loopback = True
                break
        except ValueError:
            pass

    systemd_upstream_resolv = Path("/run/systemd/resolve/resolv.conf")
    if has_loopback:
        detail_msg = "Found local loopback resolver (127.0.0.53) in /etc/resolv.conf."
        if systemd_upstream_resolv.is_file():
            detail_msg += " Upstream servers available at /run/systemd/resolve/resolv.conf."

        section.add(
            CheckItem(
                name="Loopback Stub Resolver Check (127.0.0.53)",
                status="WARN",
                detail=detail_msg,
                expected="Routable upstream nameservers (or Kubelet configured with --resolv-conf=/run/systemd/resolve/resolv.conf)",
                actual=f"Nameservers contain loopback: {parsed.nameservers}",
                why="Kubernetes pods run in isolated network namespaces and cannot reach the host's 127.0.0.53 loopback, triggering CoreDNS forwarding loops (CrashLoopBackOff).",
                metadata={
                    "issue": "resolv.loopback_stub",
                    "path": str(resolv_conf_path),
                    "nameservers": parsed.nameservers,
                    "systemd_upstream_available": systemd_upstream_resolv.is_file(),
                },
            )
        )
    else:
        section.add(
            CheckItem(
                name="Loopback Stub Resolver Check (127.0.0.53)",
                status="PASS",
                detail="All configured nameservers are routable network IP addresses.",
                expected="No loopback resolvers (127.0.0.X)",
                actual=f"{parsed.nameservers}",
                why="Ensures pods and CoreDNS can forward queries to external nameservers without loopback collision.",
            )
        )

    return parsed


def wildcard_collisions(domains: List[str], wildcard_base: str) -> List[str]:
    """Return search domains equal to, or under, the wildcard base (so the wildcard matches every suffixed lookup)."""
    base = wildcard_base.lstrip("*.").rstrip(".").lower()
    hits = []
    for d in domains:
        norm = d.rstrip(".").lower()
        if norm and (norm == base or norm.endswith("." + base)):
            hits.append(d)
    return hits


def audit_search_wildcard_collision(section: CheckSection, parsed: ResolvConfParsed, wildcard_base: str) -> None:
    base = wildcard_base.lstrip("*.")
    why = (
        f"Pods inherit host search domains with ndots:5. A lookup like registry.example.com is first tried as "
        f"registry.example.com.<search>; with *.{base} in DNS that matches the wildcard, so external names "
        f"silently resolve to the controller IP."
    )
    effective = parsed.search_domains
    derived = False
    if not effective:
        # glibc falls back to the domain part of the hostname when no search/domain line exists
        host = socket.gethostname()
        if "." in host:
            effective = [host.split(".", 1)[1]]
            derived = True

    hits = wildcard_collisions(effective, wildcard_base)
    if hits:
        source = "derived from hostname (no search line)" if derived else "configured"
        section.add(
            CheckItem(
                name="Search Domain Wildcard Collision",
                status="FAIL",
                detail=f"Search domain(s) {hits} ({source}) are covered by wildcard *.{base}.",
                expected=f"No search domain equal to or under {base} (e.g. 'search .' or unrelated domains)",
                actual=f"search {' '.join(effective)}",
                why=why,
                metadata={
                    "issue": "resolv.search_wildcard_collision",
                    "path": str(parsed.path),
                    "domains": hits,
                    "derived_from_hostname": derived,
                },
            )
        )
    else:
        section.add(
            CheckItem(
                name="Search Domain Wildcard Collision",
                status="PASS",
                detail=f"No search domain is covered by wildcard *.{base}.",
                expected=f"No search domain equal to or under {base}",
                actual=f"search {' '.join(effective) if effective else '(none)'}",
                why="Prevents wildcard DNS from hijacking pod lookups of external names.",
            )
        )
