"""CLI entrypoint for Rafay & Kubernetes DNS Validation Engine."""

import argparse
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from tools.common.colors import bold, green, red, set_color_mode, yellow
from tools.common.reporter import ValidationReport
from tools.common.netinfo import detect_node_ip
from tools.common.ownership import write_text
from tools.config_loader import get_merged_config, wildcard_ip as cfg_wildcard_ip
from tools.dns_validator.config_audit import audit_resolver_config
from tools.dns_validator.probe import probe_nameservers
from tools.dns_validator.remediation import (
    RemediationAction, apply_actions, build_plan, plan_item_to_dict, render_plan, render_plan_markdown,
)
from tools.dns_validator.resolution import audit_node_resolution
from tools.dns_validator.wildcard import audit_wildcard_dns


@dataclass
class DnsSettings:
    fqdn: str
    wildcard_base: str
    node_ip: Optional[str] = None
    wildcard_ip: Optional[str] = None
    wildcard_scope: str = "auto"
    public_resolvers: List[str] = field(default_factory=list)
    resolv_conf: Path = Path("/etc/resolv.conf")
    check_tcp: bool = True
    warn_latency_ms: float = 100.0
    max_nameservers: int = 3
    max_search_domains: int = 3
    skip_wildcard: bool = False
    skip_probe: bool = False


def load_settings(config_path: Path, **overrides) -> DnsSettings:
    """Config file values, overridden by any non-None keyword (CLI flags)."""
    cfg = get_merged_config(config_path)
    ctrl, dns = cfg.get("controller", {}), cfg.get("dns_validation", {})
    fqdn = overrides.get("fqdn") or ctrl.get("fqdn", "rctrl01.rafay.lab")
    s = DnsSettings(
        fqdn=fqdn,
        wildcard_base=overrides.get("wildcard_base") or ctrl.get("wildcard_base") or fqdn,
        node_ip=overrides.get("node_ip") or ctrl.get("node_ip"),
        wildcard_ip=overrides.get("wildcard_ip") or cfg_wildcard_ip(cfg),
        wildcard_scope=overrides.get("wildcard_scope") or ctrl.get("wildcard_scope") or "auto",
        public_resolvers=dns.get("public_resolvers", ["8.8.8.8", "1.1.1.1"]),
        check_tcp=dns.get("check_tcp", True),
        warn_latency_ms=dns.get("warn_latency_ms", 100.0),
        max_nameservers=dns.get("max_nameservers", 3),
        max_search_domains=dns.get("max_search_domains", 3),
    )
    for key in ("resolv_conf", "skip_wildcard", "skip_probe"):
        if overrides.get(key) is not None:
            setattr(s, key, overrides[key])
    return s


def run_dns_validation(s: DnsSettings) -> ValidationReport:
    """Run all DNS validation suites and return a structured ValidationReport."""
    report = ValidationReport(title="Rafay / Kubernetes DNS Validation Engine")

    # Section 1: Host Resolver Audit
    sec_audit = report.new_section("1/4: Host Resolver Audit (/etc/resolv.conf)")
    parsed_resolv = audit_resolver_config(
        sec_audit,
        resolv_conf_path=s.resolv_conf,
        max_nameservers=s.max_nameservers,
        max_search_domains=s.max_search_domains,
        wildcard_base=s.wildcard_base,
    )
    nameservers = parsed_resolv.nameservers

    # If /etc/resolv.conf has only a loopback stub, audit the systemd-resolved upstream file the kubelet uses
    systemd_upstream = Path("/run/systemd/resolve/resolv.conf")
    if all(ns.startswith("127.") for ns in nameservers) and systemd_upstream.is_file():
        sec_audit_up = report.new_section("Systemd-Resolved Upstream Reference (/run/systemd/resolve/resolv.conf)")
        parsed_up = audit_resolver_config(
            sec_audit_up,
            resolv_conf_path=systemd_upstream,
            max_nameservers=s.max_nameservers,
            max_search_domains=s.max_search_domains,
            wildcard_base=s.wildcard_base,
        )
        if parsed_up.nameservers:
            nameservers = parsed_up.nameservers

    node_ip = s.node_ip or detect_node_ip(nameservers)
    report.metadata = {
        "Node FQDN": s.fqdn,
        "Node IP": f"{node_ip} ({'configured' if s.node_ip else 'auto-detected'})" if node_ip else "unknown",
        "Wildcard": f"*.{s.wildcard_base.lstrip('*.')} (scope: {s.wildcard_scope})",
        "Expected Wildcard IP": s.wildcard_ip or "not specified",
        "Resolver Config": str(s.resolv_conf),
        "Upstream Nameservers": " ".join(nameservers) or "none",
    }

    # Section 2: Port 53 Reachability & Latency
    if not s.skip_probe and nameservers:
        sec_probe = report.new_section("2/4: Upstream Nameserver Connectivity & Latency")
        probe_nameservers(sec_probe, nameservers=nameservers, check_tcp=s.check_tcp,
                          warn_latency_ms=s.warn_latency_ms)

    # Section 3: Node hostname resolution (host-local requirement; DNS record optional)
    sec_res = report.new_section("3/4: Node Hostname Resolution")
    audit_node_resolution(sec_res, fqdn=s.fqdn, nameservers=nameservers, node_ip=node_ip)

    # Section 4: Wildcard (console/API) DNS
    if not s.skip_wildcard:
        sec_wild = report.new_section("4/4: Wildcard (Console/API) DNS")
        report.wildcard = audit_wildcard_dns(sec_wild, wildcard_base=s.wildcard_base, nameservers=nameservers,
                           expected_ip=s.wildcard_ip, scope=s.wildcard_scope,
                           public_resolvers=s.public_resolvers, fqdn=s.fqdn)

    report.nameservers = nameservers
    report.node_ip = node_ip
    return report


def plan_for(report: ValidationReport, s: DnsSettings) -> List[RemediationAction]:
    if report.exit_code == 0:
        return []
    return build_plan(report, s, getattr(report, "nameservers", []), getattr(report, "node_ip", None))


def main():
    parser = argparse.ArgumentParser(
        description="DNS & wildcard validation for Kubernetes / Rafay controller nodes",
        epilog="Exit codes: 0 = pass, 1 = warnings, 2 = failures.",
    )
    parser.add_argument("-f", "--fqdn", help="Node FQDN / hostname (e.g. rctrl01.rafay.lab)")
    parser.add_argument("-w", "--wildcard-base", help="Console/API wildcard base (e.g. ctrl.example.com); "
                                                      "may be unrelated to the FQDN")
    parser.add_argument("-n", "--node-ip", help="Node IP the FQDN must map to (default: auto-detect)")
    parser.add_argument("-i", "--wildcard-ip", "--expected-ip", dest="wildcard_ip",
                        help="Expected answer for *.<wildcard-base> (public IP for a public wildcard)")
    parser.add_argument("-s", "--wildcard-scope", choices=["auto", "public", "private"],
                        help="Where the wildcard zone is served (default: auto = infer from the answer)")
    parser.add_argument("-c", "--config", type=Path, default=Path("rafay_prep_config.json"),
                        help="Path to configuration file")
    parser.add_argument("--resolv-conf", type=Path, help="resolv.conf to audit (default: /etc/resolv.conf)")
    parser.add_argument("--json", action="store_true", help="Print the report + plan as JSON (no prompts, no changes)")
    parser.add_argument("--json-out", type=Path, help="Also write the final JSON report to this path")
    parser.add_argument("--md-out", type=Path, help="Also write the final report + plan as Markdown to this path")
    parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors")
    parser.add_argument("--skip-wildcard", action="store_true", default=None, help="Skip wildcard checks")
    parser.add_argument("--skip-probe", action="store_true", default=None, help="Skip UDP/TCP probing")
    parser.add_argument("--no-fix", action="store_true", help="Show the plan but never prompt for or apply fixes")
    parser.add_argument("--yes", action="store_true", help="Apply local fixes without prompting")

    args = parser.parse_args()
    if args.no_color:
        set_color_mode(False)

    s = load_settings(args.config, fqdn=args.fqdn, wildcard_base=args.wildcard_base, node_ip=args.node_ip,
                      wildcard_ip=args.wildcard_ip, wildcard_scope=args.wildcard_scope,
                      resolv_conf=args.resolv_conf, skip_wildcard=args.skip_wildcard, skip_probe=args.skip_probe)

    def validate() -> ValidationReport:
        return run_dns_validation(s)

    def plan(rep: ValidationReport) -> List[RemediationAction]:
        return plan_for(rep, s)

    report = validate()
    actions = plan(report)

    if args.json:
        # Machine-readable mode: report + plan, never prompts or changes anything
        print(json.dumps(report_with_plan(report, actions), indent=2))
    else:
        print(report.render_console())
        if actions:
            print(render_plan(actions))
            report, actions = offer_local_fixes(report, actions, validate, plan, args)
        print(render_verdict(report, actions, args.json_out, args.md_out))

    if args.json_out:
        write_text(args.json_out, json.dumps(report_with_plan(report, actions), indent=2))
    if args.md_out:
        write_text(args.md_out, report.render_markdown() + "\n" + render_plan_markdown(actions))

    sys.exit(report.exit_code)


def report_with_plan(report: ValidationReport, actions: List[RemediationAction]) -> dict:
    data = report.to_dict()
    data["remediation"] = [plan_item_to_dict(a) for a in actions]
    return data


def offer_local_fixes(report, actions, validate, plan, args):
    """Prompt for (or auto-apply) local fixes, re-validate, and return the final report and plan."""
    local = [a for a in actions if a.local]
    if not local:
        return report, actions
    if args.no_fix:
        print(f"\n{len(local)} local fix(es) available (not applied: --no-fix).")
        return report, actions
    if os.geteuid() != 0:
        print(f"\n{len(local)} local fix(es) available. Re-run as root (sudo) to apply them.")
        return report, actions
    if not args.yes:
        if not sys.stdin.isatty():
            print(f"\n{len(local)} local fix(es) available. Re-run interactively or with --yes to apply them.")
            return report, actions
        print(f"\nApply the {len(local)} local fix(es) above? (y/n)")
        try:
            answer = input().strip().lower()
        except EOFError:
            answer = ""
        if answer not in ("y", "yes"):
            print("Local fixes skipped.")
            return report, actions

    print(bold("\nApplying local fixes..."))
    apply_actions(actions)
    print("\nRe-running DNS validation...")
    report = validate()
    print(report.render_console())
    actions = plan(report)
    if actions:
        print(render_plan(actions, title="REMAINING DNS REMEDIATION ACTIONS"))
    return report, actions


def render_verdict(report: ValidationReport, actions: List[RemediationAction], json_out: Optional[Path],
                   md_out: Optional[Path] = None) -> str:
    external = sum(1 for a in actions if not a.local)
    local = sum(1 for a in actions if a.local)
    lines = [""]
    if report.exit_code == 0:
        lines.append(green("✔ DNS and wildcard validation passed. No action required."))
    elif report.exit_code == 1:
        lines.append(yellow("⚠ DNS validation completed with warnings. Review the plan above."))
    else:
        lines.append(red("✖ [CRITICAL] DNS resolution does not meet Kubernetes requirements."))
        lines.append("  Continuing may result in cluster bootstrap failure or inaccessible services.")
    if local:
        lines.append(f"  Outstanding local fixes:     {local}")
    if external:
        lines.append(f"  Outstanding external actions: {external} (must be completed outside this host, then re-run)")
    for p in (json_out, md_out):
        if p:
            lines.append(f"  Report: {p}")
    return "\n".join(lines)


if __name__ == "__main__":
    main()
