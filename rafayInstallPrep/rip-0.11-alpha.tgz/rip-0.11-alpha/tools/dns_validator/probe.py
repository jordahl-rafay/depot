"""Network reachability and latency probing for nameservers on UDP and TCP port 53."""

import socket
import time
from typing import Dict, Any, List

from tools.common.reporter import CheckSection, CheckItem


def probe_tcp_port(host: str, port: int = 53, timeout: float = 2.0) -> Dict[str, Any]:
    """Test TCP port connectivity and measure round-trip handshake latency."""
    start = time.perf_counter()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((host, port))
        latency_ms = (time.perf_counter() - start) * 1000.0
        return {"reachable": True, "latency_ms": round(latency_ms, 2), "error": None}
    except Exception as e:
        return {"reachable": False, "latency_ms": None, "error": str(e)}
    finally:
        sock.close()


def probe_udp_port(host: str, port: int = 53, timeout: float = 2.0) -> Dict[str, Any]:
    """Send a lightweight DNS query over UDP to test reachability and latency."""
    # Standard RFC 1035 root query: query ID 0x1234, flags 0x0100 (standard query, RD), QDCOUNT=1
    # Question: "." type NS, class IN
    root_query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x01"
    start = time.perf_counter()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        sock.sendto(root_query, (host, port))
        data, _ = sock.recvfrom(512)
        latency_ms = (time.perf_counter() - start) * 1000.0
        return {"reachable": True, "latency_ms": round(latency_ms, 2), "error": None}
    except socket.timeout:
        return {"reachable": False, "latency_ms": None, "error": "Query timed out"}
    except Exception as e:
        return {"reachable": False, "latency_ms": None, "error": str(e)}
    finally:
        sock.close()


def probe_nameservers(
    section: CheckSection,
    nameservers: List[str],
    check_tcp: bool = True,
    warn_latency_ms: float = 100.0,
) -> Dict[str, Dict[str, Any]]:
    """Probe all nameservers and record connectivity/latency checks."""
    results: Dict[str, Dict[str, Any]] = {}

    for ns in nameservers:
        # Loopback servers don't need network testing
        if ns.startswith("127."):
            continue

        udp_res = probe_udp_port(ns, port=53)
        tcp_res = probe_tcp_port(ns, port=53) if check_tcp else None

        results[ns] = {"udp": udp_res, "tcp": tcp_res}

        # Evaluate UDP
        if udp_res["reachable"]:
            lat = udp_res["latency_ms"]
            status = "PASS" if lat <= warn_latency_ms else "WARN"
            section.add(
                CheckItem(
                    name=f"Nameserver {ns} (UDP:53)",
                    status=status,
                    detail=f"Reachable. Round-trip latency: {lat}ms",
                    expected=f"Reachable, latency <= {warn_latency_ms}ms",
                    actual=f"Reachable in {lat}ms",
                    why="UDP port 53 is the primary transport for standard DNS queries.",
                    metadata={"issue": "probe.high_latency", "nameserver": ns, "latency_ms": lat} if status == "WARN" else {},
                )
            )
        else:
            section.add(
                CheckItem(
                    name=f"Nameserver {ns} (UDP:53)",
                    status="FAIL",
                    detail=f"Unreachable: {udp_res['error']}",
                    expected="Reachable over UDP port 53",
                    actual="Connection failed / timed out",
                    why="Nameserver cannot answer DNS queries if UDP port 53 is blocked by network firewalls.",
                    metadata={"issue": "probe.udp_unreachable", "nameserver": ns},
                )
            )

        # Evaluate TCP
        if check_tcp and tcp_res:
            if tcp_res["reachable"]:
                lat = tcp_res["latency_ms"]
                status = "PASS" if lat <= warn_latency_ms else "WARN"
                section.add(
                    CheckItem(
                        name=f"Nameserver {ns} (TCP:53)",
                        status=status,
                        detail=f"Reachable. TCP handshake latency: {lat}ms",
                        expected=f"Reachable, latency <= {warn_latency_ms}ms",
                        actual=f"Reachable in {lat}ms",
                        why="TCP port 53 is required for DNS responses exceeding 512 bytes, EDNS0 buffer fallback, and DNSSEC.",
                        metadata={"issue": "probe.high_latency", "nameserver": ns, "latency_ms": lat} if status == "WARN" else {},
                    )
                )
            else:
                section.add(
                    CheckItem(
                        name=f"Nameserver {ns} (TCP:53)",
                        status="WARN",
                        detail=f"TCP 53 failed: {tcp_res['error']}",
                        expected="Reachable over TCP port 53",
                        actual="Connection failed / timed out",
                        why="If TCP 53 is blocked, large DNS responses (e.g. multi-IP service records) will fail with truncated errors.",
                        metadata={"issue": "probe.tcp_unreachable", "nameserver": ns},
                    )
                )

    return results
