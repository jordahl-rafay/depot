"""Entrypoint for python3 -m tools.dns_validator."""

from tools.dns_validator.cli import main

if __name__ == "__main__":
    main()
