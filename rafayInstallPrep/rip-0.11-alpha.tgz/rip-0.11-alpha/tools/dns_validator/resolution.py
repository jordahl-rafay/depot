"""DNS query engine implementing RFC 1035 wire protocol in pure Python standard library.

Provides direct querying against individual nameservers, local NSS resolution,
split-brain consistency checking, and reverse DNS validation without external tools.
"""

from typing import List, Dict, Any, Optional, Set, Tuple
import os
import random
import socket
import struct
import time

import ipaddress
import subprocess

from tools.common.netinfo import local_ips
from tools.common.reporter import CheckSection, CheckItem


# DNS Response Codes (RFC 1035)
RCODES = {
    0: "NOERROR",
    1: "FORMERR",
    2: "SERVFAIL",
    3: "NXDOMAIN",
    4: "NOTIMP",
    5: "REFUSED",
}


def build_dns_query(domain: str, query_type: int = 1) -> Tuple[int, bytes]:
    """Build an RFC 1035 wire-format DNS query packet for an A record.

    query_type: 1 = A, 12 = PTR, 28 = AAAA.
    """
    query_id = random.randint(1, 65535)
    # Flags: standard query, recursion desired (RD=1) -> 0x0100
    flags = 0x0100
    qdcount = 1
    ancount = 0
    nscount = 0
    arcount = 0

    header = struct.pack("!HHHHHH", query_id, flags, qdcount, ancount, nscount, arcount)

    # Encode domain name into labels: "rctrl01.rafay.lab" -> "\x07rctrl01\x05rafay\x03lab\x00"
    question = bytearray()
    for part in domain.strip(".").split("."):
        encoded = part.encode("ascii")
        question.append(len(encoded))
        question.extend(encoded)
    question.append(0)  # terminating zero

    # QTYPE and QCLASS (IN = 1)
    question.extend(struct.pack("!HH", query_type, 1))

    return query_id, bytes(header + question)


def parse_dns_name(buffer: bytes, offset: int) -> Tuple[str, int]:
    """Parse a domain name from a DNS packet, handling label pointers (0xC0)."""
    labels = []
    jumped = False
    original_offset = offset
    max_jumps = 20
    jumps = 0

    while True:
        if offset >= len(buffer):
            break
        length = buffer[offset]
        if length == 0:
            offset += 1
            break
        elif (length & 0xC0) == 0xC0:
            # Pointer jump
            if offset + 1 >= len(buffer):
                break
            pointer = struct.unpack("!H", buffer[offset : offset + 2])[0] & 0x3FFF
            if not jumped:
                original_offset = offset + 2
                jumped = True
            offset = pointer
            jumps += 1
            if jumps > max_jumps:
                break
        else:
            offset += 1
            labels.append(buffer[offset : offset + length].decode("ascii", errors="replace"))
            offset += length

    final_offset = original_offset if jumped else offset
    return ".".join(labels), final_offset


def parse_dns_response(buffer: bytes, expected_id: int) -> Dict[str, Any]:
    """Parse an RFC 1035 DNS response packet."""
    if len(buffer) < 12:
        return {"error": "Response packet too short", "rcode": -1, "answers": []}

    res_id, flags, qdcount, ancount, nscount, arcount = struct.unpack("!HHHHHH", buffer[:12])
    if res_id != expected_id:
        return {"error": f"ID mismatch (expected {expected_id}, got {res_id})", "rcode": -1, "answers": []}

    rcode_val = flags & 0x000F
    rcode_str = RCODES.get(rcode_val, f"RCODE_{rcode_val}")
    tc_flag = bool(flags & 0x0200)

    offset = 12

    # Skip question section
    for _ in range(qdcount):
        _, offset = parse_dns_name(buffer, offset)
        offset += 4  # QTYPE (2) + QCLASS (2)

    answers: List[str] = []

    # Parse answer section
    for _ in range(ancount):
        if offset >= len(buffer):
            break
        _, offset = parse_dns_name(buffer, offset)
        if offset + 10 > len(buffer):
            break
        rtype, rclass, ttl, rdlength = struct.unpack("!HHIH", buffer[offset : offset + 10])
        offset += 10
        rdata = buffer[offset : offset + rdlength]
        offset += rdlength

        # Type 1: A record (IPv4)
        if rtype == 1 and rdlength == 4:
            ip = socket.inet_ntoa(rdata)
            answers.append(ip)

    return {
        "rcode": rcode_str,
        "rcode_val": rcode_val,
        "truncated": tc_flag,
        "answers": sorted(answers),
        "error": None,
    }


def query_nameserver_direct(
    nameserver: str,
    domain: str,
    port: int = 53,
    timeout: float = 3.0,
) -> Dict[str, Any]:
    """Send a direct DNS query to a specific nameserver over UDP (with TCP fallback)."""
    query_id, query_packet = build_dns_query(domain, query_type=1)

    start = time.perf_counter()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)

    try:
        sock.sendto(query_packet, (nameserver, port))
        data, _ = sock.recvfrom(4096)
        elapsed_ms = round((time.perf_counter() - start) * 1000.0, 2)
        parsed = parse_dns_response(data, query_id)
        parsed["latency_ms"] = elapsed_ms
        parsed["protocol"] = "UDP"

        # If truncated (TC bit set), retry over TCP
        if parsed.get("truncated"):
            tcp_res = query_nameserver_tcp(nameserver, domain, port, timeout)
            tcp_res["latency_ms"] = round((time.perf_counter() - start) * 1000.0, 2)
            tcp_res["protocol"] = "TCP_FALLBACK"
            return tcp_res

        return parsed
    except socket.timeout:
        return {"error": "Query timed out", "rcode": "TIMEOUT", "answers": [], "latency_ms": None}
    except Exception as e:
        return {"error": str(e), "rcode": "ERROR", "answers": [], "latency_ms": None}
    finally:
        sock.close()


def query_nameserver_tcp(
    nameserver: str,
    domain: str,
    port: int = 53,
    timeout: float = 4.0,
) -> Dict[str, Any]:
    """Send a direct DNS query over TCP (RFC 1035 length-prefixed format)."""
    query_id, query_packet = build_dns_query(domain, query_type=1)
    tcp_packet = struct.pack("!H", len(query_packet)) + query_packet

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((nameserver, port))
        sock.sendall(tcp_packet)

        # Read 2-byte length prefix
        len_prefix = sock.recv(2)
        if len(len_prefix) < 2:
            return {"error": "Truncated TCP length prefix", "rcode": "ERROR", "answers": []}
        msg_len = struct.unpack("!H", len_prefix)[0]

        # Read payload
        data = bytearray()
        while len(data) < msg_len:
            chunk = sock.recv(msg_len - len(data))
            if not chunk:
                break
            data.extend(chunk)

        parsed = parse_dns_response(bytes(data), query_id)
        parsed["protocol"] = "TCP"
        return parsed
    except Exception as e:
        return {"error": str(e), "rcode": "ERROR", "answers": []}
    finally:
        sock.close()


def resolve_local(domain: str) -> Dict[str, Any]:
    """Resolve a domain name using the local OS resolver (glibc getaddrinfo)."""
    start = time.perf_counter()
    try:
        info = socket.getaddrinfo(domain, None, socket.AF_INET, socket.SOCK_STREAM)
        ips = sorted(list({item[4][0] for item in info}))
        elapsed_ms = round((time.perf_counter() - start) * 1000.0, 2)
        return {"answers": ips, "error": None, "latency_ms": elapsed_ms}
    except Exception as e:
        return {"answers": [], "error": str(e), "latency_ms": None}


def hostname_i() -> Dict[str, Any]:
    """`hostname -i`: what radm's /opt/rafay_init.sh uses to pick the node nameserver at every boot."""
    try:
        out = subprocess.run(["hostname", "-i"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        return {"answers": out.stdout.decode().split(), "error": out.stderr.decode().strip() or None}
    except Exception as e:
        return {"answers": [], "error": str(e)}


def audit_node_resolution(
    section: CheckSection,
    fqdn: str,
    nameservers: List[str],
    node_ip: Optional[str],
) -> Dict[str, Any]:
    """Validate how the node's own FQDN resolves.

    What radm needs: the host resolves its FQDN to the node IP, and `hostname -i` prints exactly that IP.
    Kubernetes itself registers the node by IP, and the API/registry are reached through Consul names, so the
    FQDN does *not* have to exist in DNS. A DNS record only matters if other machines address the node by name.
    """
    results: Dict[str, Any] = {"upstream": {}}

    # 1. Node IP sanity
    if node_ip:
        local = local_ips()
        if local and node_ip not in local:
            section.add(CheckItem(
                name="Node IP", status="FAIL",
                detail=f"Configured node IP {node_ip} is not assigned to any interface on this host.",
                expected="An address from `ip addr`", actual=f"{local}",
                why="The FQDN must map to an address this node owns; radm binds Consul to it.",
                metadata={"issue": "node.ip_not_local", "node_ip": node_ip},
            ))
        else:
            section.add(CheckItem(
                name="Node IP", status="INFO", detail=f"Using node IP {node_ip}.",
                expected="Interface address on the default route", actual=node_ip,
                why="The FQDN and `hostname -i` should both resolve to this address.",
            ))

    # 2. Host (NSS) resolution of the FQDN
    local_res = resolve_local(fqdn)
    v4 = sorted({ip for ip in local_res.get("answers", []) if ":" not in ip})
    if not v4:
        section.add(CheckItem(
            name=f"Host Resolution ({fqdn})", status="FAIL",
            detail=f"The host cannot resolve its own FQDN: {local_res.get('error')}",
            expected=node_ip or "Node IP", actual="Resolution failed",
            why="kubelet/kubeadm and radm's boot scripts resolve the node name locally; without it bootstrap and reboot handling break.",
            metadata={"issue": "res.local_fail"},
        ))
    elif any(ipaddress.ip_address(ip).is_loopback for ip in v4):
        section.add(CheckItem(
            name=f"Host Resolution ({fqdn})", status="FAIL",
            detail=f"FQDN resolves to a loopback address {v4}.",
            expected=node_ip or "Node IP", actual=f"{v4}",
            why="radm's /opt/rafay_init.sh writes `nameserver $(hostname -i)` into /etc/resolv.conf at every boot. A "
                "loopback answer adds a dead nameserver and breaks the resolv.conf symlink on reboot.",
            metadata={"issue": "res.local_loopback", "answers": v4},
        ))
    elif node_ip and v4 != [node_ip]:
        section.add(CheckItem(
            name=f"Host Resolution ({fqdn})", status="WARN",
            detail=f"FQDN resolves to {v4}, not only the node IP {node_ip}.",
            expected=node_ip, actual=f"{v4}",
            why="Without a pinned /etc/hosts entry systemd-resolved answers with every local address (including CNI "
                "interfaces after install), so clients may pick an unreachable one.",
            metadata={"issue": "res.local_ip_mismatch", "answers": v4},
        ))
    else:
        section.add(CheckItem(
            name=f"Host Resolution ({fqdn})", status="PASS",
            detail=f"Host resolves {fqdn} to {v4}.", expected=node_ip or "Node IP", actual=f"{v4}",
            why="The node can always resolve its own name, independent of external DNS.",
        ))

    # 3. hostname -i must be exactly the node IP (radm reboot script contract)
    hi = hostname_i()
    hi_ips = hi["answers"]
    if node_ip and hi_ips == [node_ip]:
        section.add(CheckItem(
            name="`hostname -i`", status="PASS", detail=f"Returns exactly {node_ip}.",
            expected=node_ip, actual=" ".join(hi_ips),
            why="radm's rafay_init.sh only leaves /etc/resolv.conf alone when `nameserver $(hostname -i)` already matches.",
        ))
    elif not node_ip:
        section.add(CheckItem(
            name="`hostname -i`", status="INFO",
            detail=f"Returns {hi_ips or hi['error']}; node IP unknown, so it cannot be compared.",
            expected="Node IP", actual=" ".join(hi_ips) or str(hi["error"]),
            why="Pass --node-ip (or set controller.node_ip) to verify radm's boot-script contract.",
        ))
    elif hi_ips or hi["error"]:
        section.add(CheckItem(
            name="`hostname -i`", status="FAIL",
            detail=f"Returns {hi_ips or hi['error']}; must be exactly the node IP.",
            expected=node_ip or "Node IP", actual=" ".join(hi_ips) or str(hi["error"]),
            why="On every reboot radm's /opt/rafay_init.sh runs `sed -i` on /etc/resolv.conf unless "
                "`nameserver $(hostname -i)` is present, replacing the symlink; symchecker then relinks it to the "
                "non-existent /run/resolvconf/resolv.conf and host DNS breaks.",
            metadata={"issue": "node.hostname_i", "answers": hi_ips},
        ))

    # 4. Upstream DNS registration (optional: informational unless it disagrees)
    answered: Dict[str, set] = {}
    for ns in nameservers:
        if ns.startswith("127."):
            continue
        res = query_nameserver_direct(ns, fqdn)
        rcode, answers = res.get("rcode"), res.get("answers", [])
        results["upstream"][ns] = answers
        if rcode == "NOERROR" and answers:
            answered[ns] = set(answers)
            if node_ip and node_ip not in answers:
                section.add(CheckItem(
                    name=f"DNS Record @{ns}", status="WARN",
                    detail=f"DNS returns {answers} but the node IP is {node_ip}.",
                    expected=node_ip, actual=f"{answers}",
                    why="Other machines (and pods that query this server) will reach a different address than the "
                        "host itself uses.",
                    metadata={"issue": "res.upstream_ip_mismatch", "nameserver": ns, "answers": answers},
                ))
            else:
                section.add(CheckItem(
                    name=f"DNS Record @{ns}", status="PASS",
                    detail=f"{fqdn} is registered in DNS: {answers}.", expected="Optional A record",
                    actual=f"{answers}",
                    why="Typical enterprise setup: other systems can address the node by name.",
                ))
        elif rcode in ("TIMEOUT", "ERROR"):
            section.add(CheckItem(
                name=f"DNS Record @{ns}", status="WARN",
                detail=f"No answer from {ns}: {res.get('error')}",
                expected="Response (NOERROR or NXDOMAIN)", actual=f"RCODE: {rcode}",
                why="The nameserver did not respond; see the connectivity section.",
                metadata={"issue": "res.upstream_fail", "nameserver": ns, "rcode": rcode},
            ))
        else:
            section.add(CheckItem(
                name=f"DNS Record @{ns}", status="INFO",
                detail=f"{fqdn} is not in DNS ({rcode}). Fine for a stand-alone node: radm only needs host-local "
                       f"resolution.",
                expected="Optional A record", actual=f"RCODE: {rcode}",
                why="Kubernetes registers the node by IP and radm reaches the API/registry via Consul names; a DNS "
                    "record is only needed if other machines address the node by this name.",
            ))

    if len(answered) > 1 and len({frozenset(v) for v in answered.values()}) > 1:
        section.add(CheckItem(
            name="Upstream Consistency (FQDN)", status="WARN",
            detail="Nameservers disagree: " + "; ".join(f"{k} -> {sorted(v)}" for k, v in answered.items()),
            expected="Identical answers", actual="Divergent answers",
            why="CoreDNS picks an upstream at random, so lookups of this name from pods return different addresses.",
            metadata={"issue": "res.split_brain", "answers": {k: sorted(v) for k, v in answered.items()}},
        ))

    # 5. Reverse DNS (informational)
    if node_ip:
        try:
            ptr_name, _, _ = socket.gethostbyaddr(node_ip)
            section.add(CheckItem(name=f"Reverse DNS ({node_ip})", status="INFO", detail=f"PTR: {ptr_name}",
                                  expected=f"Optional PTR -> {fqdn}", actual=ptr_name,
                                  why="Reverse DNS is optional for the controller."))
        except Exception:
            pass

    return results
