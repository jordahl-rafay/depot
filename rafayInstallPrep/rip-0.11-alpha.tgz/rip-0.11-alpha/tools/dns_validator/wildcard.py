"""Wildcard DNS testing for the Rafay controller domain (public or private zones).

The wildcard base (e.g. `steve.demo.gorafay.net`) is independent of the node FQDN (e.g. `rctrl01.rafay.lab`) and
is served by a DNS service separate from the controller:

* public  - hosted publicly (e.g. Route 53), usually answers with the node's *public* IP
* private - hosted on internal DNS, answers with an internal IP / load balancer

Either way the node's upstream resolvers must answer it: CoreDNS (and so every pod) and radm's Consul recursion
end up there. Public zones must also resolve from the internet.
"""

from typing import Any, Dict, List, Optional
import secrets

from tools.common.netinfo import ip_scope
from tools.common.reporter import CheckSection, CheckItem
from tools.dns_validator.resolution import query_nameserver_direct, resolve_local


def generate_wildcard_nonce(prefix: str = "test") -> str:
    """Generate a random label to bypass caches."""
    return f"{prefix}-{secrets.token_hex(4)}"


def _scope_of(answers: List[str]) -> Optional[str]:
    scopes = {ip_scope(ip) for ip in answers}
    if scopes == {"public"}:
        return "public"
    if scopes and scopes <= {"private", "loopback", "link-local"}:
        return "private"
    return "mixed" if scopes else None


def audit_wildcard_dns(
    section: CheckSection,
    wildcard_base: str,
    nameservers: List[str],
    expected_ip: Optional[str] = None,
    scope: str = "auto",
    public_resolvers: Optional[List[str]] = None,
    fqdn: Optional[str] = None,
    test_subdomains: bool = True,
) -> Dict[str, Any]:
    base = wildcard_base.lstrip("*.").rstrip(".")
    test_fqdn = f"{generate_wildcard_nonce()}.{base}"
    results: Dict[str, Any] = {"nonce_tested": test_fqdn, "upstreams": {}, "public": {}, "local": None}

    if fqdn and not (fqdn.endswith("." + base) or fqdn == base):
        section.add(CheckItem(
            name="Wildcard Base vs Node FQDN", status="INFO",
            detail=f"*.{base} is independent of the node FQDN {fqdn} (supported).",
            expected="Any domain", actual=base,
            why="The console/API domain does not have to share a zone with the node hostname.",
        ))

    # 1. Node upstream resolvers (the path CoreDNS, pods and Consul recursion use)
    upstream_answers: Dict[str, List[str]] = {}
    for ns in nameservers:
        if ns.startswith("127."):
            continue
        res = query_nameserver_direct(ns, test_fqdn)
        rcode, answers = res.get("rcode"), res.get("answers", [])
        results["upstreams"][ns] = answers
        if rcode == "NOERROR" and answers:
            upstream_answers[ns] = answers
            mismatch = expected_ip and expected_ip not in answers
            section.add(CheckItem(
                name=f"Wildcard via Upstream @{ns}",
                status="WARN" if mismatch else "PASS",
                detail=f"{test_fqdn} -> {answers}" + (f" (expected {expected_ip})" if mismatch else ""),
                expected=expected_ip or "Any A record", actual=f"{answers}",
                why="Pods and CoreDNS resolve the console/API names through this server.",
                metadata={"issue": "wild.upstream_ip_mismatch", "nameserver": ns, "answers": answers} if mismatch else {},
            ))
        elif rcode in ("TIMEOUT", "ERROR"):
            section.add(CheckItem(
                name=f"Wildcard via Upstream @{ns}", status="WARN",
                detail=f"No answer from {ns}: {res.get('error')}", expected="Response", actual=f"RCODE: {rcode}",
                why="The nameserver did not respond; see the connectivity section.",
                metadata={"issue": "wild.upstream_fail", "nameserver": ns, "rcode": rcode},
            ))
        else:
            section.add(CheckItem(
                name=f"Wildcard via Upstream @{ns}", status="FAIL",
                detail=f"{test_fqdn}: {rcode}. The node's resolver cannot see *.{base}.",
                expected="NOERROR with an A record", actual=f"RCODE: {rcode}",
                why="Pods (via CoreDNS) and radm resolve console/API names through this server. For a private zone it "
                    "must forward the zone to the internal DNS; for a public zone it must recurse to the internet.",
                metadata={"issue": "wild.upstream_fail", "nameserver": ns, "rcode": rcode},
            ))

    distinct = {tuple(sorted(v)) for v in upstream_answers.values()}
    if len(distinct) > 1:
        section.add(CheckItem(
            name="Wildcard Upstream Consistency", status="FAIL",
            detail="Upstreams disagree: " + "; ".join(f"{k} -> {v}" for k, v in upstream_answers.items()),
            expected="Identical answers", actual="Divergent answers",
            why="CoreDNS load-balances across upstreams at random, so console/API lookups from pods would flap.",
            metadata={"issue": "wild.split_brain", "answers": upstream_answers},
        ))

    # 2. Scope: configured vs. inferred from the answer
    all_answers = sorted({ip for v in upstream_answers.values() for ip in v})
    inferred = _scope_of(all_answers)
    effective = scope if scope in ("public", "private") else inferred
    if inferred:
        if scope in ("public", "private") and inferred != scope:
            section.add(CheckItem(
                name="Wildcard Scope", status="WARN",
                detail=f"Configured as {scope}, but answers {all_answers} are {inferred} addresses.",
                expected=f"{scope} addresses", actual=f"{inferred}: {all_answers}",
                why="A public wildcard normally points at the public IP; a private one at an internal IP or LB.",
                metadata={"issue": "wild.scope_mismatch", "configured": scope, "inferred": inferred},
            ))
        else:
            section.add(CheckItem(
                name="Wildcard Scope", status="INFO",
                detail=f"{effective} wildcard ({'configured' if scope != 'auto' else 'inferred'}): {all_answers}.",
                expected="public | private", actual=effective,
                why="Determines which additional checks apply (internet visibility, hairpin access).",
            ))
        if inferred == "public":
            section.add(CheckItem(
                name="Public Wildcard Access Path", status="INFO",
                detail=f"Pods and the host reach the console via public IP(s) {all_answers}.",
                expected="Hairpin/NAT path allowed", actual="Verify after install (post-validator TCP 443 test)",
                why="Traffic from the node to its own public IP must be allowed back in by the cloud NAT/security "
                    "rules; the post-install validator tests this once the ingress is listening.",
            ))

    # 3. Internet visibility (only meaningful for public zones; informational otherwise)
    for pr in public_resolvers or []:
        res = query_nameserver_direct(pr, test_fqdn, timeout=3.0)
        rcode, answers = res.get("rcode"), res.get("answers", [])
        results["public"][pr] = answers
        if rcode in ("TIMEOUT", "ERROR"):
            section.add(CheckItem(
                name=f"Public Resolver @{pr}", status="INFO",
                detail=f"Unreachable ({res.get('error')}). Expected on air-gapped networks.",
                expected="Reachable (optional)", actual=f"RCODE: {rcode}",
                why="Used only to check whether a public wildcard is visible from the internet.",
            ))
            continue
        visible = rcode == "NOERROR" and bool(answers)
        if effective == "public" and not visible:
            section.add(CheckItem(
                name=f"Public Resolver @{pr}", status="FAIL",
                detail=f"{test_fqdn}: {rcode} from the internet, but the wildcard is public.",
                expected="NOERROR with the public IP", actual=f"RCODE: {rcode}",
                why="Users and edge clusters outside the network resolve the console through public DNS.",
                metadata={"issue": "wild.public_missing", "resolver": pr, "rcode": rcode},
            ))
        elif visible and all_answers and sorted(answers) != all_answers:
            section.add(CheckItem(
                name=f"Public Resolver @{pr}", status="INFO",
                detail=f"Split-horizon: internet sees {answers}, the node sees {all_answers}.",
                expected="Intentional split-horizon", actual=f"{answers}",
                why="Fine when deliberate (internal clients use the internal answer).",
            ))
        else:
            section.add(CheckItem(
                name=f"Public Resolver @{pr}", status="PASS" if visible else "INFO",
                detail=(f"Publicly resolvable: {answers}" if visible
                        else f"Not visible on the internet ({rcode}), as expected for a private wildcard."),
                expected="public: resolvable / private: not required", actual=f"{answers or rcode}",
                why="Confirms the wildcard's exposure matches its scope.",
            ))

    # 4. Host resolution of the nonce
    local_res = resolve_local(test_fqdn)
    local_ips = local_res.get("answers", [])
    results["local"] = local_ips
    if local_ips:
        mismatch = expected_ip and expected_ip not in local_ips
        section.add(CheckItem(
            name="Wildcard via Host Resolver", status="WARN" if mismatch else "PASS",
            detail=f"{test_fqdn} -> {local_ips}" + (f" (expected {expected_ip})" if mismatch else ""),
            expected=expected_ip or "Any A record", actual=f"{local_ips}",
            why="Host-side tools (radm, kubectl, curl) reach the console through the host resolver.",
            metadata={"issue": "wild.local_ip_mismatch", "answers": local_ips} if mismatch else {},
        ))
    else:
        section.add(CheckItem(
            name="Wildcard via Host Resolver", status="FAIL",
            detail=f"{test_fqdn}: {local_res.get('error')}", expected=expected_ip or "Any A record",
            actual="Resolution failed",
            why="Host-side tools (radm, kubectl, curl) reach the console through the host resolver.",
            metadata={"issue": "wild.local_fail"},
        ))

    # 5. Nested names (optional)
    if test_subdomains:
        sub = f"{generate_wildcard_nonce()}.core.{base}"
        sub_ips = resolve_local(sub).get("answers", [])
        section.add(CheckItem(
            name="Multi-Level Wildcard (*.core.<base>)", status="PASS" if sub_ips else "INFO",
            detail=f"{sub} -> {sub_ips}" if sub_ips else "Not resolved. Single-level wildcard is standard.",
            expected="Optional", actual=f"{sub_ips or 'Not configured'}",
            why="Only needed if the deployment uses nested service names.",
        ))

    return results
