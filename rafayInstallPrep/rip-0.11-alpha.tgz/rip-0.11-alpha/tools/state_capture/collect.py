"""Read-only collection of host configuration and runtime state into a capture directory.

Capture layout (inside <label>_<host>_<timestamp>/):
  meta.json            label, host, OS, kernel, timestamps, collector options
  etc/...              copy of /etc (secrets replaced by a redaction note)
  manifest.json        path -> type/mode/owner/size/sha256 for watched roots
  filelist.tsv.gz      every path on the walked filesystems (path, type, size) for catch-all diffs
  sysctl.json          `sysctl -a` as a dict
  modules.json         loaded kernel modules
  packages.json        installed packages -> version
  units.json           systemd unit-file states and runtime states
  dns.json             summary of every resolver file (link target, nameservers, search, options)
  dns/...              copies of resolver files outside /etc (/run/systemd/resolve, NetworkManager)
  pod_dns/...          resolv.conf files handed to pod sandboxes (read from the host filesystem)
  scripts/...          text programs run by units/cron/rc.local + text files in /opt, /usr/local (scrubbed)
  scripts.json         index of those scripts and hashes of referenced binaries
  cmd/<name>.txt       output of read-only commands (stdout, stderr, rc)
  kube/<name>.txt      read-only kubectl queries (when a cluster is reachable)

Nothing here modifies the host. kubectl is only used with get/version/--raw GET requests.
"""

import gzip
import hashlib
import json
import os
import platform
import re
import shutil
import socket
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tools.common.ownership import hand_back
from tools.state_capture.redact import is_secret_file, scrub

TOOL_VERSION = "1"

# Roots whose files are individually recorded (hash + metadata)
MANIFEST_ROOTS = [
    "/etc",
    "/usr/lib/systemd/system",
    "/lib/systemd/system",
    "/usr/lib/sysctl.d",
    "/usr/lib/modules-load.d",
    "/usr/lib/modprobe.d",
    "/usr/local/bin",
    "/usr/local/sbin",
    "/usr/bin/radm",
    "/opt",
    "/var/lib/kubelet",
    "/run/systemd/resolve",
    "/run/systemd/network",
    "/run/NetworkManager",
]
# Subtrees that are huge and/or pure runtime data
MANIFEST_SKIP = [
    "/var/lib/kubelet/pods",
    "/var/lib/kubelet/plugins",
    "/var/lib/kubelet/pod-resources",
    "/opt/containerd",
]
HASH_MAX_BYTES = 64 * 1024 * 1024

# Catch-all filesystem walk exclusions (still -xdev per root)
WALK_SKIP = [
    "/proc", "/sys", "/dev", "/run", "/tmp", "/var/tmp", "/var/log", "/var/cache",
    "/var/lib/apt/lists", "/var/lib/dnf", "/var/lib/yum", "/var/crash", "/lost+found",
    "/snap", "/var/lib/snapd/snaps",
]

COPY_MAX_BYTES = 2 * 1024 * 1024

RESOLVER_FILES = [
    "/etc/resolv.conf",
    "/run/systemd/resolve/resolv.conf",
    "/run/systemd/resolve/stub-resolv.conf",
    "/run/NetworkManager/resolv.conf",
    "/run/NetworkManager/no-stub-resolv.conf",
]


def log(msg: str) -> None:
    print(f"  • {msg}", file=sys.stderr, flush=True)


def run(argv: List[str], timeout: int = 60, env: Optional[dict] = None) -> Tuple[int, str, str]:
    try:
        proc = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              timeout=timeout, env=env)
        return (proc.returncode,
                proc.stdout.decode("utf-8", errors="replace"),
                proc.stderr.decode("utf-8", errors="replace"))
    except FileNotFoundError:
        return 127, "", f"{argv[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"timed out after {timeout}s"
    except Exception as e:  # pragma: no cover - defensive
        return 1, "", str(e)


def write_cmd(dest: Path, name: str, argv: List[str], timeout: int = 60, env: Optional[dict] = None) -> str:
    """Run a command if present and store its output; returns stdout."""
    if not shutil.which(argv[0]) and not os.path.isabs(argv[0]):
        return ""
    rc, out, err = run(argv, timeout=timeout, env=env)
    dest.mkdir(parents=True, exist_ok=True)
    body = f"$ {' '.join(argv)}\n# rc={rc}\n{scrub(out)}"
    if err.strip():
        body += f"\n# --- stderr ---\n{scrub(err)}"
    (dest / f"{name}.txt").write_text(body, encoding="utf-8")
    return out


def sha256_file(path: str) -> Optional[str]:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def is_secret(path: str, head: bytes) -> bool:
    return is_secret_file(path, head)


# --- Collectors -----------------------------------------------------------------

def collect_meta(out: Path, label: str, options: dict) -> None:
    os_release = {}
    try:
        for line in Path("/etc/os-release").read_text(encoding="utf-8").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                os_release[k] = v.strip().strip('"')
    except OSError:
        pass
    meta = {
        "tool_version": TOOL_VERSION,
        "label": label,
        "hostname": socket.gethostname(),
        "fqdn": socket.getfqdn(),
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "kernel": platform.release(),
        "os": os_release.get("PRETTY_NAME", ""),
        "os_id": os_release.get("ID", ""),
        "os_version_id": os_release.get("VERSION_ID", ""),
        "euid": os.geteuid(),
        "python": platform.python_version(),
        "options": options,
    }
    (out / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def collect_etc_and_manifest(out: Path) -> None:
    manifest: Dict[str, dict] = {}
    seen_real = set()
    redacted = []
    etc_out = out / "etc"

    for root in MANIFEST_ROOTS:
        if not os.path.lexists(root):
            continue
        real_root = os.path.realpath(root)
        # /lib -> /usr/lib on merged-/usr systems: don't walk the same tree twice
        if real_root in seen_real and real_root != root:
            continue
        seen_real.add(real_root)
        entries = [root] if not os.path.isdir(root) or os.path.islink(root) else None
        if entries is None:
            entries = []
            for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
                dirnames[:] = sorted(d for d in dirnames
                                     if not any(os.path.join(dirpath, d).startswith(s) for s in MANIFEST_SKIP))
                entries.append(dirpath)
                entries.extend(os.path.join(dirpath, n) for n in sorted(filenames))
                entries.extend(os.path.join(dirpath, d) for d in dirnames if os.path.islink(os.path.join(dirpath, d)))
        for path in entries:
            if path in manifest:
                continue
            try:
                st = os.lstat(path)
            except OSError:
                continue
            rec = {"mode": oct(stat.S_IMODE(st.st_mode)), "uid": st.st_uid, "gid": st.st_gid}
            if stat.S_ISLNK(st.st_mode):
                rec.update(type="link", target=os.readlink(path))
            elif stat.S_ISDIR(st.st_mode):
                rec["type"] = "dir"
            elif stat.S_ISREG(st.st_mode):
                rec.update(type="file", size=st.st_size)
                if st.st_size <= HASH_MAX_BYTES:
                    rec["sha256"] = sha256_file(path)
                else:
                    rec["mtime"] = int(st.st_mtime)
                # Copy /etc text content for diffs, unless it looks secret
                if path.startswith("/etc/") and st.st_size <= COPY_MAX_BYTES:
                    try:
                        with open(path, "rb") as f:
                            data = f.read()
                    except OSError:
                        data = None
                    if data is not None:
                        dest = etc_out / path[len("/etc/"):]
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        if is_secret(path, data[:65536]):
                            rec["redacted"] = True
                            redacted.append(path)
                            dest.write_text(f"[redacted by state_capture: sha256={rec.get('sha256')}]\n",
                                            encoding="utf-8")
                        else:
                            dest.write_bytes(data)
            else:
                rec["type"] = "other"
            manifest[path] = rec

    (out / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True), encoding="utf-8")
    log(f"manifest: {len(manifest)} entries, {len(redacted)} redacted")


def collect_filelist(out: Path, walk_roots: List[str]) -> None:
    count = 0
    with gzip.open(out / "filelist.tsv.gz", "wt", encoding="utf-8") as f:
        for root in walk_roots:
            try:
                root_dev = os.lstat(root).st_dev
            except OSError:
                continue
            for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
                keep = []
                for d in dirnames:
                    p = os.path.join(dirpath, d)
                    if p in WALK_SKIP:
                        continue
                    try:
                        st = os.lstat(p)
                    except OSError:
                        continue
                    if stat.S_ISLNK(st.st_mode):
                        f.write(f"{p}\tl\t0\n")
                        count += 1
                    elif st.st_dev == root_dev:
                        keep.append(d)
                dirnames[:] = sorted(keep)
                f.write(f"{dirpath}\td\t0\n")
                count += 1
                for n in filenames:
                    p = os.path.join(dirpath, n)
                    try:
                        st = os.lstat(p)
                    except OSError:
                        continue
                    t = "l" if stat.S_ISLNK(st.st_mode) else ("f" if stat.S_ISREG(st.st_mode) else "o")
                    f.write(f"{p}\t{t}\t{st.st_size if t == 'f' else 0}\n")
                    count += 1
    log(f"filelist: {count} paths across {walk_roots}")


def collect_sysctl(out: Path) -> None:
    rc, text, _ = run(["sysctl", "-a"], timeout=60)
    values = {}
    for line in text.splitlines():
        if " = " in line:
            k, v = line.split(" = ", 1)
            values[k.strip()] = " ".join(v.split())
    (out / "sysctl.json").write_text(json.dumps(values, indent=1, sort_keys=True), encoding="utf-8")
    log(f"sysctl: {len(values)} keys")


def collect_modules(out: Path) -> None:
    mods = []
    try:
        for line in Path("/proc/modules").read_text().splitlines():
            mods.append(line.split()[0])
    except OSError:
        pass
    builtin = []
    try:
        builtin = sorted(Path(f"/lib/modules/{platform.release()}/modules.builtin").read_text().split())
    except OSError:
        pass
    (out / "modules.json").write_text(json.dumps({"loaded": sorted(mods), "builtin_count": len(builtin)},
                                                 indent=1), encoding="utf-8")


def collect_packages(out: Path) -> None:
    pkgs = {}
    if shutil.which("dpkg-query"):
        _, text, _ = run(["dpkg-query", "-W", "-f", "${Package}:${Architecture}\t${Version}\t${Status}\n"])
        for line in text.splitlines():
            parts = line.split("\t")
            if len(parts) == 3 and parts[2].endswith(" installed"):
                pkgs[parts[0]] = parts[1]
    elif shutil.which("rpm"):
        _, text, _ = run(["rpm", "-qa", "--qf", "%{NAME}.%{ARCH}\t%{VERSION}-%{RELEASE}\n"])
        for line in text.splitlines():
            parts = line.split("\t")
            if len(parts) == 2:
                pkgs[parts[0]] = parts[1]
    snaps = {}
    if shutil.which("snap"):
        _, text, _ = run(["snap", "list"])
        for line in text.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2:
                snaps[parts[0]] = parts[1]
    (out / "packages.json").write_text(json.dumps({"packages": pkgs, "snaps": snaps}, indent=1, sort_keys=True),
                                       encoding="utf-8")
    log(f"packages: {len(pkgs)} (+{len(snaps)} snaps)")


def collect_units(out: Path) -> None:
    types = "service,socket,timer,mount,swap,target,path,automount"
    files, active = {}, {}
    if shutil.which("systemctl"):
        _, text, _ = run(["systemctl", "list-unit-files", "--no-legend", "--no-pager", f"--type={types}"])
        for line in text.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                files[parts[0]] = parts[1]
        _, text, _ = run(["systemctl", "list-units", "--all", "--no-legend", "--no-pager", "--plain",
                          f"--type={types}"])
        for line in text.splitlines():
            parts = line.split()
            if len(parts) >= 4:
                active[parts[0]] = f"{parts[1]}/{parts[2]}/{parts[3]}"
    (out / "units.json").write_text(json.dumps({"unit_files": files, "units": active}, indent=1, sort_keys=True),
                                    encoding="utf-8")
    log(f"units: {len(files)} unit files, {len(active)} loaded units")


def parse_resolv(text: str) -> dict:
    res = {"nameservers": [], "search": [], "options": [], "domain": None}
    for line in text.splitlines():
        parts = line.split()
        if not parts or parts[0].startswith(("#", ";")):
            continue
        kw = parts[0].lower()
        if kw == "nameserver" and len(parts) > 1:
            res["nameservers"].append(parts[1])
        elif kw == "search":
            res["search"] = parts[1:]
        elif kw == "domain" and len(parts) > 1:
            res["domain"] = parts[1]
        elif kw == "options":
            res["options"].extend(parts[1:])
    return res


def collect_dns(out: Path, fqdn: Optional[str]) -> None:
    dns_dir = out / "dns"
    dns_dir.mkdir(exist_ok=True)
    summary = {"files": {}}
    for path in RESOLVER_FILES:
        entry = {"exists": os.path.lexists(path)}
        if os.path.islink(path):
            entry["link"] = os.readlink(path)
            entry["resolves_to"] = os.path.realpath(path)
        if os.path.isfile(path):
            try:
                text = Path(path).read_text(encoding="utf-8", errors="replace")
                entry.update(parse_resolv(text))
                (dns_dir / path.strip("/").replace("/", "__")).write_text(text, encoding="utf-8")
            except OSError as e:
                entry["error"] = str(e)
        summary["files"][path] = entry

    # Name lookups through the host resolver stack (read-only)
    names = {socket.gethostname(), socket.getfqdn()}
    if fqdn:
        names.update({fqdn, f"state-capture-probe.{fqdn}"})
    lookups = {}
    for name in sorted(n for n in names if n):
        try:
            lookups[name] = sorted({ai[4][0] for ai in socket.getaddrinfo(name, None)})
        except Exception as e:
            lookups[name] = f"error: {e}"
    summary["lookups"] = lookups

    try:
        nss = [l for l in Path("/etc/nsswitch.conf").read_text().splitlines() if l.startswith("hosts:")]
        summary["nsswitch_hosts"] = nss[0] if nss else None
    except OSError:
        summary["nsswitch_hosts"] = None

    cmd = out / "cmd"
    write_cmd(cmd, "resolvectl_status", ["resolvectl", "status", "--no-pager"])
    write_cmd(cmd, "resolvectl_dns", ["resolvectl", "dns"])
    write_cmd(cmd, "resolvectl_domain", ["resolvectl", "domain"])
    write_cmd(cmd, "systemd_resolved_config", ["systemd-analyze", "cat-config", "systemd/resolved.conf"])
    write_cmd(cmd, "networkmanager_config", ["NetworkManager", "--print-config"])
    write_cmd(cmd, "nmcli_general", ["nmcli", "general", "status"])
    write_cmd(cmd, "nmcli_dev_show", ["nmcli", "dev", "show"])
    write_cmd(cmd, "networkctl_list", ["networkctl", "list", "--no-pager"])
    write_cmd(cmd, "netplan_get", ["netplan", "get"])
    for name in sorted(lookups):
        write_cmd(cmd, f"getent_ahosts_{re.sub(r'[^A-Za-z0-9.-]', '_', name)}", ["getent", "ahosts", name])
    (out / "dns.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    log("dns: resolver files, lookups, resolved/NetworkManager/netplan state")


def collect_pod_dns(out: Path) -> None:
    """Copy resolv.conf files that container runtimes generated for pod sandboxes (host files, read-only)."""
    roots = ["/var/lib/containerd", "/run/containerd", "/var/run/containerd", "/var/lib/docker/containers",
             "/data"]
    try:
        cfg = Path("/etc/containerd/config.toml").read_text()
        roots += re.findall(r'^\s*(?:root|state)\s*=\s*"([^"]+)"', cfg, re.M)
    except OSError:
        pass
    found: Dict[str, List[str]] = {}
    for root in dict.fromkeys(roots):
        if not os.path.isdir(root):
            continue
        base_depth = root.rstrip("/").count("/")
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            depth = dirpath.count("/") - base_depth
            # don't descend into image/snapshot stores
            dirnames[:] = [d for d in dirnames
                           if "snapshot" not in d and d not in ("content", "rootfs") and depth < 6]
            if "resolv.conf" in filenames and ("sandboxes" in dirpath or "/containers/" in dirpath):
                p = os.path.join(dirpath, "resolv.conf")
                try:
                    text = Path(p).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                found.setdefault(text, []).append(p)
    if found:
        pod_dir = out / "pod_dns"
        pod_dir.mkdir(exist_ok=True)
        index = []
        for i, (text, paths) in enumerate(sorted(found.items(), key=lambda kv: -len(kv[1]))):
            (pod_dir / f"variant_{i}.conf").write_text(text, encoding="utf-8")
            index.append({"variant": i, "count": len(paths), "parsed": parse_resolv(text), "examples": paths[:3]})
        (pod_dir / "index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
    log(f"pod dns: {sum(len(v) for v in found.values())} sandbox resolv.conf files, {len(found)} variants")


def collect_commands(out: Path) -> None:
    cmd = out / "cmd"
    cmds = {
        "uname": ["uname", "-a"],
        "hostnamectl": ["hostnamectl"],
        "hostname_f": ["hostname", "-f"],
        "timedatectl": ["timedatectl", "show"],
        "ip_addr": ["ip", "-o", "addr"],
        "ip_link": ["ip", "-o", "link"],
        "ip_route": ["ip", "route", "show", "table", "all"],
        "ip6_route": ["ip", "-6", "route"],
        "ip_rule": ["ip", "rule"],
        "ss_listen": ["ss", "-tulpnH"],
        "iptables_version": ["iptables", "-V"],
        "iptables_save": ["iptables-save"],
        "ip6tables_save": ["ip6tables-save"],
        "nft_ruleset": ["nft", "list", "ruleset"],
        "ipvsadm": ["ipvsadm", "-Ln"],
        "systemd_sysctl_config": ["systemd-analyze", "cat-config", "sysctl.d"],
        "modules_load_config": ["systemd-analyze", "cat-config", "modules-load.d"],
        "swapon": ["swapon", "--show"],
        "swap_target": ["systemctl", "show", "swap.target", "-p", "LoadState", "-p", "ActiveState",
                        "-p", "UnitFileState"],
        "findmnt": ["findmnt", "-rn", "-o", "TARGET,SOURCE,FSTYPE,OPTIONS"],
        "lsblk": ["lsblk", "-o", "NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,UUID"],
        "getenforce": ["getenforce"],
        "sestatus": ["sestatus"],
        "aa_status": ["aa-status"],
        "systemctl_failed": ["systemctl", "--failed", "--no-legend", "--no-pager"],
        "processes": ["ps", "-eo", "comm,args", "--sort=comm"],
        "crictl_info": ["crictl", "info"],
        "crictl_pods": ["crictl", "pods"],
        "containerd_config": ["containerd", "config", "dump"],
        "kubelet_version": ["kubelet", "--version"],
        "radm_version": ["radm", "version"],
        "cgroup_fs": ["stat", "-fc", "%T", "/sys/fs/cgroup/"],
    }
    for name, argv in cmds.items():
        write_cmd(cmd, name, argv)
    for name, path in (("proc_cmdline", "/proc/cmdline"),
                       ("apparmor_enabled", "/sys/module/apparmor/parameters/enabled")):
        try:
            cmd.mkdir(parents=True, exist_ok=True)
            (cmd / f"{name}.txt").write_text(Path(path).read_text(), encoding="utf-8")
        except OSError:
            pass
    log(f"commands: {len(list(cmd.glob('*.txt')))} outputs")


SCRIPT_MAX_BYTES = 256 * 1024
SCRIPT_DIRS = [("/opt", 2), ("/usr/local/bin", 1), ("/usr/local/sbin", 1)]
EXEC_RE = re.compile(r"^\s*Exec(?:Start|StartPre|StartPost|Stop|StopPost|Reload|Condition)\s*=\s*[-@:+!]*(\S+)", re.M)


def _is_text_file(path: str) -> bool:
    try:
        st = os.stat(path)
        if not stat.S_ISREG(st.st_mode) or st.st_size > SCRIPT_MAX_BYTES:
            return False
        with open(path, "rb") as f:
            return b"\0" not in f.read(8192)
    except OSError:
        return False


def collect_scripts(out: Path) -> None:
    """Copy small text programs that units, cron jobs and rc.local run, plus text files in /opt and /usr/local.

    Installers often drop shell scripts outside /etc (e.g. /usr/bin/<tool>, /opt/<init>.sh); their content
    explains behaviour that config diffs alone cannot.
    """
    refs: Dict[str, List[str]] = {}

    def ref(path: str, source: str) -> None:
        if os.path.isabs(path):
            refs.setdefault(os.path.realpath(path), []).append(source)

    unit_dirs = ["/etc/systemd/system", "/run/systemd/system"]
    for d in unit_dirs:
        for dirpath, _, filenames in os.walk(d):
            for n in filenames:
                p = os.path.join(dirpath, n)
                if not n.endswith((".service", ".conf", ".timer", ".socket")) or not os.path.isfile(p):
                    continue
                try:
                    for m in EXEC_RE.finditer(Path(p).read_text(errors="replace")):
                        ref(m.group(1), p)
                except OSError:
                    pass

    cron_files = ["/etc/crontab", "/etc/rc.local"]
    for d in ("/etc/cron.d", "/var/spool/cron/crontabs", "/var/spool/cron"):
        if os.path.isdir(d):
            cron_files += [os.path.join(d, n) for n in sorted(os.listdir(d))]
    for cf in cron_files:
        if cf == "/etc/rc.local" and os.path.isfile(cf):
            ref(cf, "rc.local")
        try:
            lines = Path(cf).read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            if line.lstrip().startswith("#"):
                continue
            for tok in re.findall(r"(/[\w./+-]+)", line):
                if os.path.isfile(tok) and not tok.startswith(("/bin/", "/usr/bin/run-parts", "/dev/")):
                    ref(tok, cf)

    for root, max_depth in SCRIPT_DIRS:
        if not os.path.isdir(root):
            continue
        base = root.rstrip("/").count("/")
        for dirpath, dirnames, filenames in os.walk(root):
            if dirpath.count("/") - base >= max_depth:
                dirnames[:] = []
            for n in filenames:
                refs.setdefault(os.path.join(dirpath, n), []).append(f"dir:{root}")

    index = {}
    dest_root = out / "scripts"
    for path in sorted(refs):
        if path.startswith("/etc/") or not _is_text_file(path):
            continue  # /etc is copied already; binaries are hashed in the manifest
        data = Path(path).read_bytes()
        only_dir_scan = all(r.startswith("dir:") for r in refs[path])
        if only_dir_scan and not (data.startswith(b"#!") or os.access(path, os.X_OK)):
            continue  # LICENSE/README-style files found by the directory scan
        dest = dest_root / path.lstrip("/")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(scrub(data.decode("utf-8", errors="replace")), encoding="utf-8")
        index[path] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data),
                       "referenced_by": sorted(set(refs[path]))}
    # Referenced binaries: record hashes so changes still show up
    binaries = {p: {"sha256": sha256_file(p) if os.path.getsize(p) <= HASH_MAX_BYTES else None,
                    "size": os.path.getsize(p), "referenced_by": sorted(set(r))}
                for p, r in refs.items()
                if p not in index and not p.startswith("/etc/") and os.path.isfile(p)
                and any(not x.startswith("dir:") for x in r)}
    (out / "scripts.json").write_text(json.dumps({"scripts": index, "binaries": binaries}, indent=1, sort_keys=True),
                                      encoding="utf-8")
    log(f"scripts: {len(index)} text programs copied, {len(binaries)} referenced binaries hashed")


def find_kubelet() -> Tuple[Optional[List[str]], Optional[str]]:
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            if Path(f"/proc/{pid}/comm").read_text().strip() != "kubelet":
                continue
            args = Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")
            args = [a.decode(errors="replace") for a in args if a]
        except OSError:
            continue
        config = None
        for i, a in enumerate(args):
            if a.startswith("--config="):
                config = a.split("=", 1)[1]
            elif a == "--config" and i + 1 < len(args):
                config = args[i + 1]
        return args, config
    return None, None


def collect_kube(out: Path) -> None:
    kube = out / "kube"
    args, config_path = find_kubelet()
    if args:
        kube.mkdir(exist_ok=True)
        (kube / "kubelet_cmdline.txt").write_text(scrub("\n".join(args) + "\n"), encoding="utf-8")
        for p in [config_path, "/var/lib/kubelet/config.yaml", "/var/lib/kubelet/kubeadm-flags.env"]:
            if p and os.path.isfile(p):
                data = Path(p).read_bytes()
                name = "kubelet_" + p.strip("/").replace("/", "__")
                (kube / name).write_text(scrub(data.decode("utf-8", errors="replace")), encoding="utf-8")

    kubectl = shutil.which("kubectl") or next(
        (p for p in ("/usr/local/bin/kubectl", "/usr/bin/kubectl", "/opt/rafay/bin/kubectl") if os.path.isfile(p)),
        None)
    if not kubectl:
        log("kube: kubectl not found (skipping cluster queries)")
        return
    env = dict(os.environ)
    if not env.get("KUBECONFIG"):
        for p in ("/etc/kubernetes/admin.conf", "/root/.kube/config"):
            if os.path.isfile(p):
                env["KUBECONFIG"] = p
                break
    k = [kubectl, "--request-timeout=15s"]
    rc, _, _ = run(k + ["get", "--raw", "/readyz"], env=env, timeout=20)
    if rc != 0:
        log("kube: API not reachable (skipping cluster queries)")
        return
    kube.mkdir(exist_ok=True)
    queries = {
        "version": ["version", "-o", "yaml"],
        "nodes": ["get", "nodes", "-o", "wide"],
        "namespaces": ["get", "ns"],
        "workloads": ["get", "deploy,ds,sts", "-A", "-o", "wide"],
        "services_kube_system": ["get", "svc", "-n", "kube-system", "-o", "wide"],
        "pods": ["get", "pods", "-A", "-o", "wide"],
        "configmap_names": ["get", "cm", "-A", "-o", "name"],
    }
    for name, q in queries.items():
        write_cmd(kube, name, k + q, env=env)
    # DNS / proxy related configmaps, wherever they live
    _, text, _ = run(k + ["get", "cm", "-A", "-o", "custom-columns=NS:.metadata.namespace,NAME:.metadata.name",
                          "--no-headers"], env=env)
    for line in text.splitlines():
        parts = line.split()
        if len(parts) == 2 and re.search(r"coredns|kube-proxy|nodelocal|dns|kubelet-config|kubeadm-config", parts[1]):
            write_cmd(kube, f"cm_{parts[0]}_{parts[1]}", k + ["get", "cm", "-n", parts[0], parts[1], "-o", "yaml"],
                      env=env)
    # Effective kubelet config straight from each kubelet (GET only)
    _, text, _ = run(k + ["get", "nodes", "-o", "name"], env=env)
    for node in text.split():
        node = node.split("/", 1)[-1]
        write_cmd(kube, f"configz_{node}", k + ["get", "--raw", f"/api/v1/nodes/{node}/proxy/configz"], env=env)
    log("kube: cluster version, workloads, DNS/proxy configmaps, kubelet configz")


def capture(label: str, out_root: Path, fqdn: Optional[str], walk_roots: List[str],
            skip_walk: bool, keep_dir: bool) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    name = f"{label}_{socket.gethostname()}_{stamp}"
    out = out_root / name
    new_root = not out_root.exists()
    out.mkdir(parents=True, exist_ok=False)
    if new_root:
        hand_back(out_root)
    started = time.time()
    print(f">>> Capturing host state '{label}' -> {out}", file=sys.stderr)

    collect_meta(out, label, {"fqdn": fqdn, "walk_roots": walk_roots, "skip_walk": skip_walk})
    collect_etc_and_manifest(out)
    if not skip_walk:
        collect_filelist(out, walk_roots)
    collect_sysctl(out)
    collect_modules(out)
    collect_packages(out)
    collect_units(out)
    collect_dns(out, fqdn)
    collect_pod_dns(out)
    collect_scripts(out)
    collect_commands(out)
    collect_kube(out)

    tarball = out_root / f"{name}.tar.gz"
    shutil.make_archive(str(out_root / name), "gztar", root_dir=str(out_root), base_dir=name)
    hand_back(tarball)
    if not keep_dir:
        shutil.rmtree(out)
    else:
        hand_back(out)
    print(f">>> Done in {time.time() - started:.0f}s: {tarball}", file=sys.stderr)
    return tarball
