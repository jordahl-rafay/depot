"""Secret detection and scrubbing shared by capture (files, command output) and diff (report text)."""

import os
import re

SECRET_NAMES = {"shadow", "shadow-", "gshadow", "gshadow-", "opasswd", "htpasswd", ".htpasswd"}
SECRET_NAME_RE = re.compile(r"(^ssh_host_.*_key$)|\.key$|password|secret|credential|token", re.I)
SECRET_DIRS = ("/ssl/private", "/rafay-auth", "/etc/kubernetes/pki", "/var/lib/kubelet/pki")

_KEYS = r"token|password|passwd|secret|client[-_]secret|api[-_]?key|bearer|auth|client-key-data|private[-_]?key"

# Whole-file markers: any hit means the file is not copied verbatim
SECRET_CONTENT = re.compile(
    rb"PRIVATE KEY|BEGIN OPENSSH|client-key-data"
    rb"|^[ \t]*[\"']?(?:" + _KEYS.encode() + rb")[\"']?[ \t]*[:=][ \t]*\S"
    rb"|\$2[aby]\$\d\d\$|\$[156]\$[^\s:$]+\$"           # bcrypt / crypt(3) hashes
    rb"|eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}",  # JWTs
    re.I | re.M,
)

# Value scrubbers for text that is kept (command output, kubectl output, rendered reports)
_SCRUBBERS = [
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S),
     "[redacted private key]"),
    (re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]*"), "[redacted jwt]"),
    (re.compile(r"\$2[aby]\$\d\d\$[./A-Za-z0-9]{20,}"), "[redacted hash]"),
    (re.compile(r"\$[156]\$[^\s:$]+\$[./A-Za-z0-9]{20,}"), "[redacted hash]"),
    (re.compile(r"(?im)^([ \t]*[-+]?[ \t]*[\"']?(?:" + _KEYS + r")[\"']?[ \t]*[:=][ \t]*)(?![\"']?[ \t]*$)(\S.*)$"),
     r"\1[redacted]"),
]


def is_secret_file(path: str, head: bytes) -> bool:
    name = os.path.basename(path)
    if name in SECRET_NAMES or SECRET_NAME_RE.search(name):
        return True
    if any(d in path for d in SECRET_DIRS) or ("/pki/" in path and name.endswith((".key", ".pem"))):
        return True
    return bool(SECRET_CONTENT.search(head))


def scrub(text: str) -> str:
    for pattern, repl in _SCRUBBERS:
        text = pattern.sub(repl, text)
    return text
