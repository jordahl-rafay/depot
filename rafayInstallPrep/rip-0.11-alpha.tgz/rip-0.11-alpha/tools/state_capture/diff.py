"""Compare two state captures and render a Markdown report (DNS first)."""

import difflib
import gzip
import json
import re
import shutil
import tarfile
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from tools.state_capture.redact import scrub

# --- Noise filters ----------------------------------------------------------------

VOLATILE_SYSCTL = re.compile(
    r"^(kernel\.random\.|fs\.(dentry-state|inode-nr|inode-state|file-nr|aio-nr|quota\.)|kernel\.ns_last_pid|"
    r"kernel\.pty\.nr|net\.netfilter\.nf_conntrack_count|kernel\.sched_domain\.|"
    r"kernel\.perf_event_max_sample_rate|dev\.cdrom\.|fs\.binfmt_misc\.|kernel\.hostname$|kernel\.domainname$|"
    r"net\.ipv4\.tcp_mem|net\.ipv4\.udp_mem|vm\.stat_)"
)
IFACE_SYSCTL = re.compile(r"^net\.(ipv4|ipv6)\.(conf|neigh)\.([^.]+)\.")
NOISY_UNITS = re.compile(
    r"^(run-.*\.mount|var-lib-kubelet-pods-.*\.mount|.*-overlay.*\.mount|run-netns-.*|run-containerd-.*|"
    r"var-lib-containerd-.*\.mount|session-\d+\.scope|user@\d+\.service|user-runtime-dir@\d+\.service|"
    r"snap-.*\.mount|cri-containerd-.*|docker-.*\.scope|.*\.scope)$"
)
VOLATILE_FILES = re.compile(
    r"^/etc/(ld\.so\.cache|adjtime|\.pwd\.lock|mtab|machine-info)$|~$|\.swp$|"
    r"^/var/lib/kubelet/(cpu_manager_state|memory_manager_state|device-plugins/kubelet_internal_checkpoint)$"
)
# Paths summarised elsewhere in the report
FILELIST_IGNORE = re.compile(r"^/(etc|var/lib/kubelet/pods|var/lib/containerd|var/lib/docker)(/|$)")

IMPORTANT_CMDS = [
    "iptables_save", "nft_ruleset", "ipvsadm", "ip_route", "ip_rule", "ip_addr", "ss_listen",
    "systemd_sysctl_config", "modules_load_config", "swapon", "swap_target", "getenforce", "aa_status",
    "proc_cmdline", "apparmor_enabled", "hostnamectl", "hostname_f", "findmnt", "containerd_config",
    "crictl_info", "kubelet_version", "radm_version", "cgroup_fs", "processes",
]
DNS_CMDS = ["resolvectl_status", "resolvectl_dns", "resolvectl_domain", "systemd_resolved_config",
            "networkmanager_config", "nmcli_dev_show", "networkctl_list", "netplan_get"]


def _normalize(name: str, text: str) -> str:
    lines = text.splitlines()
    if lines and lines[0].startswith("$ "):
        lines = lines[1:]  # command echo
    out = []
    for l in lines:
        if name.startswith(("iptables_save", "ip6tables_save")):
            if l.startswith("#"):
                continue
            l = re.sub(r"\[\d+:\d+\]", "[0:0]", l)
        elif name == "ss_listen":
            l = re.sub(r"pid=\d+,fd=\d+", "pid=*", l)
        elif name in ("ip_addr", "ip_link"):
            l = re.sub(r"(valid_lft|preferred_lft) \d+sec", r"\1 *", l)
        elif name == "timedatectl":
            if re.match(r"^(TimeUSec|RTCTimeUSec|NTPSynchronized)=", l):
                continue
        elif name == "processes":
            l = " ".join(l.split()[:1])  # command name only
        elif name in ("crictl_pods", "pods", "workloads"):
            l = re.sub(r"\b\d+[smhd](\d+[smh])?\b", "<age>", l)
        out.append(l.rstrip())
    if name == "processes":
        out = sorted(set(out))
    return "\n".join(out) + "\n"


# --- Capture loading --------------------------------------------------------------

class Capture:
    def __init__(self, path: Path, tmp_root: Path):
        if path.is_file():
            with tarfile.open(path, "r:gz") as tar:
                try:
                    tar.extractall(tmp_root, filter="data")
                except TypeError:  # Python < 3.12
                    tar.extractall(tmp_root)
            dirs = [d for d in tmp_root.iterdir() if d.is_dir()]
            if len(dirs) != 1:
                raise ValueError(f"{path}: unexpected archive layout")
            self.root = dirs[0]
        else:
            self.root = path
        self.meta = self.json("meta.json") or {}
        self.label = self.meta.get("label", self.root.name)

    def json(self, name: str):
        p = self.root / name
        if not p.is_file():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

    def text(self, rel: str) -> Optional[str]:
        p = self.root / rel
        return p.read_text(encoding="utf-8", errors="replace") if p.is_file() else None

    def filelist(self) -> Dict[str, str]:
        p = self.root / "filelist.tsv.gz"
        entries = {}
        if p.is_file():
            with gzip.open(p, "rt", encoding="utf-8") as f:
                for line in f:
                    parts = line.rstrip("\n").split("\t")
                    if len(parts) == 3:
                        entries[parts[0]] = parts[1]
        return entries


# --- Report builder ---------------------------------------------------------------

class Report:
    def __init__(self, max_lines: int):
        self.lines: List[str] = []
        self.summary: List[Tuple[str, str]] = []
        self.max_lines = max_lines

    def h(self, level: int, text: str) -> None:
        self.lines += ["", "#" * level + " " + text, ""]

    def p(self, text: str = "") -> None:
        self.lines.append(text)

    def table(self, headers: List[str], rows: List[List[str]]) -> None:
        if not rows:
            return
        self.p("| " + " | ".join(headers) + " |")
        self.p("|" + "---|" * len(headers))
        for r in rows:
            self.p("| " + " | ".join(str(c).replace("|", "\\|").replace("\n", " ") for c in r) + " |")
        self.p()

    def diff(self, a: str, b: str, a_name: str, b_name: str) -> int:
        d = list(difflib.unified_diff(a.splitlines(), b.splitlines(), a_name, b_name, lineterm="", n=2))
        if not d:
            return 0
        shown = d[: self.max_lines]
        self.p("```diff")
        self.lines += shown
        if len(d) > len(shown):
            self.p(f"... ({len(d) - len(shown)} more diff lines truncated; raise --max-diff-lines)")
        self.p("```")
        return len(d)

    def block(self, text: str, lang: str = "") -> None:
        lines = text.rstrip("\n").splitlines()
        self.p(f"```{lang}")
        self.lines += lines[: self.max_lines]
        if len(lines) > self.max_lines:
            self.p(f"... ({len(lines) - self.max_lines} more lines)")
        self.p("```")


def _fmt(v) -> str:
    if v is None:
        return "—"
    if isinstance(v, list):
        return " ".join(v) if v else "(none)"
    return str(v)


# --- Sections ---------------------------------------------------------------------

def section_dns(r: Report, a: Capture, b: Capture) -> None:
    r.h(2, "DNS & name resolution")
    da, db = a.json("dns.json") or {}, b.json("dns.json") or {}
    fa, fb = da.get("files", {}), db.get("files", {})
    rows, changes = [], 0
    for path in sorted(set(fa) | set(fb)):
        ea, eb = fa.get(path, {}), fb.get(path, {})
        for key in ("exists", "link", "resolves_to", "nameservers", "search", "domain", "options"):
            va, vb = ea.get(key), eb.get(key)
            if va != vb:
                rows.append([f"`{path}`", key, _fmt(va), _fmt(vb)])
                changes += 1
    if rows:
        r.p("**Resolver files**")
        r.p()
        r.table(["File", "Field", a.label, b.label], rows)
    else:
        r.p("Resolver files: no change in links, nameservers, search domains or options.")
        r.p()

    # current state for reference (always useful for the 'what does radm do by default' question)
    r.p(f"**State in {b.label}**")
    r.p()
    r.table(["File", "Link -> target", "Nameservers", "Search", "Options"],
            [[f"`{p}`", f"{e.get('link', '')} -> {e.get('resolves_to', '')}" if e.get("link") else
              ("missing" if not e.get("exists") else "regular file"),
              _fmt(e.get("nameservers")), _fmt(e.get("search")), _fmt(e.get("options"))]
             for p, e in sorted(fb.items())])

    la, lb = da.get("lookups", {}), db.get("lookups", {})
    lrows = [[f"`{n}`", _fmt(la.get(n)), _fmt(lb.get(n))] for n in sorted(set(la) | set(lb)) if la.get(n) != lb.get(n)]
    if lrows:
        r.p("**Host lookups (getaddrinfo) that changed**")
        r.p()
        r.table(["Name", a.label, b.label], lrows)
        changes += len(lrows)
    if da.get("nsswitch_hosts") != db.get("nsswitch_hosts"):
        r.p(f"**nsswitch hosts:** `{da.get('nsswitch_hosts')}` -> `{db.get('nsswitch_hosts')}`")
        changes += 1

    for name in DNS_CMDS:
        ta, tb = a.text(f"cmd/{name}.txt"), b.text(f"cmd/{name}.txt")
        if ta is None and tb is None:
            continue
        na, nb = _normalize(name, ta or ""), _normalize(name, tb or "")
        if na != nb:
            r.p(f"**`{name}`**")
            r.diff(na, nb, a.label, b.label)
            changes += 1

    pod_a, pod_b = a.json("pod_dns/index.json") or [], b.json("pod_dns/index.json") or []
    if pod_b or pod_a:
        r.p(f"**Pod sandbox resolv.conf ({b.label})**: what the kubelet actually handed to pods")
        r.p()
        for v in pod_b:
            r.p(f"Variant {v['variant']}: used by {v['count']} sandbox(es), e.g. `{v['examples'][0]}`")
            r.block(b.text(f"pod_dns/variant_{v['variant']}.conf") or "")
        if not pod_b:
            r.p("(none found)")
    r.summary.append(("DNS & resolution", f"{changes} change(s)"))


def section_packages(r: Report, a: Capture, b: Capture) -> None:
    pa, pb = (a.json("packages.json") or {}), (b.json("packages.json") or {})
    r.h(2, "Packages")
    total = 0
    for kind in ("packages", "snaps"):
        xa, xb = pa.get(kind, {}), pb.get(kind, {})
        added = sorted(set(xb) - set(xa))
        removed = sorted(set(xa) - set(xb))
        changed = sorted(k for k in set(xa) & set(xb) if xa[k] != xb[k])
        total += len(added) + len(removed) + len(changed)
        rows = [[k, "added", "", xb[k]] for k in added] + [[k, "removed", xa[k], ""] for k in removed] + \
               [[k, "changed", xa[k], xb[k]] for k in changed]
        if rows:
            r.p(f"**{kind}**: {len(added)} added, {len(removed)} removed, {len(changed)} version changes")
            r.p()
            r.table(["Name", "Change", a.label, b.label], rows)
    if not total:
        r.p("No package changes.")
    r.summary.append(("Packages", f"{total} change(s)"))


def section_units(r: Report, a: Capture, b: Capture) -> None:
    ua, ub = a.json("units.json") or {}, b.json("units.json") or {}
    r.h(2, "systemd units")
    fa, fb = ua.get("unit_files", {}), ub.get("unit_files", {})
    rows = []
    for u in sorted(set(fa) | set(fb)):
        if fa.get(u) != fb.get(u) and not NOISY_UNITS.match(u):
            rows.append([f"`{u}`", fa.get(u, "—"), fb.get(u, "—")])
    if rows:
        r.p("**Unit files (enablement)**")
        r.p()
        r.table(["Unit", a.label, b.label], rows)
    sa, sb = ua.get("units", {}), ub.get("units", {})
    noisy = 0
    srows = []
    for u in sorted(set(sa) | set(sb)):
        if sa.get(u) == sb.get(u):
            continue
        if NOISY_UNITS.match(u):
            noisy += 1
            continue
        srows.append([f"`{u}`", sa.get(u, "—"), sb.get(u, "—")])
    if srows:
        r.p("**Runtime state (load/active/sub)**")
        r.p()
        r.table(["Unit", a.label, b.label], srows)
    if noisy:
        r.p(f"({noisy} container/session/mount scope units changed; omitted as noise)")
    if not rows and not srows:
        r.p("No unit changes.")
    r.summary.append(("systemd units", f"{len(rows)} enablement, {len(srows)} runtime change(s)"))


def section_sysctl(r: Report, a: Capture, b: Capture) -> None:
    sa, sb = a.json("sysctl.json") or {}, b.json("sysctl.json") or {}
    r.h(2, "Kernel parameters (sysctl)")
    ifaces_a = {m.group(3) for k in sa for m in [IFACE_SYSCTL.match(k)] if m}
    new_iface_keys = Counter()
    rows = []
    for k in sorted(set(sa) | set(sb)):
        if VOLATILE_SYSCTL.match(k) or sa.get(k) == sb.get(k):
            continue
        m = IFACE_SYSCTL.match(k)
        if m and m.group(3) not in ("all", "default") and m.group(3) not in ifaces_a and k not in sa:
            new_iface_keys[m.group(3)] += 1
            continue
        if m and m.group(3) not in ("all", "default") and k not in sb:
            continue  # interface went away
        rows.append([f"`{k}`", sa.get(k, "—"), sb.get(k, "—")])
    r.table(["Key", a.label, b.label], rows)
    if new_iface_keys:
        names = ", ".join(sorted(new_iface_keys)[:15]) + (" ..." if len(new_iface_keys) > 15 else "")
        r.p(f"({sum(new_iface_keys.values())} keys for {len(new_iface_keys)} new interfaces omitted: {names})")
    if not rows:
        r.p("No sysctl changes (excluding volatile counters).")
    r.p()
    r.p("Where persistent sysctls come from: see `systemd_sysctl_config` under Commands and new files under "
        "`/etc/sysctl.d` / `/usr/lib/sysctl.d` in Files.")
    r.summary.append(("sysctl", f"{len(rows)} change(s)"))


def section_modules(r: Report, a: Capture, b: Capture) -> None:
    ma, mb = set((a.json("modules.json") or {}).get("loaded", [])), set((b.json("modules.json") or {}).get("loaded", []))
    r.h(2, "Kernel modules (loaded)")
    added, removed = sorted(mb - ma), sorted(ma - mb)
    if added:
        r.p("Loaded: " + ", ".join(f"`{m}`" for m in added))
    if removed:
        r.p("Unloaded: " + ", ".join(f"`{m}`" for m in removed))
    if not added and not removed:
        r.p("No module changes.")
    r.p()
    r.p("Persistence: compare with `modules_load_config` under Commands (runtime-only modules vanish after reboot).")
    r.summary.append(("Kernel modules", f"+{len(added)} / -{len(removed)}"))


def section_files(r: Report, a: Capture, b: Capture) -> None:
    ma, mb = a.json("manifest.json") or {}, b.json("manifest.json") or {}
    r.h(2, "Configuration files (watched roots)")
    added = [p for p in sorted(set(mb) - set(ma)) if not VOLATILE_FILES.search(p)]
    removed = [p for p in sorted(set(ma) - set(mb)) if not VOLATILE_FILES.search(p)]
    changed = []
    for p in sorted(set(ma) & set(mb)):
        if VOLATILE_FILES.search(p):
            continue
        ea, eb = ma[p], mb[p]
        fields = [f for f in ("type", "sha256", "target", "mode", "uid", "gid", "size", "mtime")
                  if ea.get(f) != eb.get(f) and not (f in ("size", "mtime") and ea.get("sha256"))]
        if fields and not (fields == ["mtime"] and ea.get("type") == "dir"):
            changed.append((p, fields))

    def by_top(paths):
        groups = defaultdict(list)
        for p in paths:
            groups["/".join(p.split("/")[:4])].append(p)
        return groups

    r.p(f"{len(added)} added, {len(removed)} removed, {len(changed)} changed.")
    if added:
        r.h(3, "Added")
        for top, paths in sorted(by_top(added).items()):
            files = [p for p in paths if mb[p].get("type") != "dir"]
            if not files:
                continue
            r.p(f"- `{top}`: {len(files)} file(s)")
            for p in files[:40]:
                e = mb[p]
                extra = f" -> `{e['target']}`" if e.get("type") == "link" else f" ({e.get('size', 0)} B, {e.get('mode')})"
                r.p(f"  - `{p}`{extra}")
            if len(files) > 40:
                r.p(f"  - ... {len(files) - 40} more")
        # Show the content of small new /etc files: these are usually the interesting ones
        shown = 0
        for p in added:
            if p.startswith("/etc/") and mb[p].get("type") == "file" and shown < 60:
                text = b.text("etc/" + p[len("/etc/"):])
                if text is not None and len(text) < 20000 and "\0" not in text:
                    r.p()
                    r.p(f"**New: `{p}`**")
                    r.block(text)
                    shown += 1
    if removed:
        r.h(3, "Removed")
        for p in removed[:200]:
            r.p(f"- `{p}`")
    if changed:
        r.h(3, "Changed")
        for p, fields in changed:
            ea, eb = ma[p], mb[p]
            meta_bits = ", ".join(f"{f}: {ea.get(f)} -> {eb.get(f)}" for f in fields if f not in ("sha256",))
            r.p(f"- `{p}` ({', '.join(fields)}){'  ' + meta_bits if meta_bits else ''}")
            if "sha256" in fields and p.startswith("/etc/"):
                ta, tb = a.text("etc/" + p[len("/etc/"):]), b.text("etc/" + p[len("/etc/"):])
                if ta is not None and tb is not None and "\0" not in ta + tb:
                    r.diff(ta, tb, f"{a.label}:{p}", f"{b.label}:{p}")
    r.summary.append(("Config files", f"+{len(added)} / -{len(removed)} / ~{len(changed)}"))


def section_scripts(r: Report, a: Capture, b: Capture) -> None:
    sa, sb = a.json("scripts.json") or {}, b.json("scripts.json") or {}
    if not sb:
        return
    r.h(2, "Scripts & programs run by units / cron / rc.local")
    xa, xb = sa.get("scripts", {}), sb.get("scripts", {})
    added = sorted(set(xb) - set(xa))
    removed = sorted(set(xa) - set(xb))
    changed = sorted(p for p in set(xa) & set(xb) if xa[p]["sha256"] != xb[p]["sha256"])
    for p in added:
        r.p()
        r.p(f"**New: `{p}`** (run by: {', '.join(f'`{x}`' for x in xb[p]['referenced_by'])})")
        r.block(b.text("scripts/" + p.lstrip("/")) or "")
    for p in changed:
        r.p()
        r.p(f"**Changed: `{p}`**")
        r.diff(a.text("scripts/" + p.lstrip("/")) or "", b.text("scripts/" + p.lstrip("/")) or "", a.label, b.label)
    if removed:
        r.p()
        r.p("Removed: " + ", ".join(f"`{p}`" for p in removed))
    ba, bb = sa.get("binaries", {}), sb.get("binaries", {})
    rows = [[f"`{p}`", "new" if p not in ba else "changed", ", ".join(bb[p]["referenced_by"])]
            for p in sorted(bb) if p not in ba or ba[p].get("sha256") != bb[p].get("sha256")]
    if rows:
        r.p()
        r.p("**Referenced binaries (hash only)**")
        r.p()
        r.table(["Binary", "Change", "Run by"], rows)
    if not (added or changed or removed or rows):
        r.p("No changes.")
    r.summary.append(("Scripts/programs", f"+{len(added)} / ~{len(changed)} / -{len(removed)}, {len(rows)} binaries"))


def section_filelist(r: Report, a: Capture, b: Capture, depth: int) -> None:
    la, lb = a.filelist(), b.filelist()
    r.h(2, "Filesystem (catch-all, outside watched roots)")
    if not la or not lb:
        r.p("Filesystem walk not present in one of the captures.")
        r.summary.append(("Filesystem", "n/a"))
        return
    added = [p for p in set(lb) - set(la) if not FILELIST_IGNORE.match(p)]
    removed = [p for p in set(la) - set(lb) if not FILELIST_IGNORE.match(p)]

    def groups(paths):
        c = Counter()
        samples = defaultdict(list)
        for p in paths:
            key = "/".join(p.split("/")[: depth + 1]) or "/"
            c[key] += 1
            if len(samples[key]) < 3:
                samples[key].append(p)
        return c, samples

    for title, paths in (("Added", added), ("Removed", removed)):
        c, samples = groups(paths)
        if not c:
            continue
        r.p(f"**{title}: {len(paths)} paths in {len(c)} directories** (top 50 by count)")
        r.p()
        r.table(["Directory", "Paths", "Examples"],
                [[f"`{k}`", n, ", ".join(f"`{s}`" for s in sorted(samples[k]))] for k, n in c.most_common(50)])
    if not added and not removed:
        r.p("No changes outside watched roots.")
    r.summary.append(("Filesystem", f"+{len(added)} / -{len(removed)} paths"))


def section_commands(r: Report, a: Capture, b: Capture) -> None:
    r.h(2, "Runtime state (commands)")
    names = sorted({p.stem for c in (a, b) for p in (c.root / "cmd").glob("*.txt")})
    names = [n for n in IMPORTANT_CMDS if n in names] + [n for n in names if n not in IMPORTANT_CMDS]
    changed = 0
    for name in names:
        if name in DNS_CMDS or name.startswith("getent_"):
            continue
        ta, tb = a.text(f"cmd/{name}.txt"), b.text(f"cmd/{name}.txt")
        na, nb = _normalize(name, ta or ""), _normalize(name, tb or "")
        if na == nb:
            continue
        changed += 1
        r.h(3, f"`{name}`")
        if ta is None:
            r.p(f"(only in {b.label})")
            r.block(nb)
        elif tb is None:
            r.p(f"(only in {a.label})")
        else:
            r.diff(na, nb, a.label, b.label)
    if not changed:
        r.p("No runtime changes.")
    r.summary.append(("Runtime commands", f"{changed} changed"))


def section_kube(r: Report, a: Capture, b: Capture) -> None:
    kb = sorted(p.name for p in (b.root / "kube").glob("*")) if (b.root / "kube").is_dir() else []
    if not kb:
        return
    r.h(2, f"Kubernetes ({b.label})")
    priority = [n for n in kb if re.search(r"kubelet_|configz|coredns|kube-proxy|nodelocal|version", n)]
    rest = [n for n in kb if n not in priority]
    for name in priority + rest:
        ta, tb = a.text(f"kube/{name}"), b.text(f"kube/{name}")
        r.h(3, f"`{name}`")
        if ta is not None:
            if not r.diff(_normalize(Path(name).stem, ta), _normalize(Path(name).stem, tb or ""), a.label, b.label):
                r.p("(unchanged)")
        else:
            r.block(tb or "")
    r.summary.append(("Kubernetes", f"{len(kb)} item(s) captured"))


def render(a_path: Path, b_path: Path, max_lines: int = 200, depth: int = 3) -> str:
    tmp = Path(tempfile.mkdtemp(prefix="state_diff_"))
    try:
        (tmp / "a").mkdir()
        (tmp / "b").mkdir()
        a = Capture(a_path, tmp / "a")
        b = Capture(b_path, tmp / "b")
        r = Report(max_lines)
        for fn in (section_dns, section_packages, section_units, section_sysctl, section_modules, section_files):
            fn(r, a, b)
        section_scripts(r, a, b)
        section_filelist(r, a, b, depth)
        section_commands(r, a, b)
        section_kube(r, a, b)

        head = [
            f"# Host state diff: {a.label} -> {b.label}",
            "",
            "| | " + a.label + " | " + b.label + " |",
            "|---|---|---|",
        ]
        for key in ("hostname", "captured_at", "os", "kernel"):
            head.append(f"| {key} | {a.meta.get(key, '')} | {b.meta.get(key, '')} |")
        head += ["", "## Summary", "", "| Area | Changes |", "|---|---|"]
        head += [f"| {k} | {v} |" for k, v in r.summary]
        # Defense in depth: captures taken by older versions may hold unredacted values
        return scrub("\n".join(head + r.lines) + "\n")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
