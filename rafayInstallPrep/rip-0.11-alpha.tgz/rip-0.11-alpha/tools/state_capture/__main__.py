"""Entrypoint for python3 -m tools.state_capture."""

from tools.state_capture.cli import main

if __name__ == "__main__":
    main()
