"""Host state capture & diff: records configuration/runtime state at install stages for comparison."""
