"""CLI for host state capture & diff.

  sudo python3 -m tools.state_capture capture --label S0 [--fqdn rctrl01.rafay.lab]
  python3 -m tools.state_capture diff S0.tar.gz S1.tar.gz [-o S0-S1.md]
  python3 -m tools.state_capture list
"""

import argparse
import os
import sys
from pathlib import Path

from tools.common.ownership import write_text
from tools.config_loader import get_merged_config
from tools.state_capture.collect import capture
from tools.state_capture.diff import render

DEFAULT_OUT = Path("rafayInstallPrep/state")


def main():
    parser = argparse.ArgumentParser(
        description="Capture host configuration/runtime state at install stages and diff the captures (read-only)"
    )
    sub = parser.add_subparsers(dest="command")

    c = sub.add_parser("capture", help="Record the current host state into a .tar.gz")
    c.add_argument("--label", required=True, help="Stage label, e.g. S0 (pristine), S1 (after prep), S2 (after radm)")
    c.add_argument("--out-dir", type=Path, default=DEFAULT_OUT, help=f"Where to write captures (default: {DEFAULT_OUT})")
    c.add_argument("-f", "--fqdn", help="Controller FQDN to test through the host resolver (default: from config)")
    c.add_argument("--config", type=Path, default=Path("rafay_prep_config.json"))
    c.add_argument("--walk-root", action="append", default=None,
                   help="Filesystem root for the catch-all walk (repeatable; default: / and /data if mounted)")
    c.add_argument("--no-walk", action="store_true", help="Skip the catch-all filesystem walk (faster)")
    c.add_argument("--keep-dir", action="store_true", help="Keep the uncompressed capture directory")

    d = sub.add_parser("diff", help="Compare two captures (tar.gz or directory) and write a Markdown report")
    d.add_argument("before", type=Path)
    d.add_argument("after", type=Path)
    d.add_argument("-o", "--output", type=Path, help="Write the report here instead of stdout")
    d.add_argument("--max-diff-lines", type=int, default=200, help="Truncate each text diff (default: 200)")
    d.add_argument("--depth", type=int, default=3, help="Directory depth for grouping filesystem changes")

    ls = sub.add_parser("list", help="List captures in the output directory")
    ls.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)

    args = parser.parse_args()

    if args.command == "capture":
        if os.geteuid() != 0:
            print("WARNING: not running as root; some files and commands (aa-status, ss -p, /etc/shadow-like "
                  "files, containerd state) will be incomplete. Re-run with sudo.", file=sys.stderr)
        fqdn = args.fqdn or get_merged_config(args.config).get("controller", {}).get("fqdn")
        walk = args.walk_root or ["/"] + (["/data"] if os.path.ismount("/data") else [])
        capture(args.label, args.out_dir, fqdn, walk, args.no_walk, args.keep_dir)
    elif args.command == "diff":
        report = render(args.before, args.after, args.max_diff_lines, args.depth)
        if args.output:
            write_text(args.output, report)
            print(f"Report written to {args.output}", file=sys.stderr)
        else:
            print(report)
    elif args.command == "list":
        for p in sorted(args.out_dir.glob("*.tar.gz")):
            print(f"{p}  ({p.stat().st_size // 1024} KiB)")
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
