"""Structured report collector for terminal rendering and JSON export."""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import json
from typing import List, Optional, Dict, Any

from tools.common.colors import (
    bold, cyan, blue, dim, white,
    status_pass, status_fail, status_warn, status_info,
)


@dataclass
class CheckItem:
    name: str
    status: str  # "PASS", "WARN", "FAIL", "INFO"
    detail: str
    expected: Optional[str] = None
    actual: Optional[str] = None
    why: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    fix: Optional[str] = None   # exact commands / steps to correct a FAIL or WARN (shown only for those)

    def render(self) -> str:
        """Render a human-readable, colorized check item."""
        lines = []
        if self.status == "PASS":
            badge = status_pass()
        elif self.status == "WARN":
            badge = status_warn()
        elif self.status == "FAIL":
            badge = status_fail()
        else:
            badge = status_info()

        lines.append(f"  {bold(self.name)} -> {badge} {self.detail}")
        if self.why:
            lines.append(f"    {dim('• Why:     ')} {dim(self.why)}")
        if self.expected is not None and self.actual is not None:
            lines.append(f"    {cyan('• Expected:')} {self.expected}")
            lines.append(f"    {cyan('• Actual:  ')} {self.actual}")
        if self.fix and self.status in ("FAIL", "WARN"):
            fix_lines = self.fix.strip("\n").splitlines()
            lines.append(f"    {bold('• Fix:     ')} {fix_lines[0]}")
            lines += [f"                {l}" for l in fix_lines[1:]]
        return "\n".join(lines)


@dataclass
class CheckSection:
    title: str
    items: List[CheckItem] = field(default_factory=list)

    def add(self, item: CheckItem) -> None:
        self.items.append(item)

    def render(self) -> str:
        output = [f"\n{blue('>>> ' + self.title)}", "-" * 80]
        for item in self.items:
            output.append(item.render())
        return "\n".join(output)


class ValidationReport:
    """Consolidates checks, calculates summary metrics, and exports reports."""

    def __init__(self, title: str):
        self.title = title
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.metadata: Dict[str, Any] = {}
        self.sections: List[CheckSection] = []

    def new_section(self, title: str) -> CheckSection:
        sec = CheckSection(title=title)
        self.sections.append(sec)
        return sec

    @property
    def total_passed(self) -> int:
        return sum(1 for s in self.sections for i in s.items if i.status == "PASS")

    @property
    def total_warnings(self) -> int:
        return sum(1 for s in self.sections for i in s.items if i.status == "WARN")

    @property
    def total_failures(self) -> int:
        return sum(1 for s in self.sections for i in s.items if i.status == "FAIL")

    @property
    def exit_code(self) -> int:
        """0 = pass, 1 = warning(s) only, 2 = failure(s)."""
        if self.total_failures > 0:
            return 2
        if self.total_warnings > 0:
            return 1
        return 0

    def render_console(self) -> str:
        lines = [
            "=" * 80,
            bold(f"  {self.title.upper()}"),
            "=" * 80,
            f"Timestamp: {white(self.timestamp)}",
        ]
        for k, v in self.metadata.items():
            lines.append(f"{cyan(k + ':'):<26} {v}")

        for sec in self.sections:
            lines.append(sec.render())

        lines.append("\n" + "=" * 80)
        status_str = (
            status_pass("ALL CHECKS PASSED - ROCK SOLID")
            if self.total_failures == 0 and self.total_warnings == 0
            else (
                status_warn("WARNINGS DETECTED - REVIEW RECOMMENDED")
                if self.total_failures == 0
                else status_fail("CRITICAL FAILURES DETECTED")
            )
        )
        lines.append(
            f"SUMMARY: {self.total_passed} Passed, {self.total_warnings} Warnings, {self.total_failures} Failed | {status_str}"
        )
        lines.append("=" * 80)
        return "\n".join(lines)

    @property
    def verdict(self) -> str:
        if self.total_failures:
            return "CRITICAL FAILURES DETECTED"
        if self.total_warnings:
            return "WARNINGS DETECTED - REVIEW RECOMMENDED"
        return "ALL CHECKS PASSED"

    def render_markdown(self, heading_level: int = 1, include_fixes: bool = True) -> str:
        """Render the report as GitHub-flavoured Markdown (no ANSI colours)."""
        h = "#" * heading_level
        icon = {"PASS": "✅ PASS", "WARN": "⚠️ WARN", "FAIL": "❌ FAIL", "INFO": "ℹ️ INFO"}
        esc = lambda s: str(s).replace("|", "\\|").replace("\n", " ")
        lines = [f"{h} {self.title}", "", f"_Generated {self.timestamp}_", ""]
        if self.metadata:
            lines += ["| | |", "|---|---|"] + [f"| {esc(k)} | {esc(v)} |" for k, v in self.metadata.items()] + [""]
        lines += [f"**Summary:** {self.total_passed} passed, {self.total_warnings} warnings, "
                  f"{self.total_failures} failed: **{self.verdict}**", ""]
        for sec in self.sections:
            lines += [f"{h}# {sec.title}", "", "| Check | Status | Detail | Expected | Actual |",
                      "|---|---|---|---|---|"]
            for i in sec.items:
                lines.append(f"| {esc(i.name)} | {icon.get(i.status, i.status)} | {esc(i.detail)} | "
                             f"{esc(i.expected or '')} | {esc(i.actual or '')} |")
            problems = [i for i in sec.items if i.status in ("FAIL", "WARN") and (i.why or (include_fixes and i.fix))]
            if problems:
                lines.append("")
                for i in problems:
                    lines.append(f"- **{esc(i.name)}**: {i.why or ''}")
                    if include_fixes and i.fix:
                        lines += ["", "  Fix:", "", "  ```bash"] + [f"  {l}" for l in i.fix.strip().splitlines()] + ["  ```", ""]
            lines.append("")
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
            "summary": {
                "passed": self.total_passed,
                "warnings": self.total_warnings,
                "failures": self.total_failures,
                "exit_code": self.exit_code,
            },
            "sections": [
                {
                    "title": s.title,
                    "items": [asdict(item) for item in s.items],
                }
                for s in self.sections
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
