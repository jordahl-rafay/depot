"""Terminal color and formatting engine."""

import os
import sys

_USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def set_color_mode(enabled: bool) -> None:
    """Explicitly enable or disable ANSI color output."""
    global _USE_COLOR
    _USE_COLOR = enabled


def is_color_enabled() -> bool:
    """Return True if ANSI colors are enabled."""
    return _USE_COLOR


# ANSI Escape Codes
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"

BOLD_RED = "\033[1;31m"
BOLD_GREEN = "\033[1;32m"
BOLD_YELLOW = "\033[1;33m"
BOLD_BLUE = "\033[1;34m"
BOLD_MAGENTA = "\033[1;35m"
BOLD_CYAN = "\033[1;36m"
BOLD_WHITE = "\033[1;37m"


def colorize(text: str, color_code: str) -> str:
    """Wrap text in an ANSI color code if coloring is enabled."""
    if not _USE_COLOR:
        return text
    return f"{color_code}{text}{RESET}"


def bold(text: str) -> str:
    return colorize(text, BOLD)


def dim(text: str) -> str:
    return colorize(text, DIM)


def red(text: str) -> str:
    return colorize(text, BOLD_RED)


def green(text: str) -> str:
    return colorize(text, BOLD_GREEN)


def yellow(text: str) -> str:
    return colorize(text, BOLD_YELLOW)


def blue(text: str) -> str:
    return colorize(text, BOLD_BLUE)


def cyan(text: str) -> str:
    return colorize(text, BOLD_CYAN)


def white(text: str) -> str:
    return colorize(text, BOLD_WHITE)


def status_pass(label: str = "PASS") -> str:
    return colorize(f"[✔ {label}]", BOLD_GREEN)


def status_fail(label: str = "FAIL") -> str:
    return colorize(f"[✖ {label}]", BOLD_RED)


def status_warn(label: str = "WARN") -> str:
    return colorize(f"[⚠ {label}]", BOLD_YELLOW)


def status_info(label: str = "INFO") -> str:
    return colorize(f"[ℹ {label}]", BOLD_CYAN)
