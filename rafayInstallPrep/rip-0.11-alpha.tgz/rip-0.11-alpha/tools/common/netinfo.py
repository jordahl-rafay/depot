"""Host network facts shared by the prep tools (standard library + iproute2 only)."""

import ipaddress
import json
import socket
import subprocess
from typing import List, Optional, Tuple


def local_ips() -> List[str]:
    """All IPv4/IPv6 addresses configured on this host's interfaces."""
    try:
        out = subprocess.run(["ip", "-j", "addr"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             timeout=10).stdout
        return [a["local"] for link in json.loads(out or b"[]") for a in link.get("addr_info", []) if "local" in a]
    except Exception:
        return []


def _ip_json(args: List[str]) -> list:
    try:
        out = subprocess.run(["ip", "-j"] + args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10).stdout
        return json.loads(out or b"[]")
    except Exception:
        return []


def _usable(ip: Optional[str]) -> bool:
    try:
        addr = ipaddress.ip_address(ip or "")
    except ValueError:
        return False
    return not (addr.is_loopback or addr.is_link_local or addr.is_unspecified)


def management_interface() -> Tuple[Optional[str], Optional[str]]:
    """(interface, IPv4) of the management interface: the one carrying the default route.

    Uses the interface's primary global address, never `hostname -i` or /etc/hosts (which on Ubuntu can map the
    hostname to 127.0.1.1).
    """
    for route in _ip_json(["-4", "route", "show", "default"]):
        dev = route.get("dev")
        if not dev:
            continue
        for link in _ip_json(["-4", "addr", "show", "dev", dev, "scope", "global"]):
            for a in link.get("addr_info", []):
                if _usable(a.get("local")):
                    return dev, a["local"]
    return None, None


def detect_node_ip(targets: Optional[List[str]] = None) -> Optional[str]:
    """Node IP = management interface address; falls back to the kernel's source address toward the metadata/DNS
    service (or the given targets) when there is no default route. Never loopback or link-local."""
    _, ip = management_interface()
    if ip:
        return ip
    for target in list(targets or []) + ["169.254.169.254", "8.8.8.8", "1.1.1.1"]:
        if not _usable(target) and not target.startswith("169.254."):
            continue
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect((target, 53))
            ip = sock.getsockname()[0]
            if _usable(ip):
                return ip
        except Exception:
            continue
        finally:
            sock.close()
    return None


def ip_scope(ip: str) -> str:
    """'private', 'public', 'loopback', 'link-local' or 'invalid'."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return "invalid"
    if addr.is_loopback:
        return "loopback"
    if addr.is_link_local:
        return "link-local"
    if addr.is_private or addr in ipaddress.ip_network("100.64.0.0/10"):  # incl. CGNAT
        return "private"
    return "public"
