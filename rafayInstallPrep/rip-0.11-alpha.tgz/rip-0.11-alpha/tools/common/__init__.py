"""Common utilities for styling, colors, and reporting."""
