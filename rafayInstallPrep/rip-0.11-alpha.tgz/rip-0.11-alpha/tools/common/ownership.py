"""Hand files created under `sudo` back to the invoking user.

rafayInstallPrep runs as a normal user and calls some tools with sudo; anything those tools write into the
user's working directory (reports, captures) would otherwise be root-owned and not overwritable next run.
"""

import os
from pathlib import Path
from typing import Union


def hand_back(path: Union[str, Path]) -> None:
    """chown path (recursively for directories) to SUDO_UID:SUDO_GID when running as root under sudo."""
    uid, gid = os.environ.get("SUDO_UID"), os.environ.get("SUDO_GID")
    if os.geteuid() != 0 or not uid or not gid:
        return
    uid, gid = int(uid), int(gid)
    p = Path(path)
    try:
        if p.is_dir():
            for root, dirs, files in os.walk(p):
                for name in dirs + files:
                    os.lchown(os.path.join(root, name), uid, gid)
        if p.exists():
            os.lchown(p, uid, gid)
    except OSError:
        pass


def write_text(path: Union[str, Path], content: str) -> Path:
    """Write a report file, creating parent dirs, and hand both back to the invoking user."""
    p = Path(path)
    created = [d for d in reversed(p.parents) if not d.exists()]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    for d in created:
        hand_back(d)
    hand_back(p)
    return p
