"""Set values in radm's config.yaml without a YAML library, keeping the template's comments and layout.

The target hosts have no PyYAML, and a load/dump round trip would drop the template's comments anyway. The editor
only handles what radm's config.yaml uses for the values we set: nested block mappings of scalars. Keys are
addressed by dotted path (e.g. ``spec.app-config.partner.star-domain``); a missing leaf is added under its parent.
Keys inside list items are never matched as targets.

Values that rafayInstallPrep sets (``desired_values``):
  - everything under ``radm_config.set`` in rafay_prep_config.json (deployment size, GAAP, the SMTP block that points
    at the sink from extras/deploy_mailpit.sh, product name, ...)
  - spec.repo.archive-directory          = absolute path of the extracted controller folder
  - spec.app-config.partner.star-domain  = controller.wildcard_base
  - spec.app-config.partner.name         = controller.partner_name
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

KEY_LINE = re.compile(r"^(?P<indent>[ ]*)(?P<key>[A-Za-z0-9_][A-Za-z0-9_.\-]*)[ ]*:(?P<rest>.*)$")


def format_value(value: Any) -> str:
    """YAML scalar text for a JSON value (strings double-quoted; JSON escaping is valid YAML)."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return '""'
    if isinstance(value, (int, float)):
        return str(value)
    return json.dumps(str(value))


def parse_scalar(text: str) -> Any:
    """Inverse of format_value for the simple scalars config.yaml uses."""
    t = text.strip()
    if len(t) >= 2 and t[0] == t[-1] and t[0] in "\"'":
        if t[0] == '"':
            try:
                return json.loads(t)
            except ValueError:
                return t[1:-1]
        return t[1:-1].replace("''", "'")
    if t in ("true", "True"):
        return True
    if t in ("false", "False"):
        return False
    if re.fullmatch(r"-?\d+", t):
        return int(t)
    return t


def split_comment(rest: str) -> Tuple[str, str]:
    """Split the text after 'key:' into (value, comment-with-leading-spaces). '#' inside quotes is not a comment."""
    quote = None
    for i, ch in enumerate(rest):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
        elif ch == "#" and (i == 0 or rest[i - 1] in " \t"):
            j = i
            while j > 0 and rest[j - 1] in " \t":
                j -= 1
            return rest[:j], rest[j:]
    return rest.rstrip(), ""


def _index(lines: List[str]) -> Dict[str, Tuple[int, int]]:
    """Map dotted path -> (line number, indent) for every mapping key outside list items."""
    out: Dict[str, Tuple[int, int]] = {}
    stack: List[Tuple[int, str]] = []    # (indent, key); key None-like '' marks a list item scope
    for n, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        while stack and stack[-1][0] >= indent:
            stack.pop()
        if stripped.startswith("- ") or stripped == "-":
            stack.append((indent, ""))   # list item: nothing below it is addressable
            continue
        m = KEY_LINE.match(line)
        if not m:
            continue
        key = m.group("key")
        if all(k for _, k in stack):
            out[".".join([k for _, k in stack] + [key])] = (n, indent)
        stack.append((indent, key))
    return out


def _block_end(lines: List[str], start: int, indent: int) -> int:
    """Index after the last non-blank, non-comment line that belongs to the block opened at lines[start]."""
    last = start
    for n in range(start + 1, len(lines)):
        s = lines[n].strip()
        if not s or s.startswith("#"):
            continue
        if len(lines[n]) - len(lines[n].lstrip(" ")) <= indent:
            break
        last = n
    return last + 1


def _child_indent(lines: List[str], start: int, indent: int) -> int:
    for n in range(start + 1, len(lines)):
        s = lines[n].strip()
        if not s or s.startswith("#"):
            continue
        ind = len(lines[n]) - len(lines[n].lstrip(" "))
        return ind if ind > indent else indent + 2
    return indent + 2


def get_value(text: str, path: str) -> Tuple[bool, Any]:
    """(found, value) for a dotted path."""
    lines = text.splitlines()
    pos = _index(lines).get(path)
    if pos is None:
        return False, None
    value, _ = split_comment(KEY_LINE.match(lines[pos[0]]).group("rest"))
    return True, parse_scalar(value)


def set_values(text: str, values: Dict[str, Any]) -> Tuple[str, List[str]]:
    """Return (new text, list of 'path: old -> new' changes). Raises KeyError when a parent mapping is missing."""
    lines = text.splitlines()
    changes = []
    for path, value in values.items():
        new = format_value(value)
        idx = _index(lines)
        if path in idx:
            n, _ = idx[path]
            m = KEY_LINE.match(lines[n])
            old, comment = split_comment(m.group("rest"))
            if parse_scalar(old) == value and old.strip():
                continue
            lines[n] = f"{m.group('indent')}{m.group('key')}: {new}{comment}"
            changes.append(f"{path}: {old.strip() or '(empty)'} -> {new}")
            continue
        parent, _, leaf = path.rpartition(".")
        if parent not in idx:
            raise KeyError(f"{path}: parent '{parent}' not found in config.yaml")
        pn, pind = idx[parent]
        lines.insert(_block_end(lines, pn, pind), " " * _child_indent(lines, pn, pind) + f"{leaf}: {new}")
        changes.append(f"{path}: (added) {new}")
    return "\n".join(lines) + ("\n" if text.endswith("\n") or not text else ""), changes


# Characters that are legal inside a quoted YAML string but break radm's handling of a value (seen: ':' in
# partner.product-name). Values we write must not contain them; the operator fixes rafay_prep_config.json instead.
UNSAFE_CHARS = ':#"\'`{}[],&*!|>%@'


def lint_values(values: Dict[str, Any]) -> List[str]:
    """Problems with the values themselves (checked before anything is written)."""
    issues = []
    for path, value in values.items():
        if isinstance(value, str):
            bad = sorted({ch for ch in value if ch in UNSAFE_CHARS})
            if bad:
                issues.append(f"{path}: value {json.dumps(value)} contains {' '.join(repr(c) for c in bad)}, which "
                              "radm does not accept; change it in rafay_prep_config.json")
            if value != value.strip():
                issues.append(f"{path}: value {json.dumps(value)} has leading/trailing spaces")
    return issues


def lint_text(text: str) -> List[str]:
    """Structural YAML problems in the whole file (stdlib checks; a full parse when PyYAML is installed)."""
    issues = []
    for n, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        lead = line[:len(line) - len(line.lstrip(" \t"))]
        if "\t" in lead:
            issues.append(f"line {n}: tab in indentation (YAML allows spaces only)")
        body = stripped[2:] if stripped.startswith("- ") else stripped
        m = KEY_LINE.match(body)
        if not m:
            continue
        value, _ = split_comment(m.group("rest"))
        v = value.strip()
        if not v:
            continue
        if v[0] in "\"'":
            if len(v) < 2 or v[-1] != v[0]:
                issues.append(f"line {n}: unbalanced quotes in value of '{m.group('key')}': {v}")
        elif ": " in v or v.endswith(":"):
            issues.append(f"line {n}: unquoted ':' in value of '{m.group('key')}': {v}")
        elif v[0] in "@`|>%&*!" and v not in ("|", ">", "|-", ">-"):
            issues.append(f"line {n}: value of '{m.group('key')}' starts with reserved character {v[0]!r}: {v}")
    try:
        import yaml  # optional; not on the target hosts by default
    except ImportError:
        return issues
    try:
        yaml.safe_load(text)
    except yaml.YAMLError as e:
        issues.append(f"YAML parse error: {e}".replace("\n", " "))
    return issues


def desired_values(cfg: dict, archive_dir: Optional[str]) -> Dict[str, Any]:
    """The values rafayInstallPrep writes into config.yaml, in file order where it matters."""
    ctrl = cfg.get("controller", {})
    values = dict(cfg.get("radm_config", {}).get("set", {}))
    if archive_dir:
        values["spec.repo.archive-directory"] = str(archive_dir)
    if ctrl.get("wildcard_base"):
        values["spec.app-config.partner.star-domain"] = ctrl["wildcard_base"]
    if ctrl.get("partner_name"):
        values["spec.app-config.partner.name"] = ctrl["partner_name"]
    return {k: v for k, v in values.items() if not k.startswith("_")}


def apply_file(path: Path, values: Dict[str, Any], dry_run: bool = False) -> List[str]:
    text = path.read_text(encoding="utf-8")
    new, changes = set_values(text, values)
    if not dry_run and new != text:
        path.write_text(new, encoding="utf-8")
    return changes


def verify_file(path: Path, values: Dict[str, Any]) -> List[Tuple[str, Any, Any]]:
    """[(path, expected, actual-or-'<missing>')] for every value that differs."""
    text = path.read_text(encoding="utf-8")
    bad = []
    for key, want in values.items():
        found, have = get_value(text, key)
        if not found or have != want:
            bad.append((key, want, have if found else "<missing>"))
    return bad
