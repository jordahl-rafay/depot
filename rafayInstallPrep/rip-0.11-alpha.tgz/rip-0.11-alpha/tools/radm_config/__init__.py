"""Comment-preserving editor for radm's config.yaml."""
