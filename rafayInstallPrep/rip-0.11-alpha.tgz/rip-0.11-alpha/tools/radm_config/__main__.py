"""python3 -m tools.radm_config: write rafayInstallPrep's values into radm's config.yaml (comments kept).

  python3 -m tools.radm_config --config rafay_prep_config.json --file config.yaml --archive-dir /home/u/rafay-...
  python3 -m tools.radm_config --file config.yaml --archive-dir ... --check     # exit 1 if a value differs or lint fails

Exit codes: 0 ok; 1 --check found differences/lint problems; 2 not written (bad value, missing parent, I/O);
3 written, but the file has lint problems.
"""

import argparse
import sys
from pathlib import Path

from tools.config_loader import get_merged_config
from tools.radm_config.editor import apply_file, desired_values, format_value, lint_text, lint_values, verify_file


def main() -> None:
    p = argparse.ArgumentParser(description="Set rafayInstallPrep's values in radm's config.yaml")
    p.add_argument("-c", "--config", type=Path, default=Path("rafay_prep_config.json"))
    p.add_argument("-f", "--file", type=Path, default=Path("config.yaml"), help="radm config.yaml to edit")
    p.add_argument("-a", "--archive-dir", help="Absolute path of the extracted controller folder")
    p.add_argument("--dry-run", action="store_true", help="Show the changes without writing")
    p.add_argument("--check", action="store_true", help="Only compare and lint; exit 1 on any problem")
    args = p.parse_args()

    values = desired_values(get_merged_config(args.config), args.archive_dir)
    value_issues = lint_values(values)
    if args.check:
        bad = verify_file(args.file, values)
        for key, want, have in bad:
            print(f"{key}: expected {format_value(want)}, found {have}")
        issues = value_issues + lint_text(args.file.read_text(encoding="utf-8"))
        for i in issues:
            print(f"lint: {i}")
        sys.exit(1 if bad or issues else 0)
    # Refuse to write values radm would reject: nothing is changed, so the template stays usable
    if value_issues:
        for i in value_issues:
            print(f"config.yaml not updated: {i}", file=sys.stderr)
        sys.exit(2)
    try:
        changes = apply_file(args.file, values, dry_run=args.dry_run)
    except (OSError, KeyError) as e:
        print(f"config.yaml not updated: {e}", file=sys.stderr)
        sys.exit(2)
    for c in changes:
        print(("(dry-run) " if args.dry_run else "") + c)
    # Lint the whole file after writing (the template itself may have problems too)
    file_issues = lint_text(args.file.read_text(encoding="utf-8"))
    for i in file_issues:
        print(f"config.yaml lint: {i}", file=sys.stderr)
    print(f"{len(changes)} value(s) {'would change' if args.dry_run else 'set'} in {args.file}"
          if changes else f"{args.file} already has all {len(values)} values")
    sys.exit(3 if file_issues else 0)


if __name__ == "__main__":
    main()
