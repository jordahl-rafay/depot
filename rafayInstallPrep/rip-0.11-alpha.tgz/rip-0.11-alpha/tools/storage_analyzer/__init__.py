"""Storage and Data Disk Discovery Analyzer."""
