"""Discovers data drives, partitions, and LVM expansion potential using structured lsblk data."""

import argparse
import json
import os
import shutil
import subprocess
import sys
from typing import Dict, Any, List, Optional

from tools.common.colors import bold, green, yellow, red, cyan, blue, dim, status_pass, status_warn


def format_bytes(size_bytes: int) -> str:
    """Format bytes into human-readable string (GB, TB)."""
    for unit in ["B", "KB", "MB", "GB", "TB", "PB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"


def get_lsblk_data() -> Dict[str, Any]:
    """Retrieve block devices using lsblk --json."""
    if not shutil.which("lsblk"):
        return {"blockdevices": []}

    cmd = ["lsblk", "--json", "-b", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,PKNAME,FSTYPE,MODEL"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return json.loads(res.stdout)
    except Exception:
        return {"blockdevices": []}


def find_root_disk() -> Optional[str]:
    """Find the root disk device name (e.g. sda, nvme0n1)."""
    # 1. Check findmnt
    if shutil.which("findmnt"):
        try:
            res = subprocess.run(
                ["findmnt", "-n", "-o", "SOURCE", "/"],
                capture_output=True, text=True, check=True
            )
            root_src = res.stdout.strip()
            if root_src:
                # Get parent disk
                pk_res = subprocess.run(
                    ["lsblk", "-no", "PKNAME", root_src],
                    capture_output=True, text=True
                )
                pk_name = pk_res.stdout.strip().splitlines()
                if pk_name and pk_name[0]:
                    return pk_name[0]
                # If root_src is already a disk
                base = os.path.basename(root_src)
                return base
        except Exception:
            pass

    # 2. Fallback to /proc/mounts
    try:
        with open("/proc/mounts", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "/":
                    dev = parts[0]
                    return os.path.basename(dev)
    except Exception:
        pass

    return None


def check_lvm_vg_expansion() -> Dict[str, Any]:
    """Check if root is on LVM and if the Volume Group has free space to expand."""
    result = {
        "can_expand": False,
        "vg_name": None,
        "lv_path": None,
        "free_space_bytes": 0,
        "free_space_str": "0",
    }

    if not shutil.which("vgs") or not shutil.which("lvs"):
        return result

    try:
        # Check root mount source
        findmnt = subprocess.run(
            ["findmnt", "-n", "-o", "SOURCE", "/"],
            capture_output=True, text=True
        )
        root_lv = findmnt.stdout.strip()
        if not root_lv or not root_lv.startswith("/dev/mapper/"):
            return result

        # Get VG name
        lvs = subprocess.run(
            ["sudo", "lvs", "--noheadings", "-o", "vg_name", root_lv],
            capture_output=True, text=True
        )
        vg_name = lvs.stdout.strip()
        if not vg_name:
            return result

        # Get Free space in bytes
        vgs = subprocess.run(
            ["sudo", "vgs", "--noheadings", "--units", "b", "--nosuffix", "-o", "vg_free", vg_name],
            capture_output=True, text=True
        )
        vg_free_str = vgs.stdout.strip().split(".")[0]
        free_bytes = int(vg_free_str) if vg_free_str.isdigit() else 0

        if free_bytes > 0:
            result["can_expand"] = True
            result["vg_name"] = vg_name
            result["lv_path"] = root_lv
            result["free_space_bytes"] = free_bytes
            result["free_space_str"] = format_bytes(free_bytes)

    except Exception:
        pass

    return result


def analyze_storage() -> Dict[str, Any]:
    """Discover root disk, non-root data disks, and LVM expansion status."""
    root_disk = find_root_disk()
    lsblk_data = get_lsblk_data()
    devices = lsblk_data.get("blockdevices", [])

    candidates: List[Dict[str, Any]] = []

    for dev in devices:
        if dev.get("type") != "disk":
            continue

        name = dev.get("name", "")
        size_bytes = int(dev.get("size", 0))

        # Skip if it is the root disk or matches root disk prefix
        if root_disk and (name == root_disk or root_disk.startswith(name)):
            continue

        # Check if any child partition is mounted at / or /boot
        children = dev.get("children", [])
        is_system_disk = False
        has_partitions = len(children) > 0

        for child in children:
            mp = child.get("mountpoint")
            if mp in ("/", "/boot", "/boot/efi", "/var", "/home"):
                is_system_disk = True
                break

        if is_system_disk:
            continue

        dev_path = f"/dev/{name}"
        candidates.append({
            "name": name,
            "path": dev_path,
            "size_bytes": size_bytes,
            "size_str": format_bytes(size_bytes),
            "model": dev.get("model", "").strip(),
            "has_partitions": has_partitions,
            "partition_count": len(children),
        })

    # Sort candidates by size descending
    candidates.sort(key=lambda d: d["size_bytes"], reverse=True)
    selected_drive = candidates[0]["path"] if candidates else None

    lvm_info = check_lvm_vg_expansion()

    return {
        "root_disk": root_disk,
        "detected_drive": selected_drive,
        "candidate_drives": candidates,
        "lvm_expansion": lvm_info,
    }


def main():
    parser = argparse.ArgumentParser(description="Storage and Data Drive Discovery Utility")
    parser.add_argument("--json", action="store_true", help="Output analysis in JSON format")
    parser.add_argument(
        "--export-shell", action="store_true", help="Output sh-compatible variable assignments"
    )
    args = parser.parse_args()

    analysis = analyze_storage()

    if args.export_shell:
        drive = analysis["detected_drive"] or ""
        can_lvm = "true" if analysis["lvm_expansion"]["can_expand"] else "false"
        vg_name = analysis["lvm_expansion"]["vg_name"] or ""
        free_space = analysis["lvm_expansion"]["free_space_str"]
        lv_path = analysis["lvm_expansion"]["lv_path"] or ""

        print(f'DETECTED_DRIVE="{drive}"')
        print(f'CAN_EXPAND_LVM={can_lvm}')
        print(f'LVM_VG_NAME="{vg_name}"')
        print(f'LVM_FREE_SPACE="{free_space}"')
        print(f'LVM_LV_PATH="{lv_path}"')
        return

    if args.json:
        print(json.dumps(analysis, indent=2))
        return

    print("=" * 80)
    print(bold(">>> STORAGE & DATA DISK ANALYSIS"))
    print("=" * 80)
    print(f"{cyan('Root Disk:'):<20} {analysis['root_disk'] or 'Unknown'}")
    print(f"{cyan('Target Data Drive:'):<20} {green(analysis['detected_drive'] or 'NOT FOUND')}")

    if analysis["candidate_drives"]:
        print(f"\n{blue('Candidate Data Disks:')}")
        for c in analysis["candidate_drives"]:
            part_info = f"({c['partition_count']} existing partition(s))" if c["has_partitions"] else "(Unpartitioned)"
            print(f"  • {bold(c['path']):<16} Size: {c['size_str']:<10} {dim(part_info)}")

    lvm = analysis["lvm_expansion"]
    print(f"\n{blue('LVM Expansion Status:')}")
    if lvm["can_expand"]:
        print(f"  • {status_pass()} Free space found in VG {bold(lvm['vg_name'])}: {green(lvm['free_space_str'])}")
    else:
        print(f"  • {dim('No unallocated LVM volume group space detected or not LVM-based.')}")
    print("=" * 80)


if __name__ == "__main__":
    main()
