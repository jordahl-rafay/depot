"""Entrypoint for python3 -m tools.storage_analyzer."""

from tools.storage_analyzer.analyzer import main

if __name__ == "__main__":
    main()
