"""Copy-paste remediation for every post-install check that can FAIL or WARN.

Each entry maps a check name (regex) to a function returning the commands a user runs to correct it, filled in with
this node's real values (FQDN, node IP, mount point, device, UUID, exact firewall rules, ...). Commands assume the
current directory is the rafayInstallPrep directory (where the validator was started).
"""

import re
from typing import Callable, Dict, List, Optional, Tuple

from tools.common.reporter import CheckItem, ValidationReport

ALL_STEPS = range(1, 17)
TOOL_PACKAGES = {  # tool -> (Ubuntu package, RHEL package)
    "bzip2": ("bzip2", "bzip2"), "pigz": ("pigz", "pigz"), "aria2c": ("aria2", "aria2"),
    "dig": ("dnsutils", "bind-utils"), "python3": ("python3", "python3"), "jq": ("jq", "jq"),
    "iptables": ("iptables", "iptables-nft"),
}


def rerun(step: int, why: str = "") -> str:
    """Command that re-runs a single prep step (all others excluded)."""
    others = ",".join(str(s) for s in ALL_STEPS if s != step)
    return f"./rafayInstallPrep.sh -x {others}    # re-runs only step {step}{(': ' + why) if why else ''}"


def _pkg(ctx: dict, tool: str) -> str:
    ubuntu, rhel = TOOL_PACKAGES.get(tool, (tool, tool))
    return (f"sudo apt-get update && sudo apt-get install -y {ubuntu}" if ctx["ost"] == "ubuntu"
            else f"sudo dnf install -y {rhel}")


def _hosts_fix(ctx: dict) -> str:
    return (f"sudo python3 -m tools.config_manager --set-hosts --cloud-init --fqdn {ctx['fqdn']} "
            f"--hostname {ctx['short']} --ip {ctx['node_ip'] or '<NODE_IP>'}\n"
            "hostname -i    # must print exactly the node IP")


def _validate_again() -> str:
    return "./rafayInstallPrep.sh --validate"


def rocky_apply() -> str:
    """Command that applies only the --rocky disguise (keeps the prep ledger)."""
    return "./rafayInstallPrep.sh --rocky-apply    # presents Rocky Linux as RHEL; originals are backed up first"


def _rocky(i, c, m):
    return f"{rocky_apply()}\n{_validate_again()}"


def _rocky_backups(i, c, m):
    return ("sudo ls -lR /var/lib/rafayInstallPrep/rocky-backup    # see which originals are missing\n"
            "# Missing originals can only be recreated from the package (this also undoes the disguise):\n"
            "sudo dnf reinstall -y rocky-release\n"
            f"{rocky_apply()}    # backs up the fresh originals, then re-applies")


# --- Fix builders: (item, ctx, regex match) -> commands -------------------------------------------

def _reboot(i, c, m):
    return f"sudo reboot\n# after the node is back:\n{_validate_again()}"


def _failed_step(i, c, m):
    return (f"grep -n 'Step {m.group(1)}' {c['log']} | tail -20    # see why it failed\n"
            f"{rerun(int(m.group(1)))}")


def _packages(i, c, m):
    return ("sudo apt-get update && sudo DEBIAN_FRONTEND=noninteractive apt-get -y upgrade"
            if c["ost"] == "ubuntu" else "sudo dnf -y update") + \
           "\n[ -f /var/run/reboot-required ] && sudo reboot    # if a new kernel was installed"


def _reject_rules(i, c, m):
    rules = i.metadata.get("rules", [])
    lines = [f"sudo iptables {r.replace('-A ', '-D ', 1)}" for r in rules] or \
            ["sudo iptables -S INPUT; sudo iptables -S FORWARD    # find the REJECT/DROP rules",
             "sudo iptables -D <CHAIN> <rule spec>"]
    return "\n".join(lines + ["# then make sure nothing restores them at boot (see the other Step 2 checks)"])


def _saved_rules(i, c, m):
    saved = " ".join(i.metadata.get("saved", ["/etc/iptables/rules.v4"]))
    return ("sudo apt-get remove --purge -y iptables-persistent    # removes the boot-time restore plugin\n"
            f"# or keep the package but empty the saved rules:\nfor f in {saved}; do sudo mv \"$f\" \"$f.bak\"; done")


def _mount(i, c, m):
    mp = c["mp"]
    return (f"grep -E '\\s{mp}\\s' /etc/fstab || echo 'no fstab entry for {mp}'\n"
            f"sudo mount {mp}    # if the fstab entry exists\n"
            f"lsblk -f            # otherwise find the data partition, then:\n{rerun(5, 'partition/format/mount')}")


def _fstab_entry(i, c, m):
    mp, uuid = c["mp"], i.metadata.get("mounted_uuid") or "<UUID from: sudo blkid -s UUID -o value <partition>>"
    return (f"sudo cp /etc/fstab /etc/fstab.bak\n"
            f"sudo sed -i -E 's|^([^#[:space:]]+[[:space:]]+{mp}[[:space:]].*)$|# \\1|' /etc/fstab   # old entries\n"
            f"echo -e 'UUID={uuid}\\t{mp}\\text4\\tdefaults\\t0 0' | sudo tee -a /etc/fstab\n"
            "sudo systemctl daemon-reload && sudo mount -a")


def _fstab_uuid(i, c, m):
    want, got = i.metadata.get("fstab_uuid", "<OLD>"), i.metadata.get("mounted_uuid", "<NEW>")
    return (f"sudo cp /etc/fstab /etc/fstab.bak\nsudo sed -i 's/UUID={want}/UUID={got}/' /etc/fstab\n"
            "sudo systemctl daemon-reload && sudo mount -a    # must succeed before the next reboot")


def _hostname(i, c, m):
    return (f"sudo hostnamectl set-hostname {c['fqdn']}\n"
            "printf 'preserve_hostname: true\\nmanage_etc_hosts: false\\n' | "
            "sudo tee /etc/cloud/cloud.cfg.d/99-rafay-hostname.cfg    # keep cloud-init from resetting it")


def _rfc1123(i, c, m):
    return (f"# Pick a lowercase name (a-z, 0-9, '-' and '.'), set controller.fqdn in the config, then:\n"
            f"./rafayInstallPrep.sh -f <lowercase-fqdn> -n <short> -x "
            f"{','.join(str(s) for s in ALL_STEPS if s != 6)}")


def _resolv_link(i, c, m):
    return ("sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf\n"
            "ls -l /etc/resolv.conf && grep nameserver /etc/resolv.conf")


def _resolved_service(i, c, m):
    return "sudo systemctl enable --now systemd-resolved\nresolvectl status | head -20"


def _resolved_dropin(i, c, m):
    return ("sudo mkdir -p /etc/systemd/resolved.conf.d\n"
            "printf '[Resolve]\\nDNSSEC=no\\nCache=no-negative\\n' | "
            "sudo tee /etc/systemd/resolved.conf.d/90-rafay.conf\nsudo systemctl restart systemd-resolved")


def _pod_resolver(i, c, m):
    if c["ost"] == "ubuntu":
        return ("resolvectl dns    # the link must list a routable DNS server (e.g. the VCN/VPC resolver)\n"
                "# if empty: fix DHCP/netplan DNS (nameservers.addresses in /etc/netplan/*.yaml), then:\n"
                "sudo netplan apply && sudo systemctl restart systemd-resolved")
    return ("sudo vi /etc/resolv.conf    # list routable nameservers, e.g. 'nameserver 10.0.0.2' (not 127.x)\n"
            "cat /etc/NetworkManager/conf.d/90-dns-none.conf    # must contain dns=none so NM keeps your edit")


def _search_budget(i, c, m):
    return ("# Too many search domains: remove extras at the source (VCN/VPC DHCP options, or netplan\n"
            "# 'nameservers.search' / NetworkManager 'ipv4.dns-search'), then:\n"
            + ("sudo netplan apply && sudo systemctl restart systemd-resolved" if c["ost"] == "ubuntu"
               else "sudo nmcli connection up <connection>    # or edit /etc/resolv.conf 'search' directly"))


def _dhclient(i, c, m):
    return ("ps -o pid,args -C dhclient    # which interface/config started it\n"
            "# Prefer netplan/systemd-networkd or NetworkManager for this interface; if dhclient must stay, pin DNS:\n"
            "echo 'supersede domain-name-servers <DNS_IP>;' | sudo tee -a /etc/dhcp/dhclient.conf")


def _lvm(i, c, m):
    lv = i.metadata.get("root_lv", "<root LV, e.g. /dev/mapper/ubuntu--vg-ubuntu--lv>")
    return f"sudo lvextend -r -l +100%FREE {lv}    # -r grows the filesystem too\ndf -h /"


def _apparmor_runtime(i, c, m):
    return ("cat /etc/default/grub.d/99-disable-apparmor.cfg    # must add apparmor=0\n"
            "sudo update-grub && sudo reboot\n# after reboot: cat /sys/module/apparmor/parameters/enabled  -> N")


def _apparmor_grub(i, c, m):
    return ("echo 'GRUB_CMDLINE_LINUX=\"$GRUB_CMDLINE_LINUX apparmor=0\"' | "
            "sudo tee /etc/default/grub.d/99-disable-apparmor.cfg\nsudo update-grub && sudo reboot")


def _apparmor_service(i, c, m):
    return "sudo systemctl disable --now apparmor"


def _selinux(i, c, m):
    return ("sudo setenforce 0\nsudo sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config\n"
            "sudo reboot    # 'getenforce' must print Disabled afterwards")


def _floors(i, c, m):
    low = i.metadata.get("low", {})
    lines = [f"sudo sysctl -w {k}={v}" for k, v in low.items()]
    return "\n".join(lines + [f"{rerun(10, 'persist the floors in /etc/sysctl.d/90-rafay-sysctl-floors.conf')}"])


def _nm_dns_none(i, c, m):
    return ("printf '[main]\\ndns=none\\n' | sudo tee /etc/NetworkManager/conf.d/90-dns-none.conf\n"
            "sudo systemctl reload NetworkManager")


def _nm_unmanaged(i, c, m):
    devs = c["cfg"].get("host_tuning", {}).get("nm_unmanaged_devices", [])
    spec = ";".join(f"interface-name:{d}" for d in devs) or "interface-name:cali*;interface-name:vxlan.calico"
    return (f"printf '[keyfile]\\nunmanaged-devices+={spec}\\n' | "
            "sudo tee /etc/NetworkManager/conf.d/90-rafay-k8s-unmanaged.conf\nsudo systemctl reload NetworkManager")


def _preflight(i, c, m):
    url = c["cfg"].get("prerequisites", {}).get("preflight_script_url", "<PREFLIGHT_URL>")
    return (f"grep -n FAIL {c['data_dir']}/changes.info/preflight_check.txt    # each line names the failed check\n"
            f"# fix each item, then re-run the preflight:\ncurl -sSL {url} | sudo bash")


def _tarball(i, c, m):
    return f"{rerun(14, 'download + MD5')}\n# MD5 still wrong? check tarball.url / tarball.md5 in rafay_prep_config.json"


def _md5(i, c, m):
    return (f"rm -f {i.metadata.get('file', '<tarball>')} {i.metadata.get('file', '<tarball>')}.aria2    # corrupt or "
            f"partial download\n{rerun(14, 'download again')}\n"
            "# still mismatched: confirm tarball.md5 in rafay_prep_config.json matches the published checksum")


def _radm(i, c, m):
    d = c.get("extract_dir") or "<extracted controller folder>"
    return f"sudo install -m 0755 ./{d}/radm /usr/bin/radm\nradm --help | head -3"


def _config_yaml(i, c, m):
    d = c.get("extract_dir") or "<extracted controller folder>"
    return f"cp ./{d}/config.yaml-airgap-tmpl ./config.yaml"


def _config_edit(i, c, m):
    return ("vi config.yaml    # set at least the controller FQDN / wildcard domain, certificates and the logo path\n"
            "# (see the comments in the template; the file must differ from config.yaml-airgap-tmpl)")


def _config_values(i, c, m):
    archive = i.metadata.get("archive") or f"$(pwd)/{c.get('extract_dir') or '<extracted controller folder>'}"
    return (f"python3 -m tools.radm_config --file config.yaml --archive-dir {archive}    # sets them, comments kept\n"
            f"python3 -m tools.radm_config --file config.yaml --archive-dir {archive} --check\n"
            "# a value you changed on purpose: change it in rafay_prep_config.json (radm_config.set / controller) "
            "instead, or ignore this warning")


def _iscsi_pkg(i, c, m):
    pkg = i.metadata.get("pkg") or ("open-iscsi" if c["ost"] == "ubuntu" else "iscsi-initiator-utils")
    inst = (f"sudo apt-get update && sudo apt-get install -y {pkg}" if c["ost"] == "ubuntu"
            else f"sudo dnf install -y {pkg}")
    return f"{inst}\nsudo systemctl enable --now iscsid"


def _chrony(i, c, m):
    svc = "chrony" if c["ost"] == "ubuntu" else "chronyd"
    return (f"sudo systemctl enable --now {svc}\nchronyc sources -v    # at least one source marked '*'\n"
            "sudo chronyc -a makestep\n# no reachable sources: allow UDP 123 to the NTP servers, or set "
            "time_sync.servers to internal NTP and re-run step 3")


def _timesyncd(i, c, m):
    return "sudo systemctl disable --now systemd-timesyncd"


def _ntp_servers(i, c, m):
    return rerun(3, "rewrites the chrony server block from time_sync.servers")


def _timezone(i, c, m):
    return f"sudo timedatectl set-timezone {c['cfg'].get('time_sync', {}).get('timezone') or '<Region/City>'}"


def _clock(i, c, m):
    return ("timedatectl timesync-status    # or: chronyc tracking\n"
            "sudo systemctl restart systemd-timesyncd\n"
            "# or set \"time_sync\": {\"enabled\": true, ...} in rafay_prep_config.json and:\n" + rerun(3))


def _cgroup(i, c, m):
    return ("# Kubernetes needs systemd as PID 1 and cgroup v2 (default on Ubuntu 22.04+/RHEL 9).\n"
            "echo 'GRUB_CMDLINE_LINUX=\"$GRUB_CMDLINE_LINUX systemd.unified_cgroup_hierarchy=1\"' | "
            "sudo tee /etc/default/grub.d/99-cgroup-v2.cfg\nsudo update-grub && sudo reboot")


def _unit(i, c, m):
    unit = m.group(1)
    return f"sudo systemctl restart {unit}\nsystemctl status {unit} --no-pager\njournalctl -u {unit} -b -n 50 --no-pager"


def _consul_bind(i, c, m):
    bind = c.get("bind") or "<consul bind_addr>"
    return (f"# /etc/hosts must map {c['fqdn']} to the Consul bind address so `hostname -i` = {bind}:\n"
            f"sudo python3 -m tools.config_manager --set-hosts --fqdn {c['fqdn']} --hostname {c['short']} --ip {bind}\n"
            "hostname -i")


def _resolv_after_reboot(i, c, m):
    return (_resolv_link(i, c, m) + "\n# then make radm's boot script leave it alone (hostname -i = node IP):\n" +
            _hosts_fix(c))


def _consul_in_resolver(i, c, m):
    bind = c.get("bind") or "<bind_addr>"
    return (f"grep -A2 '^\\[Resolve\\]' /etc/systemd/resolved.conf    # radm sets DNS={bind}\n"
            f"sudo systemctl restart systemd-resolved symchecker\ngrep nameserver {'/run/systemd/resolve/resolv.conf'}")


def _consul_host(i, c, m):
    bind = c.get("bind") or "<bind_addr>"
    return (f"systemctl status consul --no-pager\ndig @{bind} {m.group(1)} +short    # Consul answering directly?\n"
            "# if Consul answers but the host does not: fix the resolver (Step 7 checks / Controller resolv.conf)")


def _consul_split(i, c, m):
    bind = c.get("bind") or "<bind_addr>"
    return ("# Make CoreDNS send *.consul only to Consul (the other upstream answers NXDOMAIN):\n"
            "kubectl -n kube-system edit configmap coredns\n"
            f"#   add a server block before '.:53 {{':\n#     consul:53 {{\n#         forward . {bind}\n#     }}\n"
            "kubectl -n kube-system rollout restart deployment coredns")


def _api(i, c, m):
    return ("systemctl status kubelet --no-pager\nsudo crictl ps | grep -E 'kube-apiserver|etcd'\n"
            "journalctl -u kubelet -b -n 80 --no-pager")


def _console443(i, c, m):
    return ("# The wildcard resolves but TCP 443 is not reachable from this node:\n"
            "kubectl get svc -A | grep -iE 'ingress|istio'    # is the ingress up?\n"
            "# Public wildcard: allow ingress TCP 443 from the node's own public IP (hairpin) in the cloud\n"
            "# security list / NSG / security group, or point internal clients at the private IP (split-horizon).")


def _failed_units(i, c, m):
    units = i.metadata.get("units", [])
    return "\n".join([f"systemctl status {u} --no-pager; journalctl -u {u} -b -n 50 --no-pager" for u in units]
                     or ["systemctl --failed"])


FIXES: List[Tuple[str, Callable]] = [
    (r"^Rebooted after prep$|^Pending reboot flag$", _reboot),
    (r"^Step (\d+): ", _failed_step),
    (r"^Step R: ", lambda i, c, m: f"grep -n 'Step R' {c['log']} | tail -20    # see why it failed\n{_rocky(i, c, m)}"),
    (r"^Rocky Linux not presented as RHEL$|^/etc/(os|redhat)-release identifies as RHEL$", _rocky),
    (r"^Rocky release file backups$", _rocky_backups),
    (r"^Packages up to date$", _packages),
    (r"^ufw disabled$", lambda i, c, m: "sudo ufw disable\nsudo systemctl disable --now ufw\nsudo ufw status"),
    (r"^iptables-persistent removed$", lambda i, c, m: "sudo apt-get remove --purge -y iptables-persistent"),
    (r"^No saved firewall rules restored at boot$", _saved_rules),
    (r"^firewalld stopped and disabled$", lambda i, c, m: "sudo systemctl disable --now firewalld"),
    (r"^No host REJECT/DROP rules", _reject_rules),
    (r"^(\S+) installed$", lambda i, c, m: _pkg(c, m.group(1)) if m.group(1) in TOOL_PACKAGES else None),
    (r"^EPEL repository installed$", lambda i, c, m: "sudo dnf install -y epel-release"),
    (r"^Pre-change state captured$", lambda i, c, m: rerun(4)),
    (r"^\S+ mounted$", _mount),
    (r"^\S+ in /etc/fstab$", _fstab_entry),
    (r"^fstab UUID matches", _fstab_uuid),
    (r"^Hostname persisted$", _hostname),
    (r"^Hostname is RFC 1123$", _rfc1123),
    (r"^FQDN mapped to node IP$|^Previous hostname removed$|^`hostname -i`$|^`hostname -f`$",
     lambda i, c, m: _hosts_fix(c)),
    (r"^cloud-init keeps hostname/hosts$", lambda i, c, m: _hosts_fix(c)),
    (r"^/etc/resolv.conf -> upstream file$|^Resolver has nameservers$", _resolv_link),
    (r"^systemd-resolved active and enabled$", _resolved_service),
    (r"^resolved: DNSSEC=no", _resolved_dropin),
    (r"^Resolver file used by pods$", _pod_resolver),
    (r"^Search-domain budget$", _search_budget),
    (r"^dhclient not rewriting", _dhclient),
    (r"^Root volume group fully used$", _lvm),
    (r"^AppArmor disabled \(runtime\)$|^apparmor=0 on kernel cmdline$", _apparmor_runtime),
    (r"^GRUB drop-in present$", _apparmor_grub),
    (r"^apparmor.service disabled$", _apparmor_service),
    (r"^SELinux disabled", _selinux),
    (r"^fapolicyd stopped$", lambda i, c, m: "sudo systemctl disable --now fapolicyd"),
    (r"^No active swap$", lambda i, c, m: "sudo swapoff -a\n" + rerun(10, "keeps it off after reboot")),
    (r"^swap.target masked$", lambda i, c, m: "sudo systemctl mask swap.target"),
    (r"^No swap entries in /etc/fstab$", lambda i, c, m:
        "sudo cp /etc/fstab /etc/fstab.bak\n"
        "sudo sed -i -E 's|^([^#[:space:]]+[[:space:]]+[^[:space:]]+[[:space:]]+swap[[:space:]].*)$|# \\1|' /etc/fstab"),
    (r"^sysctl floors$", _floors),
    (r"^NetworkManager dns=none$", _nm_dns_none),
    (r"^CNI interfaces unmanaged$", _nm_unmanaged),
    (r"^Preflight report$", _preflight),
    (r"^Tarball present$", _tarball),
    (r"^MD5 verified at download$", _md5),
    (r"^Controller extracted$", lambda i, c, m: rerun(15)),
    (r"^radm installed$", _radm),
    (r"^config.yaml prepared$", _config_yaml),
    (r"^config.yaml edited$", _config_edit),
    (r"^config.yaml values set$", _config_values),
    (r"^config.yaml lint$", lambda i, c, m:
        "python3 -m tools.radm_config --file config.yaml --archive-dir "
        f"{i.metadata.get('archive') or '<extracted controller folder>'} --check    # lists each problem\n"
        "# a value problem: fix it in rafay_prep_config.json (radm_config.set / controller), then re-run the line "
        "above without --check\n# a file problem (tabs, quotes): fix that line in config.yaml"),
    (r"^iSCSI initiator installed$", _iscsi_pkg),
    (r"^iscsid running$", lambda i, c, m: "sudo systemctl enable --now iscsid\nsystemctl status iscsid --no-pager"),
    (r"^Time sync \(chrony\)$", _chrony),
    (r"^systemd-timesyncd stopped$", _timesyncd),
    (r"^Configured NTP servers", _ntp_servers),
    (r"^Timezone$", _timezone),
    (r"^Clock synchronized$", _clock),
    (r"^systemd \+ cgroup v2$", _cgroup),
    (r"^Consul bind address", _consul_bind),
    (r"^/etc/resolv.conf intact after reboot$", _resolv_after_reboot),
    (r"^Resolver lists Consul", _consul_in_resolver),
    (r"^Host resolves (\S+)$", _consul_host),
    (r"^Consul names consistent", _consul_split),
    (r"^Kubernetes API ready$", _api),
    (r"^Console reachable", _console443),
    (r"^No unexpected failed units$", _failed_units),
    (r"^(\S+) active$", _unit),
    (r"^disable-tcp-offloading$", lambda i, c, m: _unit(i, c, re.match(r"(.*)", "disable-tcp-offloading"))),
]


def attach_fixes(report: ValidationReport, ctx: Dict) -> List[str]:
    """Fill item.fix for every FAIL/WARN; returns the names of problems that still have no fix (should be none)."""
    missing = []
    for sec in report.sections:
        for item in sec.items:
            if item.status not in ("FAIL", "WARN") or item.fix:
                continue
            for pattern, build in FIXES:
                m = re.search(pattern, item.name)
                if m:
                    item.fix = build(item, ctx, m)
                    if item.fix:   # a builder may decline (e.g. the generic tool pattern for 'radm installed')
                        break
            if not item.fix:
                missing.append(item.name)
    return missing


_COMMANDS = ("dig ", "sudo ", "kubectl ", "curl ", "./rafayInstallPrep.sh", "resolvectl ", "nmcli ")


def _as_shell(line: str) -> str:
    """Keep runnable commands as-is; turn prose (and DNS zone records) into comments so a pasted block is safe."""
    text = line.strip()
    if not text:
        return ""
    if text.startswith("Verify from this host:"):
        cmd, _, note = text[len("Verify from this host:"):].strip().partition("   (")
        return cmd.strip() + (f"    # ({note}" if note else "")
    if text.startswith(_COMMANDS):
        return text
    return "# " + text


def attach_dns_fixes(report: ValidationReport, actions) -> None:
    """DNS checks: the fix is the remediation-plan action that lists the check."""
    by_check = {}
    for a in actions:
        for name in a.issues:
            by_check.setdefault(name, a)
    ansi = re.compile(r"\x1b\[[0-9;]*m")
    for sec in report.sections:
        for item in sec.items:
            if item.status in ("FAIL", "WARN") and not item.fix and item.name in by_check:
                a = by_check[item.name]
                steps = [ansi.sub("", st) for st in a.steps]
                if a.local:
                    item.fix = (f"# {a.title}\nsudo python3 -m tools.dns_validator --yes    # applies this local fix "
                                f"(and any other local DNS fix), then re-checks\n# What it changes:\n"
                                + "\n".join(f"#   {st}" for st in steps))
                else:
                    item.fix = f"# {a.title} (must be done outside this host)\n" + "\n".join(_as_shell(st) for st in steps)
