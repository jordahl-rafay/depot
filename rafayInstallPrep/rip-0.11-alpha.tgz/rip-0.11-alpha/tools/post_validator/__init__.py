"""Post-install validation of rafayInstallPrep changes (and the radm install, when present)."""
