"""Entrypoint for python3 -m tools.post_validator."""

from tools.post_validator.validator import main

if __name__ == "__main__":
    main()
