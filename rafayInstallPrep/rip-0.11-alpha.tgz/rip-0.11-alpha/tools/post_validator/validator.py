"""Post-install validator: verify every change rafayInstallPrep made, after a reboot.

Workflow:  sudo ./rafayInstallPrep.sh  ->  reboot  ->  sudo ./rafayInstallPrep.sh --validate
           (optionally again after `radm` has installed the controller, which adds controller checks)

Reads the change ledger written by rafayInstallPrep.sh (changes.info/changes.tsv), re-checks the end state of each
step independently (the ledger says what was done, the checks prove it is still true after the reboot), runs the
DNS validator (report only), and writes everything to one Markdown report.
"""

import argparse
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tools.common.colors import bold, set_color_mode
from tools.common.netinfo import detect_node_ip, local_ips
from tools.common.ownership import write_text
from tools.common.reporter import CheckItem, CheckSection, ValidationReport
from tools.config_loader import get_merged_config
from tools.dns_validator.cli import load_settings, plan_for, run_dns_validation
from tools.dns_validator.remediation import render_plan_markdown
from tools.post_validator.fixes import attach_dns_fixes, attach_fixes
from tools.radm_config.editor import desired_values, format_value, lint_text, lint_values, verify_file
from tools.dns_validator.resolution import hostname_i, query_nameserver_direct, resolve_local

STEP_NAMES = {
    "1": "Update system packages", "2": "Reset firewall", "3": "Install prerequisites",
    "4": "Gather instance info", "5": "Prepare data disk", "6": "Hostname & /etc/hosts",
    "7": "systemd-resolved & /etc/resolv.conf", "8": "Expand root LVM", "9": "Disable SELinux / AppArmor",
    "10": "Disable swap", "11": "NetworkManager DNS (RHEL)", "12": "DNS validation", "13": "Rafay preflight",
    "14": "Download controller tarball", "15": "Extract tarball", "16": "Finalize setup",
    "R": "Rocky Linux presented as RHEL (--rocky)",
}
UPSTREAM_RESOLV = "/run/systemd/resolve/resolv.conf"

# --rocky (lib/rocky.sh): release files replaced with RHEL equivalents; originals backed up here
ROCKY_BACKUP_DIR = Path("/var/lib/rafayInstallPrep/rocky-backup")
ROCKY_FILES = ["/etc/os-release", "/etc/redhat-release", "/etc/system-release", "/etc/system-release-cpe"]
ROCKY_MARKER = "RAFAY_PREP_DISGUISE="


def step_key(step: str):
    """Sort ledger step ids numerically, letters (e.g. R) after the numbers."""
    return (0, int(step), "") if step.isdigit() else (1, 0, step)


def sh(argv: List[str], timeout: int = 30) -> Tuple[int, str]:
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        return p.returncode, p.stdout.decode("utf-8", errors="replace").strip()
    except FileNotFoundError:
        return 127, f"{argv[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "timed out"


def unit_state(unit: str) -> str:
    return sh(["systemctl", "is-active", unit])[1].splitlines()[0] if shutil.which("systemctl") else "unknown"


def os_type() -> str:
    try:
        text = Path("/etc/os-release").read_text()
    except OSError:
        return "unknown"
    if re.search(r'^ID="?ubuntu', text, re.M):
        return "ubuntu"
    if re.search(r'^ID(_LIKE)?=.*(rhel|centos|rocky|fedora)', text, re.M):
        return "rhel"
    return "unknown"


def boot_time() -> Optional[float]:
    try:
        for line in Path("/proc/stat").read_text().splitlines():
            if line.startswith("btime "):
                return float(line.split()[1])
    except OSError:
        pass
    return None


# --- Ledger ---------------------------------------------------------------------------------

def read_ledger(path: Path) -> List[Dict[str, str]]:
    rows = []
    if path.is_file():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split("\t")
            if len(parts) >= 4:
                rows.append({"ts": parts[0], "step": parts[1], "status": parts[2], "action": parts[3],
                             "detail": parts[4] if len(parts) > 4 else ""})
    return rows


def ledger_markdown(rows: List[Dict[str, str]]) -> str:
    if not rows:
        return "_No change ledger found (was rafayInstallPrep.sh run from this directory?)._\n"
    esc = lambda s: s.replace("|", "\\|")
    out = ["| Time (UTC) | Step | Status | Change | Detail |", "|---|---|---|---|---|"]
    for r in rows:
        name = STEP_NAMES.get(r["step"], r["step"])
        out.append(f"| {r['ts']} | {r['step']}: {name} | {r['status']} | {esc(r['action'])} | {esc(r['detail'])} |")
    return "\n".join(out) + "\n"


# --- Checks -----------------------------------------------------------------------------------

def add(sec: CheckSection, name: str, ok: Optional[bool], detail: str, expected: str = "", actual: str = "",
        why: str = "", warn: bool = False, meta: Optional[dict] = None) -> None:
    """ok=True PASS, ok=False FAIL (or WARN if warn=True), ok=None INFO."""
    status = "INFO" if ok is None else ("PASS" if ok else ("WARN" if warn else "FAIL"))
    sec.add(CheckItem(name=name, status=status, detail=detail, expected=expected or None,
                      actual=actual or None, why=why or None, metadata=meta or {}))


def check_reboot(sec: CheckSection, ledger: List[Dict[str, str]]) -> None:
    bt = boot_time()
    last = None
    for r in ledger:
        try:
            last = max(last or 0, datetime.fromisoformat(r["ts"].replace("Z", "+00:00")).timestamp())
        except ValueError:
            pass
    if last and bt:
        booted = datetime.fromtimestamp(bt, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        add(sec, "Rebooted after prep", bt > last,
            f"Last boot {booted}; prep finished {datetime.fromtimestamp(last, timezone.utc):%Y-%m-%d %H:%M:%S UTC}.",
            "Boot after the last recorded change", booted,
            "Kernel, AppArmor/SELinux and resolver changes only prove themselves after a reboot.", warn=True)
    elif not ledger:
        add(sec, "Change ledger", None, "No ledger; validating end state only.")
    pending = Path("/var/run/reboot-required").exists()
    add(sec, "Pending reboot flag", not pending,
        "/var/run/reboot-required present" if pending else "No reboot pending.",
        "absent", "present" if pending else "absent", "Package updates (kernel) are only active after a reboot.",
        warn=True)


def rocky_real_os() -> bool:
    """True on Rocky Linux even while /etc/os-release is disguised as RHEL (/usr/lib/os-release is left alone)."""
    if Path("/etc/rocky-release").is_file():
        return True
    try:
        return bool(re.search(r'^ID="?rocky"?$', Path("/usr/lib/os-release").read_text(), re.M))
    except OSError:
        return False


def check_rocky(rep: ValidationReport, ledger: List[Dict[str, str]]) -> None:
    """--rocky: the release files read as RHEL (Rafay's preflight/radm accept Ubuntu and RHEL only)."""
    if not rocky_real_os():
        return
    rows = [r for r in ledger if r["step"] == "R" and r["status"] != "skipped"]
    last = rows[-1] if rows else None
    try:
        osr = Path("/etc/os-release").read_text(errors="replace")
    except OSError:
        osr = ""
    m = re.search(r"^ID=(.*)$", osr, re.M)
    id_line = f"ID={m.group(1)}" if m else "no ID line"
    disguised = ROCKY_MARKER in osr
    why = ("Rafay's preflight-check.sh and radm accept Ubuntu and RHEL only; Rocky Linux passes as RHEL of the same "
           "version. A rocky-release package update (dnf update) puts the Rocky files back.")
    sec = rep.new_section("Step R: Rocky Linux presented as RHEL")

    if last and last["status"] == "restored" and not disguised:
        add(sec, "Rocky Linux release files restored", None,
            f"Originals restored with --rocky-restore at {last['ts']}; the host identifies as Rocky Linux again. "
            "Re-apply with ./rafayInstallPrep.sh --rocky-apply before running the Rafay preflight or radm.")
        return
    if not last and not disguised:
        add(sec, "Rocky Linux not presented as RHEL", False,
            f"/etc/os-release has {id_line}; the Rafay preflight lists only Ubuntu 24.04, RHEL 9 and RHEL 10.",
            'ID="rhel"', id_line, why, warn=True)
        return

    add(sec, "/etc/os-release identifies as RHEL", disguised and re.search(r'^ID="?rhel"?$', osr, re.M) is not None,
        f"{id_line}; " + ("disguise marker present" if disguised else "disguise marker missing"),
        'ID="rhel" + ' + ROCKY_MARKER.rstrip("="), id_line, why)
    try:
        rhr = Path("/etc/redhat-release").read_text(errors="replace").strip()
    except OSError:
        rhr = "(missing)"
    add(sec, "/etc/redhat-release identifies as RHEL", rhr.startswith("Red Hat Enterprise Linux release"),
        rhr, "Red Hat Enterprise Linux release X.Y (...)", rhr, why)
    missing = [f for f in ROCKY_FILES if not os.path.lexists(str(ROCKY_BACKUP_DIR) + f)]
    add(sec, "Rocky release file backups", not missing,
        f"Originals in {ROCKY_BACKUP_DIR}" + (f"; missing: {', '.join(missing)}" if missing else " (all present)"),
        f"{len(ROCKY_FILES)} originals", f"{len(ROCKY_FILES) - len(missing)} present",
        "--rocky-restore puts these back; without them only `dnf reinstall rocky-release` can.", warn=True)


def check_prep(rep: ValidationReport, cfg: dict, ledger: List[Dict[str, str]], node_ip: Optional[str]) -> None:
    ost = os_type()
    ran = {r["step"] for r in ledger if r["status"] != "skipped"}
    skipped = {r["step"]: r["detail"] for r in ledger if r["status"] == "skipped"}
    applies = lambda step: not ledger or step in ran
    ctrl = cfg.get("controller", {})
    fqdn, short = ctrl.get("fqdn", ""), ctrl.get("hostname", "")

    data_dir = Path(cfg.get("storage", {}).get("data_dir", "rafayInstallPrep"))
    failed = [r for r in ledger if r["status"].startswith("failed")]
    if failed:
        sec = rep.new_section("Steps that failed during prep")
        for r in failed:
            add(sec, f"Step {r['step']}: {STEP_NAMES.get(r['step'], '')}", False,
                f"Recorded as {r['status']} at {r['ts']}. {r['detail']}".strip(), "ok", r["status"],
                "The node may be only partly configured; later steps can depend on this one.")

    if applies("1"):
        sec = rep.new_section("Step 1: System packages")
        if ost == "ubuntu":
            _, sim = sh(["apt-get", "-s", "-o", "Debug::NoLocking=1", "upgrade"], timeout=120)
            pending = [l.split()[1] for l in sim.splitlines() if l.startswith("Inst ")]
            add(sec, "Packages up to date", not pending,
                f"{len(pending)} upgradable" + (f": {' '.join(pending[:8])}{' ...' if len(pending) > 8 else ''}"
                                                if pending else ""), "0 upgradable", str(len(pending)),
                "Based on the package lists from the last apt-get update.", warn=True)
        else:
            rc, out = sh(["dnf", "-q", "check-update"], timeout=180)
            add(sec, "Packages up to date", rc == 0, "no updates" if rc == 0 else
                (f"{len([l for l in out.splitlines() if l.strip()])} update(s) available" if rc == 100 else out[:200]),
                "no updates", "", warn=True)

    check_rocky(rep, ledger)

    if skipped:
        sec = rep.new_section("Skipped steps")
        for s in sorted(skipped, key=step_key):
            add(sec, f"Step {s}: {STEP_NAMES.get(s, '')}", None, f"Skipped ({skipped[s] or 'no reason recorded'}); not validated.")

    if applies("2"):
        sec = rep.new_section("Step 2: Firewall")
        # Always report ufw (required by the Rafay preflight checks); look in /usr/sbin too in case PATH lacks it
        ufw_bin = shutil.which("ufw") or next((p for p in ("/usr/sbin/ufw", "/sbin/ufw") if os.path.isfile(p)), None)
        if ufw_bin:
            _, ufw = sh([ufw_bin, "status"])
            ufw_first = ufw.splitlines()[0] if ufw else "unknown"
            _, ufw_unit = sh(["systemctl", "is-enabled", "ufw"])
            add(sec, "ufw disabled", "Status: inactive" in ufw and ufw_unit != "enabled",
                f"{ufw_first}; ufw.service {ufw_unit}", "Status: inactive, unit disabled", f"{ufw_first}, {ufw_unit}",
                "Required by the Rafay preflight checks; ufw rules block cluster and controller traffic.")
        else:
            add(sec, "ufw disabled", True, "ufw is not installed; nothing to disable.", "inactive or not installed",
                "not installed", "Required by the Rafay preflight checks.")
        if ost == "ubuntu":
            # dpkg-query exits 0 for any package dpkg still knows about (e.g. "deinstall ok config-files" or
            # "unknown ok not-installed" after a purge), so the status text decides, not the exit code.
            rc, status = sh(["dpkg-query", "-W", "-f", "${Status}", "iptables-persistent"])
            installed = rc == 0 and status.endswith("ok installed")
            add(sec, "iptables-persistent removed", not installed,
                "Still installed." if installed else f"Not installed ({status or 'unknown to dpkg'}).",
                "not installed", status or "absent",
                "Persisted rules would be restored at boot and block cluster traffic.")
            # What actually restores rules at boot: netfilter-persistent + an iptables plugin + a saved rules file
            plugins = sorted(str(p) for p in Path("/usr/share/netfilter-persistent/plugins.d").glob("*ip*tables*"))
            saved = [f for f in ("/etc/iptables/rules.v4", "/etc/iptables/rules.v6") if os.path.isfile(f)]
            add(sec, "No saved firewall rules restored at boot", not (plugins and saved),
                (f"Plugins {plugins} would load {saved} at boot." if plugins and saved else
                 f"Nothing restores saved rules (plugins: {len(plugins)}, saved rule files: {saved or 'none'})."),
                "no iptables restore plugin, or no saved rules", "",
                "OCI Ubuntu images ship REJECT rules in /etc/iptables/rules.v4; restoring them at boot blocks "
                "Kubernetes and controller ports.", meta={"saved": saved})
        else:
            st = unit_state("firewalld")
            _, en = sh(["systemctl", "is-enabled", "firewalld"])
            add(sec, "firewalld stopped and disabled", st != "active" and en not in ("enabled", "enabled-runtime"),
                f"firewalld is {st}, {en or 'not installed'}.", "inactive, disabled", f"{st}, {en}",
                "firewalld blocks pod/service traffic unless configured for Kubernetes.")
        ipt = shutil.which("iptables") or next((p for p in ("/usr/sbin/iptables", "/sbin/iptables")
                                                 if os.path.isfile(p)), None)
        add(sec, "iptables installed", bool(ipt), ipt or "not found", "installed",
            ipt or "missing", "The Rafay preflight checks the iptables rules and skips that check without it; "
            "Step 2 flushes the rules with it.")
        rc, rules = sh([ipt or "iptables", "-S"])
        if rc == 0:
            reject = [l for l in rules.splitlines()
                      if l.startswith(("-A INPUT ", "-A FORWARD ")) and re.search(r"-j (REJECT|DROP)\b", l)]
            add(sec, "No host REJECT/DROP rules in INPUT/FORWARD", not reject,
                f"{len(reject)} rule(s)" + (f": {reject[0]}" if reject else ""), "none", str(len(reject)),
                "Image-supplied rules (e.g. OCI's '-A INPUT -j REJECT --reject-with icmp-host-prohibited') block "
                "Kubernetes and controller ports; Step 2 flushes them and nothing may restore them at boot.",
                meta={"rules": reject})

    if applies("3"):
        sec = rep.new_section("Step 3: Prerequisites")
        for tool in ("bzip2", "pigz", "aria2c", "dig", "python3", "jq"):
            path = shutil.which(tool)
            add(sec, f"{tool} installed", bool(path), path or "not found", "on PATH", path or "missing")
        if ost == "rhel":
            rc, _ = sh(["rpm", "-q", "epel-release"])
            add(sec, "EPEL repository installed", rc == 0, "epel-release " + ("installed" if rc == 0 else "missing"),
                "installed", "")
        check_iscsid(sec, ost)
        check_time_sync(sec, cfg, ost)

    if applies("4"):
        sec = rep.new_section("Step 4: Instance information")
        info = data_dir / "instance.info"
        files = sorted(p.name for p in info.glob("*")) if info.is_dir() else []
        add(sec, "Pre-change state captured", bool(files), f"{info}: {', '.join(files) or 'missing'}",
            "lsblk / cpuinfo / network files", str(len(files)))

    if applies("5"):
        sec = rep.new_section("Step 5: Data disk")
        mp = cfg.get("storage", {}).get("mount_point", "/data")
        mounted = os.path.ismount(mp)
        _, fs = sh(["findmnt", "-n", "-o", "SOURCE,FSTYPE", mp])
        add(sec, f"{mp} mounted", mounted, fs or "not mounted", "mounted (ext4)", fs or "-")
        try:
            fstab = [l for l in Path("/etc/fstab").read_text().splitlines()
                     if not l.lstrip().startswith("#") and len(l.split()) > 1 and l.split()[1] == mp]
        except OSError:
            fstab = []
        _, mounted_uuid = sh(["findmnt", "-n", "-o", "UUID", mp]) if mounted else (1, "")
        add(sec, f"{mp} in /etc/fstab", bool(fstab) and fstab[0].startswith("UUID="),
            fstab[0] if fstab else "no entry", "UUID=<uuid> entry", fstab[0] if fstab else "-",
            "UUID mounts survive device renaming (e.g. NVMe order changes) across reboots.",
            meta={"mounted_uuid": mounted_uuid})
        if fstab and fstab[0].startswith("UUID=") and mounted:
            want = fstab[0].split()[0][len("UUID="):]
            _, got = sh(["findmnt", "-n", "-o", "UUID", mp])
            add(sec, "fstab UUID matches the mounted filesystem", got == want, f"fstab {want}, mounted {got or '?'}",
                want, got, "A stale UUID means the disk will not mount after the next reboot.",
                meta={"fstab_uuid": want, "mounted_uuid": got})

    if applies("6"):
        sec = rep.new_section("Step 6: Hostname & /etc/hosts")
        cur = socket.gethostname()
        add(sec, "Hostname persisted", cur == fqdn, f"Hostname is {cur}.", fqdn, cur,
            "cloud-init or DHCP can reset the hostname at boot.")
        add(sec, "Hostname is RFC 1123", bool(RFC1123.match(cur)), cur, "lowercase a-z 0-9 - .", cur,
            "Kubernetes node names must be valid RFC 1123 names.")
        try:
            hosts = Path("/etc/hosts").read_text()
        except OSError:
            hosts = ""
        lines = [l.split("#", 1)[0].split() for l in hosts.splitlines()]
        mapped = sorted({p[0] for p in lines if len(p) > 1 and fqdn in p[1:]})
        add(sec, "FQDN mapped to node IP", mapped == [node_ip], f"/etc/hosts: {fqdn} -> {mapped or 'none'}",
            node_ip or "node IP", " ".join(mapped) or "-",
            "radm's /opt/rafay_init.sh needs `hostname -i` to return the node IP at every boot.")
        old = [r["detail"].split("old=", 1)[1].split()[0] for r in ledger
               if r["step"] == "6" and "old=" in r["detail"]]
        stale = [o for o in old if o and o not in (fqdn, short) and re.search(rf"\s{re.escape(o)}(\s|$)", hosts)]
        add(sec, "Previous hostname removed", not stale,
            f"Stale entries for {stale}" if stale else (f"No entries for {old}" if old else "No previous hostname recorded."),
            "none", " ".join(stale) or "none")
        hi = hostname_i()["answers"]
        add(sec, "`hostname -i`", hi == [node_ip], " ".join(hi) or "no answer", node_ip or "node IP", " ".join(hi),
            "Must be exactly the node IP (radm reboot-script contract).")
        _, hf = sh(["hostname", "-f"])
        add(sec, "`hostname -f`", hf == fqdn, hf, fqdn, hf)
        if Path("/etc/cloud").is_dir():
            dropin = Path("/etc/cloud/cloud.cfg.d/99-rafay-hostname.cfg")
            add(sec, "cloud-init keeps hostname/hosts", dropin.is_file(),
                str(dropin) if dropin.is_file() else "drop-in missing", "preserve_hostname: true", "",
                "Without it cloud-init may reset the hostname or regenerate /etc/hosts on boot.", warn=True)

    if applies("7") and ost == "ubuntu":
        sec = rep.new_section("Step 7: /etc/resolv.conf & systemd-resolved")
        link = os.readlink("/etc/resolv.conf") if os.path.islink("/etc/resolv.conf") else None
        target_ok = link is not None and os.path.realpath("/etc/resolv.conf") == UPSTREAM_RESOLV
        add(sec, "/etc/resolv.conf -> upstream file", target_ok, f"link: {link or 'not a symlink'}",
            UPSTREAM_RESOLV, link or "regular file / missing",
            "The upstream link is the only layout that survives radm's reboot scripts (rafay_init.sh + symchecker).")
        exists = os.path.exists("/etc/resolv.conf")
        ns = []
        if exists:
            ns = [l.split()[1] for l in Path("/etc/resolv.conf").read_text().splitlines()
                  if l.startswith("nameserver") and len(l.split()) > 1]
        add(sec, "Resolver has nameservers", bool(ns), " ".join(ns) or ("dangling link" if link else "missing"),
            "≥1 routable nameserver", " ".join(ns) or "-")
        st = unit_state("systemd-resolved")
        _, en = sh(["systemctl", "is-enabled", "systemd-resolved"])
        add(sec, "systemd-resolved active and enabled", st == "active" and en == "enabled", f"{st}, {en}",
            "active, enabled", f"{st}, {en}")
        dropin = Path("/etc/systemd/resolved.conf.d/90-rafay.conf")
        text = dropin.read_text() if dropin.is_file() else ""
        add(sec, "resolved: DNSSEC=no, Cache=no-negative", "DNSSEC=no" in text and "Cache=no-negative" in text,
            f"{dropin}: {'present' if text else 'missing'}", "both set", "present" if text else "missing",
            "Avoids DNSSEC failures on private zones and caching NXDOMAIN for records added mid-install.")
        check_pod_resolver(sec, cfg, UPSTREAM_RESOLV)

    if applies("8"):
        sec = rep.new_section("Step 8: Root LVM")
        _, root_src = sh(["findmnt", "-n", "-o", "SOURCE", "/"])
        if root_src.startswith("/dev/mapper/"):
            _, vg = sh(["lvs", "--noheadings", "-o", "vg_name", root_src])
            _, free = sh(["vgs", "--noheadings", "--units", "g", "--nosuffix", "-o", "vg_free", vg.strip()])
            try:
                free_g = float(free.strip() or "nan")
            except ValueError:
                free_g = float("nan")
            add(sec, "Root volume group fully used", free_g < 1.0, f"VG {vg.strip() or '?'}: {free.strip() or '?'} GiB free",
                "< 1 GiB free", free.strip(), "Step 8 extends the root LV and filesystem to 100% of the VG.", warn=True,
                meta={"root_lv": root_src})
        else:
            add(sec, "Root LVM", None, f"Root filesystem is {root_src or 'unknown'} (not LVM); nothing to expand.")

    if applies("9"):
        sec = rep.new_section("Step 9: Security modules")
        if ost == "ubuntu":
            try:
                aa = Path("/sys/module/apparmor/parameters/enabled").read_text().strip()
            except OSError:
                aa = "N"
            add(sec, "AppArmor disabled (runtime)", aa != "Y", f"enabled={aa}", "N", aa,
                "Rafay preflight requires AppArmor off; takes effect after reboot.")
            cmdline = Path("/proc/cmdline").read_text() if Path("/proc/cmdline").exists() else ""
            add(sec, "apparmor=0 on kernel cmdline", "apparmor=0" in cmdline, "present" if "apparmor=0" in cmdline
                else "absent", "apparmor=0", "", "Set via /etc/default/grub.d/99-disable-apparmor.cfg.")
            grub = Path("/etc/default/grub.d/99-disable-apparmor.cfg")
            add(sec, "GRUB drop-in present", grub.is_file() and "apparmor=0" in grub.read_text(), str(grub),
                "apparmor=0", "", "Keeps AppArmor off across kernel updates and reboots.")
            _, aen = sh(["systemctl", "is-enabled", "apparmor"])
            add(sec, "apparmor.service disabled", aen not in ("enabled", "enabled-runtime"), aen or "not installed",
                "disabled", aen)
        elif shutil.which("getenforce"):
            _, se = sh(["getenforce"])
            add(sec, "SELinux disabled", se == "Disabled", se, "Disabled", se)
            try:
                secfg = re.search(r"^SELINUX=(\S+)", Path("/etc/selinux/config").read_text(), re.M)
            except OSError:
                secfg = None
            add(sec, "SELinux disabled in /etc/selinux/config", bool(secfg) and secfg.group(1) == "disabled",
                f"SELINUX={secfg.group(1) if secfg else '?'}", "SELINUX=disabled", "")
            fst = unit_state("fapolicyd")
            add(sec, "fapolicyd stopped", fst != "active", fst, "inactive", fst,
                "fapolicyd blocks CNI plugin binaries from executing.")

    if applies("10"):
        sec = rep.new_section("Step 10: Swap & kernel floors")
        try:
            active = Path("/proc/swaps").read_text().strip().splitlines()[1:]
        except OSError:
            active = []
        add(sec, "No active swap", not active, f"{len(active)} active device(s)", "none",
            " ".join(l.split()[0] for l in active) or "none", "kubelet runs with failSwapOn: true.")
        _, masked = sh(["systemctl", "is-enabled", "swap.target"])
        add(sec, "swap.target masked", masked == "masked", f"swap.target is {masked}.", "masked", masked,
            "Step 10 masks it so systemd cannot re-activate swap at boot.")
        try:
            swap_lines = [l for l in Path("/etc/fstab").read_text().splitlines()
                          if not l.lstrip().startswith("#") and len(l.split()) > 2 and l.split()[2] == "swap"]
        except OSError:
            swap_lines = []
        add(sec, "No swap entries in /etc/fstab", not swap_lines, f"{len(swap_lines)} active swap line(s)", "0",
            str(len(swap_lines)))
        check_sysctl_floors(sec, cfg)

    nm_active = unit_state("NetworkManager") == "active"
    if applies("11") and (ost == "rhel" or nm_active):
        sec = rep.new_section("Step 11: NetworkManager")
        if ost == "rhel":
            conf = Path("/etc/NetworkManager/conf.d/90-dns-none.conf")
            add(sec, "NetworkManager dns=none", conf.is_file() and "dns=none" in conf.read_text(),
                str(conf), "dns=none", "", "DNS is a static /etc/resolv.conf on RHEL nodes.")
            check_pod_resolver(sec, cfg, "/etc/resolv.conf")
        if nm_active:
            nmf = Path("/etc/NetworkManager/conf.d/90-rafay-k8s-unmanaged.conf")
            add(sec, "CNI interfaces unmanaged", nmf.is_file(), str(nmf) if nmf.is_file() else "missing",
                "present", "", "NetworkManager must not reconfigure Calico / kube-proxy interfaces.")

    if applies("12"):
        sec = rep.new_section("Step 12: DNS validation")
        add(sec, "DNS validation", None, "Current DNS state is re-validated in the DNS section below. Local fixes it "
                                         "applied during prep are checked in Steps 6 and 7.")

    if applies("13"):
        sec = rep.new_section("Step 13: Preflight")
        pf = Path(cfg.get("storage", {}).get("data_dir", "rafayInstallPrep")) / "changes.info" / "preflight_check.txt"
        if pf.is_file():
            fails = [l for l in pf.read_text(errors="replace").splitlines() if re.search(r"\bFAIL", l)]
            add(sec, "Preflight report", not fails, f"{len(fails)} FAIL line(s) in {pf}", "0 failures",
                "; ".join(fails[:3]), warn=True)
        else:
            add(sec, "Preflight report", None, f"{pf} not found.")

    extract_dir = None
    if (data_dir / "extract_dir").is_file():
        extract_dir = Path((data_dir / "extract_dir").read_text().strip())

    if applies("14"):
        sec = rep.new_section("Step 14: Controller download")
        rec = next((r["detail"] for r in reversed(ledger) if r["step"] == "14" and "file=" in r["detail"]), "")
        kv = dict(p.split("=", 1) for p in rec.split() if "=" in p)
        tb = cfg.get("tarball", {})
        fname = kv.get("file") or Path(tb.get("url", "")).name
        expected = kv.get("expected") or tb.get("md5", "")
        md5_file = data_dir / "tarball.md5"
        recorded = md5_file.read_text().split()[0] if md5_file.is_file() and md5_file.read_text().split() else ""
        add(sec, "Tarball present", bool(fname) and Path(fname).is_file(), fname or "unknown", "present", "")
        add(sec, "MD5 verified at download", bool(recorded) and recorded == expected,
            f"recorded {recorded or 'none'}, expected {expected or '?'}", expected, recorded,
            "Checksum calculated by Step 14 right after the download.", meta={"file": fname})

    if applies("15"):
        sec = rep.new_section("Step 15: Extraction")
        ok = extract_dir is not None and extract_dir.is_dir() and any(extract_dir.iterdir())
        add(sec, "Controller extracted", ok, f"./{extract_dir}" if extract_dir else "no record of the extract folder",
            "non-empty folder", "")

    if applies("16"):
        sec = rep.new_section("Step 16: Finalize")
        radm = Path("/usr/bin/radm")
        add(sec, "radm installed", radm.is_file() and os.access(radm, os.X_OK), str(radm), "present, executable", "")
        cfg_yaml = Path("config.yaml")
        add(sec, "config.yaml prepared", cfg_yaml.is_file(), str(cfg_yaml.resolve()), "present", "",
            "Edit it before running radm.", warn=True)
        tmpl = extract_dir / "config.yaml-airgap-tmpl" if extract_dir else None
        if cfg_yaml.is_file() and tmpl and tmpl.is_file():
            edited = cfg_yaml.read_bytes() != tmpl.read_bytes()
            add(sec, "config.yaml edited", edited, "edited" if edited else "identical to the template",
                "edited for this site", "", "Set the controller FQDN, certificates, logo path, etc. before radm.",
                warn=True)
        if cfg_yaml.is_file():
            archive = str(extract_dir.resolve()) if extract_dir and extract_dir.is_dir() else None
            want = desired_values(cfg, archive)
            try:
                bad = verify_file(cfg_yaml, want)
            except OSError as e:
                bad = [("config.yaml", "readable", str(e))]
            add(sec, "config.yaml values set", not bad,
                f"all {len(want)} values match" if not bad else
                "; ".join(f"{k}: {format_value(v) if v != '<missing>' else v} (expected {format_value(w)})"
                          for k, w, v in bad),
                "values from rafay_prep_config.json", f"{len(bad)} differ" if bad else "",
                "Step 16 writes deployment size, GAAP, the SMTP sink, archive-directory and the partner values; "
                "radm uses them as-is.", warn=True, meta={"archive": archive, "bad": [k for k, _, _ in bad]})
            try:
                issues = lint_values(want) + lint_text(cfg_yaml.read_text(encoding="utf-8"))
            except OSError as e:
                issues = [str(e)]
            add(sec, "config.yaml lint", not issues, "no problems found" if not issues else "; ".join(issues),
                "valid YAML, no values radm rejects", f"{len(issues)} problem(s)" if issues else "",
                "Catches what would make radm fail later: characters radm rejects in values (e.g. ':' in "
                "partner.product-name), tabs in indentation, unquoted ':' and unbalanced quotes.",
                meta={"archive": archive})


# --- Helpers for host-setting checks ------------------------------------------------------------

RFC1123 = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$")
FLOORS_FILE = "/etc/sysctl.d/90-rafay-sysctl-floors.conf"


def _resolv_nameservers(path: str) -> List[str]:
    try:
        return [l.split()[1] for l in Path(path).read_text().splitlines()
                if l.startswith("nameserver") and len(l.split()) > 1]
    except OSError:
        return []


def _search_domains(path: str) -> List[str]:
    try:
        for l in Path(path).read_text().splitlines():
            if l.startswith("search "):
                return l.split()[1:]
    except OSError:
        pass
    return []


def _process_running(name: str) -> bool:
    for p in Path("/proc").glob("[0-9]*/comm"):
        try:
            if p.read_text().strip() == name:
                return True
        except OSError:
            continue
    return False


def check_pod_resolver(sec: CheckSection, cfg: dict, path: str) -> None:
    """The resolver file pods with dnsPolicy Default (incl. CoreDNS) inherit."""
    ns = [n for n in _resolv_nameservers(path) if not n.startswith("127.")]
    add(sec, "Resolver file used by pods", bool(ns), f"{path}: {' '.join(ns) or 'no routable nameservers'}",
        "routable nameservers", " ".join(ns) or "-",
        "CoreDNS and hostNetwork pods inherit this file; loopback servers are unreachable from pods.")
    maxs = cfg.get("dns_validation", {}).get("max_search_domains", 6)
    sd = _search_domains(path)
    add(sec, "Search-domain budget", len(sd) <= maxs and sum(len(d) + 1 for d in sd) <= 256,
        f"{len(sd)} domain(s): {' '.join(sd) or 'none'}", f"≤{maxs} names, ≤256 chars", str(len(sd)),
        "Pods prepend 3 cluster search domains; glibc limits apply to the combined list.")
    dh = _process_running("dhclient")
    add(sec, "dhclient not rewriting resolv.conf", not dh, "dhclient running" if dh else "dhclient not running",
        "not running", "running" if dh else "not running",
        "A running dhclient can rewrite /etc/resolv.conf on lease renewal.", warn=True)


def check_iscsid(sec: CheckSection, ost: str) -> None:
    """iSCSI initiator installed, iscsid enabled and running (Longhorn attaches volumes over iSCSI)."""
    pkg = "open-iscsi" if ost == "ubuntu" else "iscsi-initiator-utils"
    if ost == "ubuntu":
        rc, status = sh(["dpkg-query", "-W", "-f", "${Status}", pkg])
        installed = rc == 0 and status.endswith("ok installed")
    else:
        rc, _ = sh(["rpm", "-q", pkg])
        installed = rc == 0
    installed = installed or bool(shutil.which("iscsiadm") or os.path.isfile("/usr/sbin/iscsiadm"))
    add(sec, "iSCSI initiator installed", installed, f"{pkg} " + ("installed" if installed else "missing"),
        "installed", "" if installed else "missing",
        "Longhorn (the controller's internal storage) needs iscsiadm/iscsid on every node.", meta={"pkg": pkg})
    st = unit_state("iscsid")
    _, en = sh(["systemctl", "is-enabled", "iscsid"])
    add(sec, "iscsid running", st == "active" and en in ("enabled", "static", "indirect"),
        f"iscsid is {st}, {en or 'unknown'}.", "active, enabled", f"{st}, {en or 'unknown'}",
        "Longhorn volumes can't attach without a running iscsid; enabled so it is back after a reboot.",
        meta={"pkg": pkg})


def check_time_sync(sec: CheckSection, cfg: dict, ost: str) -> None:
    ts = cfg.get("time_sync", {})
    _, sync = sh(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    if ts.get("enabled"):
        svc = "chrony" if ost == "ubuntu" else "chronyd"
        st = unit_state(svc)
        add(sec, "Time sync (chrony)", st == "active" and sync == "yes",
            f"{svc} {st}; synchronized={sync or 'unknown'}; servers: "
            f"{' '.join(ts.get('servers') or []) or 'distro default'}",
            f"{svc} active, synchronized", f"{st}, {sync}", "Certificates and etcd are sensitive to clock skew.")
        tsd = unit_state("systemd-timesyncd")
        add(sec, "systemd-timesyncd stopped", tsd != "active", tsd, "inactive", tsd,
            "Only one time daemon may adjust the clock.")
        if ts.get("servers"):
            conf = Path("/etc/chrony/chrony.conf" if ost == "ubuntu" else "/etc/chrony.conf")
            text = conf.read_text() if conf.is_file() else ""
            missing = [srv for srv in ts["servers"] if f"server {srv} " not in text]
            add(sec, "Configured NTP servers in chrony.conf", "# BEGIN rafayInstallPrep" in text and not missing,
                f"{conf}: " + (f"missing {missing}" if missing else "all configured servers present"),
                " ".join(ts["servers"]), "")
        if ts.get("timezone"):
            _, tz = sh(["timedatectl", "show", "-p", "Timezone", "--value"])
            add(sec, "Timezone", tz == ts["timezone"], tz or "unknown", ts["timezone"], tz)
    else:
        add(sec, "Clock synchronized", sync == "yes",
            f"time_sync disabled in config; synchronized={sync or 'unknown'}"
            + ("" if sync == "yes" else ". Enable time_sync or fix the existing NTP client."),
            "synchronized", sync, "Certificates and etcd are sensitive to clock skew.", warn=True)


def check_sysctl_floors(sec: CheckSection, cfg: dict) -> None:
    floors = cfg.get("host_tuning", {}).get("sysctl_floors", {})
    if not floors:
        return
    low, missing, low_keys = [], [], {}
    for key, want in floors.items():
        rc, cur = sh(["sysctl", "-n", key])
        if rc != 0 or not cur.strip().lstrip("-").isdigit():
            missing.append(key)
        elif int(cur) < int(want):
            low.append(f"{key}={cur} (<{want})")
            low_keys[key] = want
    add(sec, "sysctl floors", not low,
        (f"Below floor: {', '.join(low)}" if low else f"All {len(floors) - len(missing)} floors met ({FLOORS_FILE})")
        + (f"; not on this kernel: {', '.join(missing)}" if missing else ""),
        "each key ≥ floor", f"{len(low)} below",
        "Raised for container density: process count, memory maps, async I/O, connection backlog, neighbour tables.",
        meta={"low": low_keys})


def check_host_baseline(rep: ValidationReport) -> None:
    sec = rep.new_section("Host baseline")
    _, cg = sh(["stat", "-fc", "%T", "/sys/fs/cgroup/"])
    try:
        pid1 = Path("/proc/1/comm").read_text().strip()
    except OSError:
        pid1 = "unknown"
    add(sec, "systemd + cgroup v2", pid1 == "systemd" and cg == "cgroup2fs", f"PID 1={pid1}, /sys/fs/cgroup={cg}",
        "systemd, cgroup2fs", f"{pid1}, {cg}", "The kubelet expects systemd as init and the unified cgroup v2 hierarchy.")
    _, uu = sh(["systemctl", "is-enabled", "unattended-upgrades"])
    if uu and "not-found" not in uu and uu != "not found":
        add(sec, "Unattended upgrades", None, f"unattended-upgrades is {uu}. Automatic package/kernel updates can "
                                              "restart services or change the kernel under the controller.")


def check_radm(rep: ValidationReport, cfg: dict, node_ip: Optional[str], settings) -> None:
    sec = rep.new_section("Controller (radm) health")
    try:
        consul = json.loads(Path("/etc/consul.d/config.json").read_text())
    except (OSError, ValueError):
        consul = {}
    dc = consul.get("datacenter", "edgedc")
    bind = consul.get("bind_addr")

    for unit in ("consul", "registry", "auth-registry", "containerd", "kubelet", "symchecker",
                 "rafay-service-monitor.timer"):
        st = unit_state(unit)
        add(sec, f"{unit} active", st == "active", st, "active", st)
    st = unit_state("disable-tcp-offloading")
    has_flannel = sh(["ip", "link", "show", "flannel.1"])[0] == 0
    cni_confs = " ".join(p.name for p in Path("/etc/cni/net.d").glob("*")) if Path("/etc/cni/net.d").is_dir() else ""
    calico = (sh(["ip", "link", "show", "vxlan.calico"])[0] == 0 or sh(["ip", "link", "show", "tunl0"])[0] == 0
              or "calico" in cni_confs)
    if calico and not has_flannel:
        add(sec, "disable-tcp-offloading", None,
            f"{st}: expected with Calico. The unit only targets flannel.1, which never exists here (see Notes).")
        notes = getattr(rep, "notes", None)
        if notes is not None:
            notes.append(
                "**disable-tcp-offloading.service is expected to fail on this node.** radm installs it to disable TCP "
                "checksum offloading on Flannel's `flannel.1` VXLAN interface. This cluster uses **Calico** "
                f"(`vxlan.calico`{', CNI config: ' + cni_confs if cni_confs else ''}), so `flannel.1` never "
                "appears: the unit waits 10 minutes after every boot, exits 1 and shows in `systemctl --failed`. "
                "It is harmless here and is excluded from the failed-unit check. If you see checksum or "
                "packet-drop problems on VXLAN traffic, the Calico equivalent is `ethtool --offload vxlan.calico "
                "rx off tx off`. Known radm issue (unit should match the CNI in use); include it in the Rafay report.")
    else:
        add(sec, "disable-tcp-offloading", st == "active", st, "active", st)

    add(sec, "jq installed", bool(shutil.which("jq")), shutil.which("jq") or "missing", "present", "",
        "rafay-service-monitor (service-monitor.sh) exits immediately without jq.")
    add(sec, "Consul bind address = node IP = `hostname -i`",
        bool(bind) and bind == node_ip and hostname_i()["answers"] == [node_ip],
        f"bind_addr={bind}, node IP={node_ip}, hostname -i={' '.join(hostname_i()['answers'])}",
        "all equal", "", "rafay_init.sh compares `nameserver $(hostname -i)` with the resolver at every boot.")

    # Resolver survived radm's boot scripts
    real = os.path.realpath("/etc/resolv.conf")
    content = Path("/etc/resolv.conf").read_text() if os.path.exists("/etc/resolv.conf") else ""
    add(sec, "/etc/resolv.conf intact after reboot", real == UPSTREAM_RESOLV and bool(content),
        f"-> {real}" + ("" if content else " (missing target)"), UPSTREAM_RESOLV, real,
        "symchecker relinks a regular /etc/resolv.conf to the non-existent /run/resolvconf/resolv.conf.")
    if bind:
        add(sec, f"Resolver lists Consul ({bind})", f"nameserver {bind}" in content,
            "present" if f"nameserver {bind}" in content else "missing", f"nameserver {bind}", "")

    # Consul names: host + split answers across the kubelet's upstreams
    api_name = f"k8master.service.{dc}.consul"
    host_ans = resolve_local(api_name).get("answers", [])
    add(sec, f"Host resolves {api_name}", bool(host_ans), " ".join(host_ans) or "failed", bind or "node IP",
        " ".join(host_ans), "Every kubeconfig on the host uses this name for the API server.")
    upstream_ns = []
    if os.path.isfile(UPSTREAM_RESOLV):
        upstream_ns = [l.split()[1] for l in Path(UPSTREAM_RESOLV).read_text().splitlines()
                       if l.startswith("nameserver") and len(l.split()) > 1]
    answers = {ns: query_nameserver_direct(ns, api_name, timeout=3.0) for ns in upstream_ns}
    bad = [ns for ns, r in answers.items() if not r.get("answers")]
    add(sec, "Consul names consistent across pod upstreams", not bad,
        "; ".join(f"{ns} -> {r.get('answers') or r.get('rcode')}" for ns, r in answers.items()),
        "every upstream answers", "",
        "CoreDNS forwards to these servers at random; ones that cannot answer *.consul make pod lookups flap.",
        warn=True)

    # API and console reachability
    kubeconfig = "/etc/kubernetes/admin.conf"
    if shutil.which("kubectl") and os.path.isfile(kubeconfig):
        rc, out = sh(["kubectl", f"--kubeconfig={kubeconfig}", "--request-timeout=10s", "get", "--raw", "/readyz"])
        add(sec, "Kubernetes API ready", rc == 0 and out.strip() == "ok", out.splitlines()[-1] if out else "", "ok",
            "")
    base = settings.wildcard_base.lstrip("*.")
    probe = f"post-{secrets.token_hex(3)}.{base}"
    ips = resolve_local(probe).get("answers", [])
    if ips:
        ip = ips[0]
        try:
            with socket.create_connection((ip, 443), timeout=5):
                ok, detail = True, f"TCP 443 to {ip} ({probe}) connected."
        except OSError as e:
            ok, detail = False, f"TCP 443 to {ip} failed: {e}"
        add(sec, "Console reachable from the node (wildcard:443)", ok, detail, "connect", "",
            "For a public wildcard this requires the cloud NAT/security rules to allow hairpin traffic.", warn=True)
    _, failed = sh(["systemctl", "--failed", "--no-legend", "--plain"])
    failed_units = [l.split()[0] for l in failed.splitlines() if l.strip()]
    unexpected = [u for u in failed_units if not (u.startswith("disable-tcp-offloading") and calico and not has_flannel)]
    add(sec, "No unexpected failed units", not unexpected, " ".join(unexpected) or "none", "none", "", warn=True,
        meta={"units": unexpected})


# --- Report -----------------------------------------------------------------------------------

def build_markdown(prep: ValidationReport, dns, dns_plan_md: str, ledger, meta: dict) -> str:
    total_fail = prep.total_failures + (dns.total_failures if dns else 0)
    total_warn = prep.total_warnings + (dns.total_warnings if dns else 0)
    verdict = "❌ FAILURES" if total_fail else ("⚠️ WARNINGS" if total_warn else "✅ ALL CHECKS PASSED")
    out = [f"# Rafay Controller Node: Post-Install Validation", "",
           "| | |", "|---|---|"] + [f"| {k} | {v} |" for k, v in meta.items()] + [
        f"| Result | **{verdict}**: {total_fail} failed, {total_warn} warnings |", ""]

    problems = [(s.title, i) for r in (prep, dns) if r for s in r.sections for i in s.items
                if i.status in ("FAIL", "WARN")]
    out += ["## Action required", ""]
    if problems:
        out += ["Each item lists what is wrong, why it matters and the commands to fix it (run them from the "
                "rafayInstallPrep directory, then re-run `./rafayInstallPrep.sh --validate`).", ""]
        for n, (t, i) in enumerate(problems, 1):
            out.append(f"### {n}. {'❌' if i.status == 'FAIL' else '⚠️'} {t}: {i.name}")
            out += ["", f"- **Found:** {i.detail}"]
            if i.expected is not None:
                out.append(f"- **Expected:** {i.expected}")
            if i.why:
                out.append(f"- **Why it matters:** {i.why}")
            if i.fix:
                out += ["- **Fix:**", "", "```bash"] + i.fix.strip().splitlines() + ["```"]
            out.append("")
    else:
        out.append("None. All checks passed.")
    notes = getattr(prep, "notes", [])
    if notes:
        out += ["", "## Notes", ""] + [f"- {n}" for n in notes]
    out += ["", "## Changes made by rafayInstallPrep", "", ledger_markdown(ledger),
            prep.render_markdown(heading_level=2, include_fixes=False)
                .replace("# Post-Install Validation", "# Validation of changes", 1)]
    if dns:
        out += ["", dns.render_markdown(heading_level=2, include_fixes=False), dns_plan_md]
    return "\n".join(out) + "\n"


class _Capture:
    """Records everything written to stdout/stderr (in order, ANSI colors included) while still printing it."""

    def __init__(self):
        self.parts: List[str] = []

    def tee(self, stream):
        cap = self

        class _Tee:
            def write(self, data):
                cap.parts.append(data)
                return stream.write(data)

            def __getattr__(self, name):   # isatty, flush, encoding, fileno, ... come from the real stream
                return getattr(stream, name)
        return _Tee()

    def text(self) -> str:
        return "".join(self.parts)


def main():
    parser = argparse.ArgumentParser(
        description="Validate rafayInstallPrep changes after reboot (and the radm install, when present)")
    parser.add_argument("-c", "--config", type=Path, default=Path("rafay_prep_config.json"))
    parser.add_argument("--ledger", type=Path, help="Change ledger (default: <data_dir>/changes.info/changes.tsv)")
    parser.add_argument("-o", "--output", type=Path, help="Markdown report path "
                                                          "(default: <data_dir>/post_validation_<UTC>.md); the "
                                                          "terminal output is saved next to it as .ansi")
    parser.add_argument("--stage", choices=["auto", "prep", "radm"], default="auto",
                        help="prep = prep checks only; radm = include controller checks; auto = detect radm")
    parser.add_argument("-f", "--fqdn")
    parser.add_argument("-w", "--wildcard-base")
    parser.add_argument("-n", "--node-ip")
    parser.add_argument("-i", "--wildcard-ip")
    parser.add_argument("-s", "--wildcard-scope", choices=["auto", "public", "private"])
    parser.add_argument("--skip-dns", action="store_true", help="Do not run the DNS validator")
    parser.add_argument("--no-color", action="store_true")
    args = parser.parse_args()
    if args.no_color:
        set_color_mode(False)

    cfg = get_merged_config(args.config)
    if args.fqdn:
        cfg.setdefault("controller", {})["fqdn"] = args.fqdn
    data_dir = Path(cfg.get("storage", {}).get("data_dir", "rafayInstallPrep"))
    ledger = read_ledger(args.ledger or data_dir / "changes.info" / "changes.tsv")
    settings = load_settings(args.config, fqdn=args.fqdn, wildcard_base=args.wildcard_base, node_ip=args.node_ip,
                             wildcard_ip=args.wildcard_ip, wildcard_scope=args.wildcard_scope)
    node_ip = settings.node_ip or detect_node_ip()
    settings.node_ip = node_ip  # the DNS run must compare against the same node IP

    radm_present = Path("/etc/consul.d/config.json").is_file() or Path("/etc/kubernetes/admin.conf").is_file()
    stage = args.stage if args.stage != "auto" else ("radm" if radm_present else "prep")

    stamp = datetime.now(timezone.utc)
    output = args.output or data_dir / f"post_validation_{stamp:%Y%m%dT%H%M%SZ}.md"
    # Everything printed below (progress, results, colors) is also kept in <report>.ansi: `less -R` / `cat` it later
    console_log = output.with_suffix(".ansi")
    capture = _Capture()
    sys.stdout, sys.stderr = capture.tee(sys.stdout), capture.tee(sys.stderr)
    print(bold(f"Post-install validation ({stage}); report: {output}"), file=sys.stderr, flush=True)

    prep = ValidationReport(title="Post-Install Validation")
    prep.notes = []   # free-text notes shown near the top of the Markdown report
    _new_section = prep.new_section

    def new_section_with_progress(title):   # a run takes a minute or more; show where it is
        print(f"  … {title}", file=sys.stderr, flush=True)
        return _new_section(title)
    prep.new_section = new_section_with_progress
    check_reboot(prep.new_section("Reboot"), ledger)
    check_prep(prep, cfg, ledger, node_ip)
    check_host_baseline(prep)
    if stage == "radm":
        check_radm(prep, cfg, node_ip, settings)

    dns, plan_md, dns_actions = None, "", []
    if not args.skip_dns:
        print("  … DNS validation (lookups can take up to a minute when servers time out)", file=sys.stderr,
              flush=True)
        dns = run_dns_validation(settings)
        dns_actions = plan_for(dns, settings)
        plan_md = render_plan_markdown(dns_actions)
        attach_dns_fixes(dns, dns_actions)

    try:
        consul_bind = json.loads(Path("/etc/consul.d/config.json").read_text()).get("bind_addr")
    except (OSError, ValueError):
        consul_bind = None
    extract_file = data_dir / "extract_dir"
    ctx = {
        "cfg": cfg, "ost": os_type(), "fqdn": cfg.get("controller", {}).get("fqdn", ""),
        "short": cfg.get("controller", {}).get("hostname", ""), "node_ip": node_ip,
        "mp": cfg.get("storage", {}).get("mount_point", "/data"), "data_dir": str(data_dir),
        "log": str(data_dir / "rafay_install_prep.log"), "bind": consul_bind,
        "extract_dir": extract_file.read_text().strip() if extract_file.is_file() else None,
    }
    unfixed = attach_fixes(prep, ctx)
    if dns:
        unfixed += attach_fixes(dns, ctx)   # DNS items without a plan action (should be none)
    for name in unfixed:
        print(f"  (no automatic fix text for '{name}': see the check's details)", file=sys.stderr)

    meta = {"Host": socket.gethostname(), "Node IP": node_ip or "unknown", "Stage": stage,
            "Validated (UTC)": stamp.strftime("%Y-%m-%d %H:%M:%S"), "Ledger entries": len(ledger)}
    write_text(output, build_markdown(prep, dns, plan_md, ledger, meta))

    print(prep.render_console())
    for n in getattr(prep, "notes", []):
        print(bold("NOTE: ") + re.sub(r"[*`]", "", n))
    if dns:
        print(dns.render_console())
    fails = prep.total_failures + (dns.total_failures if dns else 0)
    warns = prep.total_warnings + (dns.total_warnings if dns else 0)
    print(bold(f"\nPost-install validation ({stage}): {fails} failed, {warns} warnings. Report: {output}"))
    print(bold(f"Terminal output (with colors): {console_log}   view: less -R {console_log}"))
    sys.stdout.flush()
    write_text(console_log, capture.text())
    sys.exit(2 if fails else (1 if warns else 0))


if __name__ == "__main__":
    main()
