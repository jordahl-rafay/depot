"""Idempotent Host and Network Configuration Manager."""
