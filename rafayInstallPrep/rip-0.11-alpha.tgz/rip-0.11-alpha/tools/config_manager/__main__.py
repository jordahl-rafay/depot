"""Entrypoint for python3 -m tools.config_manager."""

from tools.config_manager.manager import main

if __name__ == "__main__":
    main()
