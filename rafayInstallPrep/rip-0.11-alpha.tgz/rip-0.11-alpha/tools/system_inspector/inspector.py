"""Inspects node hardware sizing, kernel, OS, swap, and security module status."""

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, Any

from tools.common.colors import bold, green, yellow, red, cyan, blue, dim, status_pass, status_warn, status_fail


def get_os_info() -> Dict[str, Any]:
    """Retrieve OS distribution and version from /etc/os-release."""
    info = {
        "id": "unknown",
        "id_like": "",
        "name": platform.system(),
        "version": platform.release(),
        "version_id": "",
        "os_type": "unknown",
    }
    os_release = Path("/etc/os-release")
    if os_release.is_file():
        for line in os_release.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            v = v.strip('"\'')
            if k == "ID":
                info["id"] = v.lower()
            elif k == "ID_LIKE":
                info["id_like"] = v.lower()
            elif k == "NAME":
                info["name"] = v
            elif k == "VERSION_ID":
                info["version_id"] = v

    os_id = info["id"]
    os_like = info["id_like"]
    if os_id == "ubuntu":
        info["os_type"] = "ubuntu"
    elif os_id in ("rhel", "centos", "rocky", "almalinux") or "rhel" in os_like:
        info["os_type"] = "rhel"
    else:
        info["os_type"] = "unknown"

    return info


def get_cpu_info() -> Dict[str, Any]:
    """Inspect CPU model, cores, and physical sockets."""
    cpu_count = os.cpu_count() or 0
    model_name = "Unknown"
    sockets = 1

    try:
        with open("/proc/cpuinfo", "r") as f:
            physical_ids = set()
            for line in f:
                parts = [p.strip() for p in line.split(":", 1)]
                if len(parts) == 2:
                    k, v = parts
                    if k == "model name" and model_name == "Unknown":
                        model_name = v
                    elif k == "physical id":
                        physical_ids.add(v)
            if physical_ids:
                sockets = len(physical_ids)
    except Exception:
        pass

    return {
        "logical_vcpus": cpu_count,
        "sockets": sockets,
        "model": model_name,
    }


def get_memory_info() -> Dict[str, Any]:
    """Inspect RAM and Swap from /proc/meminfo."""
    mem_total_kb = 0
    mem_avail_kb = 0
    swap_total_kb = 0
    swap_free_kb = 0

    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    k = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    if val.isdigit():
                        v_kb = int(val)
                        if k == "MemTotal":
                            mem_total_kb = v_kb
                        elif k == "MemAvailable":
                            mem_avail_kb = v_kb
                        elif k == "SwapTotal":
                            swap_total_kb = v_kb
                        elif k == "SwapFree":
                            swap_free_kb = v_kb
    except Exception:
        pass

    swap_used_kb = swap_total_kb - swap_free_kb

    return {
        "ram_total_gb": round(mem_total_kb / (1024 * 1024), 2),
        "ram_avail_gb": round(mem_avail_kb / (1024 * 1024), 2),
        "swap_total_gb": round(swap_total_kb / (1024 * 1024), 2),
        "swap_used_gb": round(swap_used_kb / (1024 * 1024), 2),
        "swap_active": swap_total_kb > 0,
    }


def get_security_modules() -> Dict[str, Any]:
    """Inspect AppArmor and SELinux enforcement status."""
    # 1. SELinux
    selinux_active = False
    selinux_status = "Disabled / Not Installed"
    if shutil.which("getenforce"):
        try:
            res = subprocess.run(["getenforce"], capture_output=True, text=True)
            status = res.stdout.strip()
            if status:
                selinux_status = status
                selinux_active = status.lower() != "disabled"
        except Exception:
            pass

    # 2. AppArmor
    apparmor_active = False
    apparmor_status = "Disabled"
    aa_param = Path("/sys/module/apparmor/parameters/enabled")
    if aa_param.is_file():
        try:
            val = aa_param.read_text(encoding="utf-8").strip()
            if val == "Y":
                apparmor_active = True
                apparmor_status = "Enabled (Runtime active)"
            else:
                apparmor_status = "Disabled (Kernel parameter = N)"
        except Exception:
            pass
    elif shutil.which("aa-status"):
        try:
            res = subprocess.run(["sudo", "aa-status", "--enabled"], capture_output=True)
            if res.returncode == 0:
                apparmor_active = True
                apparmor_status = "Enabled"
        except Exception:
            pass

    return {
        "selinux": {"active": selinux_active, "status": selinux_status},
        "apparmor": {"active": apparmor_active, "status": apparmor_status},
    }


# Minimum Rafay controller baseline
MIN_VCPUS = 32
MIN_RAM_GB = 64
# MemTotal reports less than the nominal size (kernel/firmware reservations), so allow ~3% headroom
MIN_RAM_GB_REPORTED = 62.0


def inspect_system() -> Dict[str, Any]:
    """Run full system inspection and return structured report."""
    os_info = get_os_info()
    cpu_info = get_cpu_info()
    mem_info = get_memory_info()
    sec_info = get_security_modules()

    # Minimum Rafay controller baseline: MIN_VCPUS vCPUs, MIN_RAM_GB RAM, swap disabled
    sizing_audit = {
        "cpu_meets_min": cpu_info["logical_vcpus"] >= MIN_VCPUS,
        "ram_meets_min": mem_info["ram_total_gb"] >= MIN_RAM_GB_REPORTED,
        "swap_is_disabled": not mem_info["swap_active"],
    }

    return {
        "os": os_info,
        "cpu": cpu_info,
        "memory": mem_info,
        "security": sec_info,
        "sizing_audit": sizing_audit,
    }


def main():
    parser = argparse.ArgumentParser(description="Node Hardware and Security Inspector")
    parser.add_argument("--json", action="store_true", help="Output inspection as JSON")
    parser.add_argument("--export-shell", action="store_true", help="Output sh-compatible variable assignments")
    args = parser.parse_args()

    info = inspect_system()

    if args.export_shell:
        os_type = info["os"]["os_type"]
        os_id = info["os"]["id"]
        vcpus = info["cpu"]["logical_vcpus"]
        ram_gb = info["memory"]["ram_total_gb"]
        swap_active = "true" if info["memory"]["swap_active"] else "false"
        selinux_active = "true" if info["security"]["selinux"]["active"] else "false"
        apparmor_active = "true" if info["security"]["apparmor"]["active"] else "false"

        print(f'OS_TYPE="{os_type}"')
        print(f'OS_ID="{os_id}"')
        print(f'SYSTEM_VCPUS={vcpus}')
        print(f'SYSTEM_RAM_GB={ram_gb}')
        print(f'SWAP_ACTIVE={swap_active}')
        print(f'SELINUX_ACTIVE={selinux_active}')
        print(f'APPARMOR_ACTIVE={apparmor_active}')
        return

    if args.json:
        print(json.dumps(info, indent=2))
        return

    print("=" * 80)
    print(bold(">>> NODE HARDWARE & SYSTEM INSPECTION"))
    print("=" * 80)
    os_str = f"{info['os']['name']} ({info['os']['id']} {info['os']['version_id']})"
    print(f"{cyan('Operating System:'):<22} {bold(os_str)}")
    print(f"{cyan('Kernel Version:'):<22} {platform.release()}")
    print(f"{cyan('CPU Hardware:'):<22} {info['cpu']['logical_vcpus']} vCPUs ({info['cpu']['model']})")
    print(f"{cyan('Memory (RAM):'):<22} {info['memory']['ram_total_gb']} GB Total ({info['memory']['ram_avail_gb']} GB Available)")

    swap_str = f"{info['memory']['swap_total_gb']} GB Active" if info["memory"]["swap_active"] else "Disabled"
    print(f"{cyan('Swap Status:'):<22} {swap_str}")

    print(f"\n{blue('Security Modules:')}")
    print(f"  • {bold('AppArmor:'):<14} {info['security']['apparmor']['status']}")
    print(f"  • {bold('SELinux:'):<14} {info['security']['selinux']['status']}")

    print(f"\n{blue('Rafay Baseline Sizing Check:')}")
    audit = info["sizing_audit"]
    cpu_badge = status_pass() if audit["cpu_meets_min"] else status_warn()
    ram_badge = status_pass() if audit["ram_meets_min"] else status_warn()
    swap_badge = status_pass() if audit["swap_is_disabled"] else status_warn()

    print(f"  • vCPU Check (Min {MIN_VCPUS}):    {cpu_badge} Found {info['cpu']['logical_vcpus']} vCPUs")
    print(f"  • RAM Check (Min {MIN_RAM_GB} GB):  {ram_badge} Found {info['memory']['ram_total_gb']} GB")
    print(f"  • Swap Disabled Check:    {swap_badge} Swap is {swap_str}")
    print("=" * 80)


if __name__ == "__main__":
    main()
