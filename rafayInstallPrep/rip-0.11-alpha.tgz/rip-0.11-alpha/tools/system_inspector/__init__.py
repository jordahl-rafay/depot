"""Node Hardware, OS, and Security Inspector."""
