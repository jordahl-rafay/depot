"""Entrypoint for python3 -m tools.system_inspector."""

from tools.system_inspector.inspector import main

if __name__ == "__main__":
    main()
