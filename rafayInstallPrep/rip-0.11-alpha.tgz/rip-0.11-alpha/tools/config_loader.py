"""Configuration loader for Rafay Host Preparation.

Loads structured JSON (or YAML if pyyaml is installed) configuration,
merges defaults, and provides shell-exportable variables for rafayInstallPrep.sh.
"""

import argparse
import json
import shlex
import os
import sys
from pathlib import Path
from typing import Dict, Any

DEFAULT_CONFIG_PATH = Path("rafay_prep_config.json")

FALLBACK_DEFAULTS = {
    "controller": {
        "fqdn": "rctrl01.rafay.lab",
        "hostname": "rctrl01",
        "node_ip": None,
        "wildcard_base": "rctrl01.rafay.lab",
        "wildcard_ip": None,
        "wildcard_scope": "auto",
        "partner_name": "rafay_partner",
    },
    "tarball": {
        "url": "https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/3.1/rafay-airgapped-controller-v3.1-38-2.tar.gz",
        "md5": "a4c248c2ab91e444607cf5d7e2548bbb",
    },
    "storage": {
        "target_drive": None,
        "mount_point": "/data",
        "data_dir": "rafayInstallPrep",
    },
    "prerequisites": {
        "aria_rpm_url": "https://github.com/asdo92/aria2-static-builds/releases/download/v1.37.0/aria2-1.37.0-linux-gnu-64bit-build1.rpm",
        "preflight_script_url": "https://rafay-airgap-controller.s3.us-west-2.amazonaws.com/Publish/preflight-check.sh",
    },
    "dns_validation": {
        "max_nameservers": 3,
        "max_search_domains": 6,
        "warn_latency_ms": 100,
        "check_tcp": True,
        "public_resolvers": ["8.8.8.8", "1.1.1.1"],
    },
    "host_tuning": {
        "sysctl_floors": {},
        "nm_unmanaged_devices": [],
    },
    "time_sync": {
        "enabled": False,
        "servers": [],
        "timezone": "",
    },
    "ui": {
        "progress_mode": "window",
        "progress_lines": 6,
    },
    # Values Step 16 writes into config.yaml (tools.radm_config); the smtp block matches extras/deploy_mailpit.sh
    "radm_config": {
        "set": {
            "spec.deployment.size": "POC",
            "spec.gaap.enabled": True,
            "spec.smtp.enabled": True,
            "spec.smtp.smtp_address": "smtp-sink.rafay-smtp-sink.svc.cluster.local",
            "spec.smtp.port": 587,
            "spec.smtp.username": "rafay",
            "spec.smtp.password": "cmFmYXk=",
            "spec.smtp.tls_verify": False,
            "spec.app-config.partner.product-name": "Rafay GPU PaaS - POC",
        },
    },
}


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge override dictionary into base."""
    merged = base.copy()
    for k, v in override.items():
        if k in merged and isinstance(merged[k], dict) and isinstance(v, dict):
            merged[k] = deep_merge(merged[k], v)
        else:
            merged[k] = v
    return merged


def load_config_file(path: Path) -> Dict[str, Any]:
    """Load configuration from JSON (or YAML if pyyaml is installed)."""
    if not path.is_file():
        return {}

    content = path.read_text(encoding="utf-8")
    ext = path.suffix.lower()

    if ext in (".yaml", ".yml"):
        try:
            import yaml
            return yaml.safe_load(content) or {}
        except ImportError:
            sys.stderr.write(
                f"[WARN] PyYAML not installed. Cannot parse {path}. Using built-in defaults.\n"
            )
            return {}

    try:
        return json.loads(content)
    except json.JSONDecodeError as e:
        sys.stderr.write(f"[ERROR] Failed to parse JSON config at {path}: {e}\n")
        return {}


def get_merged_config(config_path: Path = DEFAULT_CONFIG_PATH) -> Dict[str, Any]:
    """Merge file configuration on top of fallback defaults."""
    file_cfg = load_config_file(config_path)
    return deep_merge(FALLBACK_DEFAULTS, file_cfg)


def wildcard_ip(config: Dict[str, Any]):
    """Expected wildcard answer; 'expected_ip' is the legacy name for the same setting."""
    ctrl = config.get("controller", {})
    return ctrl.get("wildcard_ip") or ctrl.get("expected_ip")


def export_shell_vars(config: Dict[str, Any]) -> str:
    """Export configuration as sh-compatible variable assignments."""
    ctrl = config.get("controller", {})
    tb = config.get("tarball", {})
    storage = config.get("storage", {})
    prereqs = config.get("prerequisites", {})

    lines = [
        f'DEFAULT_TB_URL="{tb.get("url", "")}"',
        f'DEFAULT_TB_MD5="{tb.get("md5", "")}"',
        f'DEFAULT_RFQDN="{ctrl.get("fqdn", "")}"',
        f'DEFAULT_RHOSTNAME="{ctrl.get("hostname", "")}"',
        f'DEFAULT_WILDCARD_BASE="{ctrl.get("wildcard_base", ctrl.get("fqdn", ""))}"',
        f'DEFAULT_NODE_IP="{ctrl.get("node_ip") or ""}"',
        "SYSCTL_FLOORS=(" + " ".join(shlex.quote(f"{k}={v}") for k, v in
                                    config.get("host_tuning", {}).get("sysctl_floors", {}).items()) + ")",
        "NM_UNMANAGED_DEVICES=" + shlex.quote(";".join(f"interface-name:{d}" for d in
                                    config.get("host_tuning", {}).get("nm_unmanaged_devices", []))),
        f'TIME_SYNC_ENABLED="{str(bool(config.get("time_sync", {}).get("enabled"))).lower()}"',
        "TIME_SYNC_SERVERS=" + shlex.quote(" ".join(config.get("time_sync", {}).get("servers") or [])),
        "TIME_SYNC_TIMEZONE=" + shlex.quote(config.get("time_sync", {}).get("timezone") or ""),
        f'DEFAULT_PROGRESS_MODE="{config.get("ui", {}).get("progress_mode", "window")}"',
        f'DEFAULT_PROGRESS_LINES="{int(config.get("ui", {}).get("progress_lines", 6))}"',
        f'DEFAULT_WILDCARD_IP="{wildcard_ip(config) or ""}"',
        f'DEFAULT_WILDCARD_SCOPE="{ctrl.get("wildcard_scope") or "auto"}"',
        f'DEFAULT_DRIVE="{storage.get("target_drive") or ""}"',
        f'DEFAULT_MOUNT_POINT="{storage.get("mount_point", "/data")}"',
        f'DEFAULT_DATA_DIR="{storage.get("data_dir", "rafayInstallPrep")}"',
        f'ARIA_RPM="{prereqs.get("aria_rpm_url", "")}"',
        f'PREFLIGHT_URL="{prereqs.get("preflight_script_url", "")}"',
    ]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Rafay Prep Configuration Loader")
    parser.add_argument(
        "-c", "--config",
        type=Path,
        default=DEFAULT_CONFIG_PATH,
        help="Path to configuration file (default: rafay_prep_config.json)",
    )
    parser.add_argument(
        "--export-shell",
        action="store_true",
        help="Output sh-compatible variable assignments for eval",
    )
    parser.add_argument(
        "--dump-json",
        action="store_true",
        help="Output merged configuration as formatted JSON",
    )
    args = parser.parse_args()

    cfg = get_merged_config(args.config)

    if args.export_shell:
        print(export_shell_vars(cfg))
    elif args.dump_json:
        print(json.dumps(cfg, indent=2))
    else:
        print(json.dumps(cfg, indent=2))


if __name__ == "__main__":
    main()
