#!/bin/bash

kubectl get po -A | grep -v -e "Running" -e "Completed"
