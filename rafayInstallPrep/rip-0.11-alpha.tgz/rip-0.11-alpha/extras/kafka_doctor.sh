#!/usr/bin/env bash
# kafka_doctor.sh - find and repair the two Kafka problems that keep the GAAP
# controller (gaap-controller-aisrv) from settling on a Rafay controller.
#
# 1. Corrupt broker files after an unclean power-off. The broker crash-loops
#    with "all log dirs ... have failed" / "Malformed line in checkpoint file",
#    and the checkpoint file is full of NUL bytes. With a broker down, GAAP's
#    executor can't create its replication-factor-3 topics and exits.
#    Repair: move the corrupt files to <volume>/quarantine-<UTC>/ (outside
#    Kafka's data dir; Kafka rebuilds them from the log segments) and delete the
#    broker pod so it starts at once.
# 2. GAAP topics with the wrong layout. The executor wants events, cloudevents
#    and model-*-metrics at 10 partitions / replication factor 3. When a topic
#    isn't, the executor deletes and recreates it, but a consumer gets there
#    first through Kafka's auto-create (1 partition, RF 1). Every executor start
#    repeats that, slowly, and the liveness probe kills it before it finishes.
#    Repair: grow each topic in place (add partitions, then reassign replicas
#    across the brokers). Nothing is deleted, so there is no race.
#    Afterwards, crash-looping gaap-controller-aisrv pods are deleted so they
#    restart without the back-off delay.
#
# Usage (on the controller node, as a user with kubectl and sudo):
#   ./kafka_doctor.sh              # check only; changes nothing
#   ./kafka_doctor.sh --fix        # check, show the plan, ask, then repair
#   ./kafka_doctor.sh --fix --yes  # no question
# Exit: 0 healthy (or repaired), 1 problems found / left, 2 error.
# Env:
#   NS              namespace (default rafay-core)
#   BROKER_PREFIX   broker pod name prefix (default kafka-core-broker-)
#   TOPIC_REGEX     GAAP topics (default '^(events|cloudevents|model-.*-metrics)$')
#   WANT_PARTITIONS default 10
#   WANT_RF         default 3
#   WANT_MAX_MSG    max.message.bytes the executor sets on them (default 5242880)
#   WAIT            seconds to wait for a broker / reassignment (default 600)
#
# The broker volume is read where kubelet mounted it on this node (sudo), so
# run this on the broker's node; on a single-node controller it always is.
# A broker whose kafka container is running is only checked, never repaired.
set -euo pipefail

NS="${NS:-rafay-core}"
BROKER_PREFIX="${BROKER_PREFIX:-kafka-core-broker-}"
TOPIC_REGEX="${TOPIC_REGEX:-^(events|cloudevents|model-.*-metrics)$}"
WANT_PARTITIONS="${WANT_PARTITIONS:-10}"
WANT_RF="${WANT_RF:-3}"
WANT_MAX_MSG="${WANT_MAX_MSG:-5242880}"
WAIT="${WAIT:-600}"
KBIN=/opt/bitnami/kafka/bin
BS=localhost:9092
TS=$(date -u +%Y%m%dT%H%M%SZ)

FIX=0; YES=0
for a in "$@"; do
  case "$a" in
    --fix) FIX=1 ;;
    --yes) YES=1 ;;
    -h|--help) sed -n '2,/^set -euo pipefail/p' "${BASH_SOURCE[0]}" | grep '^#' | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; D=$'\e[2m'; N=$'\e[0m'; else B= G= Y= R= D= N=; fi
ok()   { echo "  ${G}ok${N}    $*"; }
warn() { echo "  ${Y}warn${N}  $*"; }
bad()  { echo "  ${R}FAIL${N}  $*"; }
info() { echo "  ${D}$*${N}"; }
die()  { echo "${R}error:${N} $*" >&2; exit 2; }
k()    { kubectl -n "$NS" "$@"; }

command -v kubectl >/dev/null || die "kubectl not found"
k get pods >/dev/null 2>&1 || die "can't list pods in namespace $NS (kubeconfig?)"

PLAN=()          # human-readable plan lines
FIX_BROKERS=()   # "pod|mount|file file ..."
PROBLEMS=0

# ---------------------------------------------------------------- brokers
mapfile -t BROKERS < <(k get pods -o name | sed 's|^pod/||' | grep -E "^${BROKER_PREFIX}[0-9]+$" | sort)
[ ${#BROKERS[@]} -gt 0 ] || die "no pods named ${BROKER_PREFIX}N in $NS"

kafka_ready()   { [ "$(k get pod "$1" -o jsonpath='{.status.containerStatuses[?(@.name=="kafka")].ready}')" = true ]; }
kafka_running() { [ -n "$(k get pod "$1" -o jsonpath='{.status.containerStatuses[?(@.name=="kafka")].state.running}')" ]; }

# Where kubelet mounted the broker's data PVC on this node (empty if not here).
broker_mount() {
  local pod=$1 uid claim pv path
  uid=$(k get pod "$pod" -o jsonpath='{.metadata.uid}')
  claim=$(k get pod "$pod" -o jsonpath='{.spec.volumes[?(@.name=="data")].persistentVolumeClaim.claimName}')
  [ -n "$claim" ] || return 0
  pv=$(k get pvc "$claim" -o jsonpath='{.spec.volumeName}')
  path="/var/lib/kubelet/pods/$uid/volumes/kubernetes.io~csi/$pv/mount"
  sudo test -d "$path/data" && echo "$path"
  return 0
}

# Corrupt metadata files under a Kafka data dir: "<reason>\t<path>" lines.
scan_data() {
  sudo python3 - "$1" <<'PY'
import os, sys
root = sys.argv[1].rstrip("/")
names = {"recovery-point-offset-checkpoint", "replication-offset-checkpoint", "log-start-offset-checkpoint",
         "cleaner-offset-checkpoint", "leader-epoch-checkpoint", "partition.metadata", "meta.properties"}
for d, dirs, files in os.walk(root):
    if d != root:
        dirs[:] = []          # top level and one level of partition dirs only
    for f in files:
        if f not in names:
            continue
        p = os.path.join(d, f)
        try:
            b = open(p, "rb").read()
        except OSError as e:
            print(f"unreadable ({e.strerror})\t{p}")
            continue
        if b"\0" in b:
            print(f"NUL bytes\t{p}")
        elif not b.strip() and d == root:   # empty per-partition leader-epoch files are normal
            print(f"empty\t{p}")
PY
}

echo "${B}Kafka brokers${N} ($NS)"
for pod in "${BROKERS[@]}"; do
  if kafka_ready "$pod"; then state=ready; else state="not ready"; fi
  mount=$(broker_mount "$pod")
  if [ -z "$mount" ]; then
    if [ "$state" = ready ]; then ok "$pod ready (volume not on this node; not scanned)"
    else bad "$pod not ready; its volume isn't mounted on this node: run this script on $(k get pod "$pod" -o jsonpath='{.spec.nodeName}')"; PROBLEMS=$((PROBLEMS + 1)); fi
    continue
  fi
  mapfile -t corrupt < <(scan_data "$mount/data")
  if [ ${#corrupt[@]} -eq 0 ]; then
    if [ "$state" = ready ]; then ok "$pod ready, metadata files clean"
    else
      bad "$pod not ready, but no corrupt metadata files found; see: kubectl -n $NS logs $pod -c kafka --previous"
      PROBLEMS=$((PROBLEMS + 1))
    fi
    continue
  fi
  PROBLEMS=$((PROBLEMS + 1))
  bad "$pod $state; ${#corrupt[@]} corrupt file(s):"
  files=() manual=0
  for line in "${corrupt[@]}"; do
    reason=${line%%$'\t'*}; path=${line#*$'\t'}; rel=${path#"$mount/"}
    info "  $rel  ($reason)"
    if [ "${rel##*/}" = meta.properties ]; then manual=1; else files+=("$rel"); fi
  done
  hint=$(k logs "$pod" -c kafka --previous 2>/dev/null | grep -a -m1 -E 'log dirs .* failed|Malformed line|Error while reading checkpoint' | cut -c1-160 || true)
  [ -z "$hint" ] || info "  last crash: $hint"
  if [ $manual = 1 ]; then
    warn "$pod: meta.properties is corrupt; it holds broker.id/cluster.id and is not repaired automatically"
  fi
  if kafka_running "$pod"; then
    warn "$pod: kafka container is running, so its files are left alone"
  elif [ ${#files[@]} -gt 0 ]; then
    FIX_BROKERS+=("$pod|$mount|${files[*]}")
    PLAN+=("$pod: move ${#files[@]} corrupt file(s) to quarantine-$TS/ on its volume, then delete the pod")
  fi
done

# ---------------------------------------------------------------- topics
RB=""   # a ready broker to run the Kafka tools in
for pod in "${BROKERS[@]}"; do kafka_ready "$pod" && { RB=$pod; break; }; done
kx()  { k exec "$RB" -c kafka -- "$@" </dev/null; }      # no stdin
kxi() { k exec -i "$RB" -c kafka -- "$@"; }              # stdin passed through

TOPIC_FIX=()   # "topic partitions rf maxmsg"
check_topics() {
  TOPIC_FIX=()
  local ids line topic parts rf cfg maxmsg
  mapfile -t ids < <(kx "$KBIN/kafka-broker-api-versions.sh" --bootstrap-server "$BS" 2>/dev/null | grep -o '(id: [0-9]*' | grep -o '[0-9]*' | sort -nu)
  BROKER_IDS=("${ids[@]}")
  while IFS= read -r line; do
    topic=$(sed -n 's/^Topic: \([^[:space:]]*\).*/\1/p' <<<"$line")
    [[ "$topic" =~ $TOPIC_REGEX ]] || continue
    parts=$(sed -n 's/.*PartitionCount: \([0-9]*\).*/\1/p' <<<"$line")
    rf=$(sed -n 's/.*ReplicationFactor: \([0-9]*\).*/\1/p' <<<"$line")
    cfg=${line#*Configs:}
    maxmsg=$(grep -o 'max.message.bytes=[0-9]*' <<<"$cfg" | cut -d= -f2 || true)
    if [ "$parts" -ge "$WANT_PARTITIONS" ] && [ "$rf" -ge "$WANT_RF" ] && [ "${maxmsg:-}" = "$WANT_MAX_MSG" ]; then
      continue
    fi
    TOPIC_FIX+=("$topic $parts $rf ${maxmsg:--}")
  done < <(kx "$KBIN/kafka-topics.sh" --bootstrap-server "$BS" --describe --exclude-internal 2>/dev/null | grep -E '^Topic:')
}

echo "${B}GAAP topics${N} (want $WANT_PARTITIONS partitions, replication factor $WANT_RF)"
TOPICS_OK=0
if [ -z "$RB" ]; then
  bad "no ready broker; can't check topics"; PROBLEMS=$((PROBLEMS + 1))
else
  check_topics
  matched=$(kx "$KBIN/kafka-topics.sh" --bootstrap-server "$BS" --list 2>/dev/null | grep -cE "$TOPIC_REGEX" || true)
  if [ ${#TOPIC_FIX[@]} -eq 0 ]; then
    ok "all $matched GAAP topics have the right layout"; TOPICS_OK=1
  else
    PROBLEMS=$((PROBLEMS + 1))
    bad "${#TOPIC_FIX[@]} of $matched GAAP topics have the wrong layout:"
    for t in "${TOPIC_FIX[@]}"; do read -r name p r m <<<"$t"; info "  $name  partitions=$p rf=$r max.message.bytes=$m"; done
    over=$(for t in "${TOPIC_FIX[@]}"; do read -r name p r m <<<"$t"; [ "$p" -gt "$WANT_PARTITIONS" ] && echo "$name"; done || true)
    [ -z "$over" ] || warn "more than $WANT_PARTITIONS partitions can't be reduced in place: $(echo $over)"
    if [ ${#BROKER_IDS[@]} -lt "$WANT_RF" ] || [ ${#FIX_BROKERS[@]} -gt 0 ]; then
      PLAN+=("topics: grow ${#TOPIC_FIX[@]} topic(s) in place once all brokers are up (checked again after the broker repair)")
    else
      PLAN+=("topics: grow ${#TOPIC_FIX[@]} topic(s) in place to $WANT_PARTITIONS partitions / RF $WANT_RF across brokers ${BROKER_IDS[*]} (no deletes)")
    fi
  fi
fi

AISRV_BAD=()
mapfile -t AISRV_BAD < <(k get pods -o go-template='{{range .items}}{{$n := .metadata.name}}{{range .status.containerStatuses}}{{if .state.waiting}}{{if eq .state.waiting.reason "CrashLoopBackOff"}}{{$n}}{{"\n"}}{{end}}{{end}}{{end}}{{end}}' | grep -E '^gaap-controller-aisrv-[0-9a-f]+-[a-z0-9]+$' | sort -u || true)
echo "${B}GAAP controller${N}"
if [ ${#AISRV_BAD[@]} -eq 0 ]; then ok "no gaap-controller-aisrv pod in CrashLoopBackOff"
else
  warn "in CrashLoopBackOff: ${AISRV_BAD[*]}"
  [ ${#PLAN[@]} -eq 0 ] || PLAN+=("gaap-controller-aisrv: delete crash-looping pods after the repair so they restart at once")
fi

# ---------------------------------------------------------------- plan / fix
echo
if [ $PROBLEMS -eq 0 ]; then echo "${G}${B}Kafka looks healthy.${N}"; exit 0; fi
if [ ${#PLAN[@]} -eq 0 ]; then echo "${Y}Problems found, but nothing this script can repair (see above).${N}"; exit 1; fi
echo "${B}Repair plan${N}"
for p in "${PLAN[@]}"; do echo "  - $p"; done
if [ $FIX = 0 ]; then echo; echo "Nothing changed. Run with --fix to repair."; exit 1; fi
if [ $YES = 0 ]; then
  read -r -p "Apply this plan? [y/N] " a
  [[ "$a" =~ ^[Yy]$ ]] || { echo "cancelled"; exit 1; }
fi

wait_ready() {   # wait_ready <pod>
  local end=$((SECONDS + WAIT))
  until kafka_ready "$1" 2>/dev/null; do
    [ $SECONDS -lt $end ] || return 1
    sleep 10
  done
}

for entry in "${FIX_BROKERS[@]}"; do
  IFS='|' read -r pod mount files <<<"$entry"
  echo "${B}Repairing $pod${N}"
  if kafka_running "$pod"; then warn "kafka container started meanwhile; skipped"; continue; fi
  q="$mount/quarantine-$TS"
  for rel in $files; do
    sudo mkdir -p "$q/$(dirname "$rel")"
    sudo mv "$mount/$rel" "$q/$rel" && info "moved $rel"
  done
  info "quarantined files: quarantine-$TS/ on $pod's volume (/bitnami/kafka/quarantine-$TS in the pod)"
  k delete pod "$pod" --wait=false >/dev/null && info "deleted pod $pod; waiting up to ${WAIT}s for it to become ready"
  sleep 5
  if wait_ready "$pod"; then ok "$pod ready"; else bad "$pod not ready after ${WAIT}s; see: kubectl -n $NS logs $pod -c kafka"; fi
done

if [ "$TOPICS_OK" = 0 ]; then
  echo "${B}Repairing topics${N}"
  RB=""; for pod in "${BROKERS[@]}"; do kafka_ready "$pod" && { RB=$pod; break; }; done
  [ -n "$RB" ] || die "no ready broker"
  check_topics
  if [ ${#BROKER_IDS[@]} -lt "$WANT_RF" ]; then
    bad "only ${#BROKER_IDS[@]} broker(s) up (${BROKER_IDS[*]:-none}); replication factor $WANT_RF needs $WANT_RF"
  elif [ ${#TOPIC_FIX[@]} -eq 0 ]; then
    ok "topics already right"
  else
    n=${#BROKER_IDS[@]}
    json='{"version":1,"partitions":['; sep=
    for t in "${TOPIC_FIX[@]}"; do
      read -r name p r m <<<"$t"
      if [ "$p" -lt "$WANT_PARTITIONS" ]; then
        kx "$KBIN/kafka-topics.sh" --bootstrap-server "$BS" --alter --topic "$name" --partitions "$WANT_PARTITIONS" >/dev/null && info "$name: partitions $p -> $WANT_PARTITIONS"
        p=$WANT_PARTITIONS
      fi
      if [ "$m" != "$WANT_MAX_MSG" ]; then
        kx "$KBIN/kafka-configs.sh" --bootstrap-server "$BS" --alter --entity-type topics --entity-name "$name" --add-config "max.message.bytes=$WANT_MAX_MSG" >/dev/null && info "$name: max.message.bytes=$WANT_MAX_MSG"
      fi
      if [ "$r" -lt "$WANT_RF" ]; then
        for ((i = 0; i < p; i++)); do
          reps=; for ((j = 0; j < WANT_RF; j++)); do reps+="${reps:+,}${BROKER_IDS[$(((i + j) % n))]}"; done
          json+="$sep{\"topic\":\"$name\",\"partition\":$i,\"replicas\":[$reps]}"; sep=,
        done
      fi
    done
    json+=']}'
    if [ -n "$sep" ]; then
      echo "$json" | kxi sh -c 'cat > /tmp/kafka_doctor_reassign.json'
      kx "$KBIN/kafka-reassign-partitions.sh" --bootstrap-server "$BS" --reassignment-json-file /tmp/kafka_doctor_reassign.json --execute >/dev/null \
        && info "replica reassignment started; waiting up to ${WAIT}s"
      end=$((SECONDS + WAIT))
      while :; do
        out=$(kx "$KBIN/kafka-reassign-partitions.sh" --bootstrap-server "$BS" --reassignment-json-file /tmp/kafka_doctor_reassign.json --verify 2>&1 || true)
        grep -q 'in progress' <<<"$out" || break
        [ $SECONDS -lt $end ] || { warn "reassignment still running after ${WAIT}s; it continues in the background"; break; }
        sleep 5
      done
      kx rm -f /tmp/kafka_doctor_reassign.json || true
    fi
    check_topics
    if [ ${#TOPIC_FIX[@]} -eq 0 ]; then ok "all GAAP topics now have $WANT_PARTITIONS partitions / RF $WANT_RF"; TOPICS_OK=1
    else bad "still wrong: $(for t in "${TOPIC_FIX[@]}"; do echo -n "${t%% *} "; done)"; fi
  fi
fi

if [ ${#AISRV_BAD[@]} -gt 0 ]; then
  echo "${B}Restarting crash-looping GAAP pods${N}"
  for pod in "${AISRV_BAD[@]}"; do k delete pod "$pod" --wait=false >/dev/null && info "deleted $pod"; done
fi

echo
echo "Done. Check again in a few minutes: extras/kafka_doctor.sh"
