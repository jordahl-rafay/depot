#!/bin/bash

less -R $1
