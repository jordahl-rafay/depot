#!/usr/bin/env bash
# clean_shutdown.sh - shut a Rafay controller VM down cleanly on a schedule, ahead
# of a forced (policy) power-off.
#
# Why: a forced power-off kills Kafka, ZooKeeper, etcd and the databases
# mid-write, and their Longhorn volumes come back with half-written files (seen:
# a Kafka checkpoint file full of NUL bytes, after which the broker refused to
# start; see extras/kafka_doctor.sh). Stopping everything in order first leaves
# nothing to repair.
#
# Shutdown order (--run):
#   1. stop kubelet, so nothing gets restarted
#   2. stop the app containers (every namespace except longhorn-system and
#      kube-system) in parallel: SIGTERM, then SIGKILL after GRACE seconds
#   3. sync and unmount the Longhorn volumes while Longhorn is still running
#   4. stop the Longhorn containers, then the rest (kube-system: etcd, apiserver, ...)
#   5. stop containerd, sync, power off
# kubelet stays enabled, so everything starts again at the next boot.
#
# Usage:
#   sudo ./clean_shutdown.sh --install      # cron job at SHUTDOWN_TIMES (SHUTDOWN_TZ)
#   ./clean_shutdown.sh --status            # installed job, next run, last log lines
#   ./clean_shutdown.sh --dry-run           # what --run would stop; changes nothing
#   sudo ./clean_shutdown.sh --run [--yes]  # shut down now (asks unless --yes)
#   sudo ./clean_shutdown.sh --uninstall    # remove the cron job and installed copy
# Env:
#   SHUTDOWN_TIMES  comma list of HH:MM (default 07:50,19:50)
#   SHUTDOWN_TZ     zone those times are in (default Asia/Kolkata: the company
#                   power-off runs at 08:00 and 20:00 IST)
#   GRACE           seconds each container gets after SIGTERM (default 60)
#   NO_POWEROFF=1   --run stops everything but leaves the VM up (testing; reboot after)
#   CRI_ENDPOINT    container runtime socket (default unix:///run/containerd/containerd.sock)
#
# --install writes /etc/cron.d/rafay-clean-shutdown, which runs a copy of this
# script in /usr/local/sbin (so moving the repo doesn't break the job) and logs
# to /var/log/rafay-clean-shutdown.log. The times are converted to the system
# clock's zone when you install. IST has no daylight saving time; if the system
# zone does, --install warns, and you re-run it after each change.
set -euo pipefail

SHUTDOWN_TIMES="${SHUTDOWN_TIMES:-07:50,19:50}"
SHUTDOWN_TZ="${SHUTDOWN_TZ:-Asia/Kolkata}"
GRACE="${GRACE:-60}"
CRON_FILE=/etc/cron.d/rafay-clean-shutdown
INSTALLED=/usr/local/sbin/rafay-clean-shutdown
LOG=/var/log/rafay-clean-shutdown.log
KEEP_NS="longhorn-system kube-system"   # stopped after the app containers, in this order
CRI_ENDPOINT="${CRI_ENDPOINT:-unix:///run/containerd/containerd.sock}"
crictl() { command crictl --runtime-endpoint "$CRI_ENDPOINT" "$@"; }

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B= G= Y= R= N=; fi
say()  { echo "$(date -u +%FT%TZ) $*"; }
die()  { echo "${R}error:${N} $*" >&2; exit 2; }
need_root() { [ "$(id -u)" -eq 0 ] || die "run with sudo"; }
SUDO=; [ "$(id -u)" -eq 0 ] || SUDO=sudo

usage() { sed -n '2,/^set -euo pipefail/p' "${BASH_SOURCE[0]}" | grep '^#' | sed 's/^# \{0,1\}//'; }

# "M H" in the system clock's zone for HH:MM in SHUTDOWN_TZ (today's offsets).
local_cron_time() {
  local day; day=$(TZ="$SHUTDOWN_TZ" date +%F)
  date -d "TZ=\"$SHUTDOWN_TZ\" $day $1" '+%-M %-H'
}

check_times() {
  [ -e "/usr/share/zoneinfo/$SHUTDOWN_TZ" ] || die "unknown zone SHUTDOWN_TZ=$SHUTDOWN_TZ"
  local t
  for t in ${SHUTDOWN_TIMES//,/ }; do
    [[ "$t" =~ ^([01][0-9]|2[0-3]):[0-5][0-9]$ ]] || die "bad time '$t' in SHUTDOWN_TIMES (want HH:MM)"
  done
}

cron_active() { systemctl is-active --quiet crond 2>/dev/null || systemctl is-active --quiet cron 2>/dev/null; }

do_install() {
  need_root; check_times
  local self; self=$(readlink -f "${BASH_SOURCE[0]}")
  install -m 0755 "$self" "$INSTALLED"
  {
    echo "# Installed by extras/clean_shutdown.sh on $(date -u +%FT%TZ). Remove with: sudo $INSTALLED --uninstall"
    echo "# Clean shutdown at $SHUTDOWN_TIMES $SHUTDOWN_TZ, written in system time ($(date +%Z))."
    echo "SHELL=/bin/bash"
    echo "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    local t
    for t in ${SHUTDOWN_TIMES//,/ }; do
      echo "$(local_cron_time "$t") * * * root GRACE=$GRACE $INSTALLED --run --yes >> $LOG 2>&1   # $t $SHUTDOWN_TZ"
    done
  } > "$CRON_FILE.tmp"
  chmod 0644 "$CRON_FILE.tmp"; mv "$CRON_FILE.tmp" "$CRON_FILE"
  echo "${G}installed${N} $CRON_FILE  (runs $INSTALLED)"
  sed -n '/^[0-9]/p' "$CRON_FILE" | sed 's/^/  /'
  cron_active || echo "${Y}warning:${N} no cron service is running (crond on RHEL/Rocky, cron on Ubuntu); enable it or the job never fires"
  if [ "$(date -d "$(date +%Y)-01-15" +%z)" != "$(date -d "$(date +%Y)-07-15" +%z)" ]; then
    echo "${Y}warning:${N} the system zone ($(date +%Z)) has daylight saving time; re-run --install after each change"
  fi
}

do_uninstall() {
  need_root
  rm -f "$CRON_FILE" "$INSTALLED"
  echo "removed $CRON_FILE and $INSTALLED (log $LOG kept)"
}

do_status() {
  echo "${B}cron job${N}"
  if [ -f "$CRON_FILE" ]; then
    sed -n '/^[0-9]/p' "$CRON_FILE" | sed 's/^/  /'
    if [ -f "$INSTALLED" ] && ! cmp -s "$INSTALLED" "$(readlink -f "${BASH_SOURCE[0]}")"; then
      echo "  ${Y}note:${N} $INSTALLED differs from this script; re-run --install to update it"
    fi
  else
    echo "  not installed"
  fi
  if cron_active; then echo "  cron service: ${G}running${N}"; else echo "  cron service: ${R}not running${N}"; fi
  echo "${B}schedule${N}  (system zone $(date +%Z), now $(date '+%F %H:%M'))"
  local t
  for t in ${SHUTDOWN_TIMES//,/ }; do
    echo "  $t $SHUTDOWN_TZ = $(date -d "TZ=\"$SHUTDOWN_TZ\" $(TZ="$SHUTDOWN_TZ" date +%F) $t" '+%H:%M %Z')"
  done
  if [ -f "$LOG" ]; then echo "${B}last log lines${N} ($LOG)"; $SUDO tail -n 5 "$LOG" | sed 's/^/  /'; fi
}

# Running container IDs, by phase. Prints "phase id".
containers_by_phase() {
  local ns id
  local -A keep=()
  for ns in $KEEP_NS; do
    for id in $($SUDO crictl --runtime-endpoint "$CRI_ENDPOINT" ps -q --label "io.kubernetes.pod.namespace=$ns"); do keep[$id]=$ns; done
  done
  for id in $($SUDO crictl --runtime-endpoint "$CRI_ENDPOINT" ps -q); do
    if [ -n "${keep[$id]:-}" ]; then echo "${keep[$id]} $id"; else echo "apps $id"; fi
  done
}

longhorn_mounts() {   # deepest first, so bind mounts go before their global mount
  findmnt -rn -o TARGET,SOURCE | awk '$2 ~ "^/dev/longhorn/" {print length($1), $1}' | sort -rn | cut -d' ' -f2-
}

stop_phase() {   # stop_phase <label> <id>...
  local label=$1; shift
  [ $# -gt 0 ] || { say "$label: nothing running"; return 0; }
  say "$label: stopping $# containers (SIGTERM, SIGKILL after ${GRACE}s)"
  printf '%s\n' "$@" | xargs -r -P 32 -n 1 crictl --runtime-endpoint "$CRI_ENDPOINT" stop --timeout "$GRACE" >/dev/null 2>&1 || true
  local left=0 id
  for id in "$@"; do
    [ "$(crictl inspect -o go-template --template '{{.status.state}}' "$id" 2>/dev/null)" = CONTAINER_RUNNING ] && left=$((left + 1))
  done
  say "$label: done ($left still running)"
}

do_dry_run() {
  $SUDO sh -c 'command -v crictl' >/dev/null || die "crictl not found"
  local lines; lines=$(containers_by_phase)
  echo "${B}--run would, in order:${N}"
  echo "  1. stop kubelet"
  echo "  2. stop $(grep -c '^apps ' <<<"$lines" || true) app containers (GRACE=${GRACE}s each, in parallel)"
  echo "  3. sync, unmount $(longhorn_mounts | wc -l) Longhorn mounts"
  local n=4 ns
  for ns in $KEEP_NS; do
    echo "  $n. stop $(grep -c "^$ns " <<<"$lines" || true) $ns containers"; n=$((n + 1))
  done
  echo "  $n. stop containerd, sync, $([ "${NO_POWEROFF:-}" = 1 ] && echo "stay up (NO_POWEROFF=1)" || echo "power off")"
}

do_run() {
  need_root
  if [ "${1:-}" != --yes ]; then
    do_dry_run
    read -r -p "Shut this machine down now? [y/N] " a
    [[ "$a" =~ ^[Yy]$ ]] || { echo "cancelled"; exit 0; }
  fi
  local start=$SECONDS
  say "clean shutdown starting on $(hostname)"
  wall "Clean shutdown in progress (extras/clean_shutdown.sh); powering off in a few minutes." 2>/dev/null || true
  systemctl stop kubelet && say "kubelet stopped" || say "kubelet stop failed; continuing"

  local lines ids ns m
  lines=$(containers_by_phase)
  mapfile -t ids < <(awk '$1 == "apps" {print $2}' <<<"$lines")
  stop_phase "apps" "${ids[@]}"

  sync
  local ok=0 bad=0
  while IFS= read -r m; do
    [ -n "$m" ] || continue
    if umount "$m" 2>/dev/null; then ok=$((ok + 1)); else bad=$((bad + 1)); say "umount failed: $m"; fi
  done < <(longhorn_mounts)
  say "longhorn volumes: $ok unmounted, $bad failed"

  for ns in $KEEP_NS; do
    mapfile -t ids < <(awk -v n="$ns" '$1 == n {print $2}' <<<"$lines")
    stop_phase "$ns" "${ids[@]}"
  done
  mapfile -t ids < <(crictl ps -q)   # anything started meanwhile
  [ ${#ids[@]} -eq 0 ] || stop_phase "leftovers" "${ids[@]}"

  systemctl stop containerd 2>/dev/null && say "containerd stopped" || say "containerd stop failed; continuing"
  sync
  say "clean shutdown finished in $((SECONDS - start))s"
  if [ "${NO_POWEROFF:-}" = 1 ]; then
    say "NO_POWEROFF=1: staying up. Reboot to bring the cluster back (sudo reboot)."
    return 0
  fi
  say "powering off"
  systemctl poweroff
}

case "${1:-}" in
  --install)   do_install ;;
  --uninstall) do_uninstall ;;
  --status)    do_status ;;
  --dry-run)   do_dry_run ;;
  --run)       do_run "${2:-}" ;;
  -h|--help|"") usage ;;
  *) echo "unknown option: $1" >&2; usage; exit 2 ;;
esac
