# rip-0.11-alpha

- Built: 2026-11-06 17:02:27 CST
- Commit: 0456099
- Previous release: rip-0.10.1-alpha

See CHANGELOG.md in the source repository for curated release notes.

## Commits

- extra tools for deployment (8869f94, 2026-11-06)
- Fixes: fill in config.yaml, iptables/iSCSI prep, mailpit IPs, Kafka tools (cfa38f1, 2026-11-06)
- Add --rocky: present Rocky Linux as RHEL for the Rafay preflight and radm (9e47dbe, 2026-11-03)
- Add post-validator fixes, changelog, release script, and kubespray notes (0fcc476, 2026-11-03)

## Files changed

```
 extras/check_settle.sh             |   3 +
 extras/clean_shutdown.sh           | 216 +++++++++++++++++++++++++++
 extras/deploy_mailpit.sh           |  88 +++++++++--
 extras/kafka_doctor.sh             | 308 ++++++++++++++++++++++++++++++++++++++
 extras/kubectl_bashCompletion.sh   |   8 +
 extras/set_kubeconfig.sh           |   5 +
 extras/view_ansi.sh                |   3 +
 lib/rocky.sh                       | 214 ++++++++++++++++++++++++++
 rafayInstallPrep.sh                | 136 +++++++++++++++--
 rafay_prep_config.json             |  18 ++-
 tools/common/reporter.py           |  16 +-
 tools/config_loader.py             |  15 ++
 tools/dns_validator/remediation.py |   2 +
 tools/post_validator/fixes.py      | 462 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 tools/post_validator/validator.py  | 257 ++++++++++++++++++++++++++++----
 tools/radm_config/__init__.py      |   1 +
 tools/radm_config/__main__.py      |  59 ++++++++
 tools/radm_config/editor.py        | 237 +++++++++++++++++++++++++++++
 18 files changed, 1988 insertions(+), 60 deletions(-)
```
