# **Environment Management Delete Utility**

## Overview

A utility designed to safely and systematically delete environment management objects (Service Profiles, Compute Profiles, Environment Templates, Resource Templates, Workflow Handlers, and Config Contexts) from a Rafay environment.

The script is designed to handle complex dependency chains efficiently. When a Service Profile, Compute Profile, or Environment Template is selected for deletion, the script first identifies and deletes the corresponding Service Instances, Compute Instances, or Environment Instances that were created using them. Once related instances are successfully removed, the script proceeds to delete the respective profile or template. 

## Prerequisites

* Python 3.x  
* Dependencies: requests, pyyaml

## Setting up the Config (values.yaml)

The `values.yaml` file needs to be set up for the delete utility.

```
hostenv: <>
opsenv: <>
apikey: <your-api-key>
projectname: <project-name>
debug: False
continue_on_error: True
org_hash: <>	
templates: 
- template-name
compute-profiles: 
- compute-profile-name 
service-profiles: 
- service-profile-name
res-templates: 
- res-template-name 
context: 
- context-name
workflow-handlers: 
- workflowhandler-name
```

The following fields need to be updated:

* **`<hostenv>`** Console URL of the environment  
   *(Example: `console.your-testbed.dev.rafay-edge.net`)*

* **`<opsenv>`** Ops console URL of the environment  
   *(Example: `ops-console.your-testbed.dev.rafay-edge.net`)*

* **`<apikey>`** Partner API key for the environment

* **`<projectname>`** Target project name  
   *(Example: `system-catalog`)*

* **`<org_hash>`** Target Organization ID (Hash)  
* **`<continue_on_error>`** If set to `True`, the script will log errors and proceed to the next item instead of exiting

Note: The script dynamically queries the API to discover all associated versions for Environment and Resource templates, allowing it to systematically delete every version before removing the base template.

## Usage

Place `delete.py` (delete script) and your configured `values.yaml` (config file) in the same directory and execute:

```py
python delete.py
```

## Deletion Workflow

The script first parses the `values.yaml` and prints a structured list of all resources targeted for deletion. This allows you to verify the scope before the process begins.
Cross-Project Ownership Check: For every resource, the script checks if the object is owned by the current project. If it is a shared resource, the utility automatically discovers the owner and redirects the deletion request to the originating project.

**Service Profiles:** Fetches and deletes all instances using the profile, waits for destruction, then deletes the profile.

**Compute Profiles:** Fetches and deletes all instances using the profile, waits for destruction, then deletes the profile.

**Environment Templates**: Scans all projects in the organization for Service/Compute Profiles referencing the template. Automatically destroys those profiles and their instances first. Dynamically fetches all versions. If a version deletion fails with a 400 error (because it is in use), the script parses the error message to find the dependent Environment Instance, deletes that instance, and then retries the version deletion. Finally, it unshares and deletes the base template.

**Resource Templates:** Dynamically fetches and deletes all versions. If blocked by a 400 error indicating the template is used by an Environment Template, the script dynamically discovers the dependent Environment Template (by scanning across all projects), routes a deletion request to it, and then retries the Resource Template deletion. Checks existence, unshares the base template, and deletes it.

**Workflow Handlers:** Unshares the handler and deletes it.

**Config Contexts:** Unshares the context and deletes it.

If an object is marked as "shared" with other projects, the script automatically unshares it (sets `sharing.enabled` to `false`) before attempting the final deletion.

After processing, the script provides a categorized summary:

* **Successes**: Objects successfully removed.

* **Skipped**: Objects not found or already deleted (404s).

* **Failures**: Objects that failed to delete due to unexpected errors.

