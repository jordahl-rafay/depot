import os
import yaml
import json
import requests
import re
import warnings
import sys
import time
import traceback

warnings.filterwarnings('ignore')

# Global variables
error_list = []
run_results = [] 
config = {}

def print_preflight_list():
    print("\n" + "="*20 + " Templates & Profiles to be Deleted " + "="*20)
    
    categories = {
        "configcontexts": config.get("CONTEXTS", []),
        "workflowhandlers": config.get("WORKFLOW_HANDLERS", []),
        "resourcetemplates": config.get("RESTEMPLATES", []),
        "environmenttemplates": config.get("TEMPLATES", []),
        "serviceprofiles": config.get("SPROFILES", []),
        "computeprofiles": config.get("CPROFILES", [])
    }
    
    for kind, items in categories.items():
        if items:
            print(f"\n[{kind}]")
            for item in items:
                name = item.split('/')[-1].split('.')[0]
                ver = "All" if kind in ["environmenttemplates", "resourcetemplates"] else ""
                ver_str = f" (Versions: {ver})" if ver else ""
                print(f"  - {name}{ver_str}")
    print("\n" + "="*20 + " Starting Deletion Process " + "="*20)

def print_final_summary(org_id):
    print("\n" + "="*20 + " Final Deletion Summary " + "="*20)
    
    successes = [r for r in run_results if "Loaded" in r["status"] or "Deleted" in r["status"] or "Successfully removed" in r["message"]]
    skipped = [r for r in run_results if "Skipped" in r["status"] or "Active Skip" in r["status"]]
    failures = [r for r in run_results if "Failed" in r["status"]]
    
    if successes:
        print(f"\n Successes ({len(successes)}):")
        for r in successes:
            ver_str = f" (v: {r['version']})" if r.get('version') and r['version'] != "N/A" else ""
            print(f"  - {r['kind']}/{r['name']}{ver_str}")
            
    if skipped:
        print(f"\n Skipped (Active/Not Found) ({len(skipped)}):")
        for r in skipped:
            ver_str = f" (v: {r['version']})" if r.get('version') and r['version'] != "N/A" else ""
            print(f"  - {r['kind']}/{r['name']}{ver_str} - {r['message']}")
            
    if failures:
        print(f"\n Failures ({len(failures)}):")
        for r in failures:
            ver_str = f" (v: {r['version']})" if r.get('version') and r['version'] != "N/A" else ""
            print(f"  - {r['kind']}/{r['name']}{ver_str} => {r['message']}")
    
    print("\n" + "="*60)

def handle_error(error, context=""):
    global error_list
    error_msg = f"{context}: {str(error)}" if context else str(error)

    # Force the script to always print the error and continue
    error_list.append(error_msg)
    print(f"\033[31m[ERROR] {error_msg}\033[0m")
    print("Continuing with next item...\n")
    return True

def make_rest_api_call(method, url, headers, params, data):
    response = None
    try:
        if config.get("DEBUG", False):
            print("\n" + "="*80)
            print("DEBUG: API REQUEST")
            print("="*80)
            print(f"Method: {method}")
            print(f"URL: {url}")
            print(f"Headers: {headers}")
            if params:
                print(f"Params: {params}")
            print(f"Request Body:")
            if data:
                print(data)
            else:
                print("(empty)")
            print("="*80)

        response = requests.request(
            method, url, headers=headers, params=params, data=data, verify=False
        )

        if config.get("DEBUG", False):
            print("\n" + "="*80)
            print("DEBUG: API RESPONSE")
            print("="*80)
            print(f"Status Code: {response.status_code}")
            print(f"Response Headers: {dict(response.headers)}")
            try:
                response_body = response.content.decode('utf-8', errors='ignore')
            except:
                response_body = str(response.content)
            print(f"Response Body:\n{response_body}")
            print("="*80 + "\n")

    except requests.exceptions.RequestException as e:
        error_msg = f"Error making API call {method} {url}: {e}"
        print(f"\033[31m{error_msg}\033[0m")
        raise RuntimeError(error_msg) from e

    return response

def make_v1_api(method, url, params, data):
    headers = {
        "Content-Type": "application/yaml",
        "X-RAFAY-API-KEYID": config["API_KEY"],
        "X-ORGANIZATION-ID": config["ORG_HASH"],
    }
    return make_rest_api_call(method, url, headers, params, data)

def make_v3_api(method, url, params, data):
    headers = {
        "Content-Type": "application/yaml",
        "X-API-KEY": config["API_KEY"],
        "X-ORGANIZATION-ID": config["ORG_HASH"],
    }
    return make_rest_api_call(method, url, headers, params, data)

def load_all_orgs():
    print("Loading all orgs")
    try:
        response = make_v1_api("GET", config["urls"]["GET_ORGS_V1"], params=None, data=None)
        
        if response.status_code != 200:
            raise Exception(f"Failed to load orgs: {response.status_code} {response.content}")

        org_list = []
        has_default_org = False
        default_org_id = None

        while True:
            data = yaml.safe_load(response.content)
            for k in data["results"]:
                if k['active'] == True and k['approved'] == True and k['name'] != "RafayOperations" and k['name'] != "RafayCommunity":
                    if k['is_default_org'] == True:
                        has_default_org = True
                        default_org_id = k['id']
                    org_list.append(k['id'])
            if data['next'] == None:
                break
            response = make_v1_api("GET", data['next'], params=None, data=None)                 
        if has_default_org:
            org_list = []
            org_list.append(default_org_id)
        print(f"Total organizations found: {len(org_list)},{org_list}")
        return org_list
    except Exception as e:
        handle_error(e, "Error loading organizations")
        return []

def read_values(values_file):
    global config
    
    with open(values_file, "r") as f:
        data = yaml.safe_load(f)
        HOST_ENV = data["hostenv"]
        if not HOST_ENV or len(HOST_ENV) <= 6:
            print(f"Error: HOST_ENV seems to be missing. Got: {HOST_ENV}")
            sys.exit(1)
        OPS_ENV = data["opsenv"]
        if not OPS_ENV or len(OPS_ENV) <= 6:
            print(f"Error: OPS_ENV seems to be missing. Got: {OPS_ENV}")
            sys.exit(1)
        BASE_URL = f"https://{HOST_ENV}"
        OPS_URL = f"https://{OPS_ENV}"
        PROJECT_NAME = data["projectname"]
        if not PROJECT_NAME :
            print(f"Error: PROJECT_NAME seems to be missing. Got: {PROJECT_NAME}")
            sys.exit(1)

        templates = list(dict.fromkeys(data.get("templates") or []))
        shr_templates = list(dict.fromkeys(data.get("shr-templates") or []))
        compute_profiles = list(dict.fromkeys(data.get("compute-profiles") or []))
        service_profiles = list(dict.fromkeys(data.get("service-profiles") or []))
        res_templates = list(dict.fromkeys(data.get("res-templates") or []))
        contexts = list(dict.fromkeys(data.get("context") or []))
        workflow_handlers = list(dict.fromkeys(data.get("workflow-handlers") or []))

        config = {
            "urls": {
                "BASE_URL": BASE_URL,
                "OPS_URL": OPS_URL,
                "URL_ENVIRONMENT": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/environmenttemplates",
                "URL_ENVIRONMENT_DELETE": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/environments/$ENV_NAME$?auto-destroy=true&force=true",
                "URL_RESOURCE": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/resourcetemplates",
                "URL_CONFIGCONTEXT": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/configcontexts",
                "URL_DRIVER": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/drivers",
                "URL_WRKFLW": f"{BASE_URL}/apis/eaas.envmgmt.io/v1/projects/$PROJECT_NAME$/workflowhandlers",
                "URL_CPROFILE": f"{BASE_URL}/apis/paas.envmgmt.io/v1/projects/$PROJECT_NAME$/computeprofiles",
                "URL_CPROFILE_INS": f"{BASE_URL}/apis/paas.envmgmt.io/v1/projects/$PROJECT_NAME$/computeinstances",
                "URL_SPROFILE": f"{BASE_URL}/apis/paas.envmgmt.io/v1/projects/$PROJECT_NAME$/serviceprofiles",
                "URL_SPROFILE_INS": f"{BASE_URL}/apis/paas.envmgmt.io/v1/projects/$PROJECT_NAME$/services",
                "GET_ORGS_V1": f"{OPS_URL}/auth/v1/organizations/?limit=200&offset=0",
                "GET_PROJECTS_V3": f"{BASE_URL}/apis/system.k8smgmt.io/v3/projects"
            },
            "HOST_ENV": data["hostenv"],
            "API_KEY": data["apikey"],
            "ORG_HASH": data["org_hash"],
            "PROJECT_NAME": data["projectname"],
            "DEBUG": data.get("debug", False),
            "CPROFILES": compute_profiles,
            "SPROFILES": service_profiles,
            "TEMPLATES": templates,
            "RESTEMPLATES": res_templates,
            "WORKFLOW_HANDLERS": workflow_handlers,
            "CONTEXTS": contexts,
            "DELETEALLORGS": data.get("delete_from_all_orgs", False),
            "CONTINUE_ON_ERROR": data.get("continue_on_error", False) 
        }
        
        if not config["API_KEY"] or len(config["API_KEY"]) <= 6:
            print(f"Error: API_KEY seems to be missing. Got: {config['API_KEY']}")
            sys.exit(1)

        org_list = []
        if config["DELETEALLORGS"] is True:
            org_list = load_all_orgs()
        else:
            if config["ORG_HASH"] is None:
                print("Nothing to delete from, as org list is empty")
                return
            org_list = config["ORG_HASH"].split(",")
        
        for i1 in org_list:
            config["ORG_HASH"] = i1.split(" ")[0]
            global error_list, run_results
            error_list = [] 
            run_results = []
            
            print(f"\n{'='*80}")
            print(f" PROCESSING ORGANIZATION: {config['ORG_HASH']}")
            print(f"{'='*80}")
            
            print_preflight_list()
            
            try:
                if config["SPROFILES"] is not None: 
                    for name in config["SPROFILES"]:
                        try:
                            delete_service_instances(name)
                            delete_service_profile(name)
                            run_results.append({"kind": "serviceprofiles", "name": name, "version": "", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "serviceprofiles", "name": name, "version": "", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting service profiles {name}")
                            run_results.append({"kind": "serviceprofiles", "name": name, "version": "", "status": "❌ Failed", "message": str(e)})

                if config["CPROFILES"] is not None: 
                    for name in config["CPROFILES"]:
                        try:
                            delete_compute_instances(name)
                            delete_compute_profile(name)
                            run_results.append({"kind": "computeprofiles", "name": name, "version": "", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "computeprofiles", "name": name, "version": "", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting compute profile {name}")
                            run_results.append({"kind": "computeprofiles", "name": name, "version": "", "status": "❌ Failed", "message": str(e)})

                if config["TEMPLATES"] is not None: 
                    for name in config["TEMPLATES"]:
                        try:
                            delete_environment_templates(name)
                            run_results.append({"kind": "environmenttemplates", "name": name, "version": "All", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "environmenttemplates", "name": name, "version": "All", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting environment template {name}")
                            run_results.append({"kind": "environmenttemplates", "name": name, "version": "All", "status": "❌ Failed", "message": str(e)})

                if config["RESTEMPLATES"] is not None: 
                    for name in config["RESTEMPLATES"]:
                        try:
                            delete_resource_templates(name)
                            run_results.append({"kind": "resourcetemplates", "name": name, "version": "All", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "resourcetemplates", "name": name, "version": "All", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting resource template {name}")
                            run_results.append({"kind": "resourcetemplates", "name": name, "version": "All", "status": "❌ Failed", "message": str(e)})

                if config["WORKFLOW_HANDLERS"] is not None: 
                    for name in config["WORKFLOW_HANDLERS"]:
                        try:
                            delete_workflow_handlers(name)
                            run_results.append({"kind": "workflowhandlers", "name": name, "version": "", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "workflowhandlers", "name": name, "version": "", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting workflow handler {name}")
                            run_results.append({"kind": "workflowhandlers", "name": name, "version": "", "status": "❌ Failed", "message": str(e)})

                if config["CONTEXTS"] is not None: 
                    for name in config["CONTEXTS"]:
                        try:
                            delete_config_context(name)
                            run_results.append({"kind": "configcontexts", "name": name, "version": "", "status": "✅ Deleted", "message": "Successfully removed"})
                        except FileNotFoundError:
                            run_results.append({"kind": "configcontexts", "name": name, "version": "", "status": "⚠️ Skipped", "message": "Not found"})
                        except Exception as e:
                            handle_error(e, f"Error deleting config context {name}")
                            run_results.append({"kind": "configcontexts", "name": name, "version": "", "status": "❌ Failed", "message": str(e)})
            
            except Exception as e:
                handle_error(e, "CRITICAL ERROR in deletion loop")
            
            print_final_summary(config["ORG_HASH"])


# ==============================================================================
# CROSS-PROJECT DISCOVERY & SMART DELETION ENGINE
# ==============================================================================

def find_project_for_resource(resource_type, item_name):
    """
    If a resource isn't found in the base project, this searches all projects 
    in the organization to find where the cross-shared dependency is living.
    """
    api_map = {
        "environment": ("eaas.envmgmt.io/v1", "environments"),
        "environmenttemplate": ("eaas.envmgmt.io/v1", "environmenttemplates"),
        "resourcetemplate": ("eaas.envmgmt.io/v1", "resourcetemplates"),
        "serviceprofile": ("paas.envmgmt.io/v1", "serviceprofiles"),
        "computeprofile": ("paas.envmgmt.io/v1", "computeprofiles"),
        "workflowhandler": ("eaas.envmgmt.io/v1", "workflowhandlers"),
        "configcontext": ("eaas.envmgmt.io/v1", "configcontexts")
    }
    
    clean_type = resource_type.replace('\\', '').lower()
    if clean_type not in api_map:
        return None
        
    api_group, endpoint = api_map[clean_type]
    
    response = make_v3_api("GET", config["urls"]["GET_PROJECTS_V3"], None, None)
    if response.status_code != 200:
        print(f"    [Discovery] Warning: Could not fetch project list to find cross-project dependencies.")
        return None
        
    projects = [p['metadata']['name'] for p in yaml.safe_load(response.content).get('items', [])]
    
    for proj in projects:
        if proj == config["PROJECT_NAME"]:
            continue 
            
        check_url = f"{config['urls']['BASE_URL']}/apis/{api_group}/projects/{proj}/{endpoint}/{item_name}"
        resp = make_v3_api("GET", check_url, None, None)
        if resp.status_code == 200:
            return proj
            
    return None

def delete_environment_by_name(env_name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_del_url = (
        config["urls"]["URL_ENVIRONMENT_DELETE"]
        .replace("$PROJECT_NAME$", proj) 
        .replace("$ENV_NAME$", env_name)
    )
    print(f"    [Dependency Engine] Deleting underlying environment: {env_name} (in {proj})")
    response = make_v3_api("DELETE", env_del_url, None, None)
    if response.status_code != 200:
        raise Exception(f"Failed to delete environment {env_name}. Status: {response.status_code}")
    print(f"    [Dependency Engine] Successfully deleted underlying environment: {env_name}")

def resolve_dependencies_from_error(error_msg):
    dependency_map = {
        r"environment:\s*([a-zA-Z0-9\-]+)": delete_environment_by_name,
        r"environmenttemplate:\s*([a-zA-Z0-9\-]+)": delete_environment_templates,
        r"resourcetemplate:\s*([a-zA-Z0-9\-]+)": delete_resource_templates,
        r"serviceprofile:\s*([a-zA-Z0-9\-]+)": delete_service_profile,
        r"computeprofile:\s*([a-zA-Z0-9\-]+)": delete_compute_profile,
        r"workflowhandler:\s*([a-zA-Z0-9\-]+)": delete_workflow_handlers,
        r"configcontext:\s*([a-zA-Z0-9\-]+)": delete_config_context
    }

    resolved_any = False
    
    for pattern, delete_func in dependency_map.items():
        matches = re.findall(pattern, error_msg, re.IGNORECASE)
        if matches:
            unique_deps = list(set(matches))
            resource_type = pattern.split(':')[0].replace('\\', '')
            print(f"    [Dependency Engine] Found blocking {resource_type}(s): {unique_deps}")
            
            for dep_name in unique_deps:
                try:
                    # Try current project first
                    print(f"    [Dependency Engine] Auto-deleting {resource_type} -> {dep_name} (in {config['PROJECT_NAME']})")
                    delete_func(dep_name, target_project=config["PROJECT_NAME"]) 
                except FileNotFoundError:
                    # If it's a cross-project share, search for it elsewhere
                    print(f"    [Dependency Engine] {dep_name} not found in {config['PROJECT_NAME']}. Searching cross-project...")
                    found_proj = find_project_for_resource(resource_type, dep_name)
                    if found_proj:
                        print(f"    [Dependency Engine] Found {dep_name} in project '{found_proj}'. Redirecting deletion...")
                        try:
                            delete_func(dep_name, target_project=found_proj)
                        except Exception as ex:
                            print(f"\033[31m    [Dependency Engine Error] Could not delete {dep_name} in {found_proj}: {ex}\033[0m")
                    else:
                        print(f"\033[31m    [Dependency Engine Error] Could not locate {resource_type} '{dep_name}' in any project.\033[0m")
                except Exception as e:
                    print(f"\033[31m    [Dependency Engine Error] Could not delete {resource_type} '{dep_name}': {e}\033[0m")
                
            resolved_any = True
    
    if not resolved_any:
        raise Exception(f"Dependency Engine could not resolve dependencies in error: {error_msg}")

def smart_delete(delete_url, item_name, version=""):
    max_retries = 3
    item_display = f"{item_name} (v: {version})" if version else item_name
    
    for attempt in range(max_retries):
        response = make_v3_api("DELETE", delete_url, None, None)
        
        if response.status_code == 200:
            print(f" ✅ Deleted {item_display}")
            return True
        elif response.status_code in [400, 502]:
            try:
                error_data = json.loads(response.content)
                error_msg = error_data.get("external") or error_data.get("internal", "")
            except Exception as e:
                # If 502 returns HTML or non-JSON text, capture it safely
                error_msg = str(response.content)
            
            print(f"  [{response.status_code} Error] {item_display} is in use. Resolving dependencies... (Attempt {attempt+1}/{max_retries})")
            
            # If the error is a 502, it usually means upstream is still processing dependency unsharing. 
            if response.status_code == 502:
                time.sleep(5)
            else:
                resolve_dependencies_from_error(error_msg)
        else:
            raise Exception(f"Failed to delete {item_display}. Status: {response.status_code}. Response: {response.content}")
            
    raise Exception(f"Gave up deleting {item_display} after {max_retries} dependency resolution attempts.")


def dict_contains_value(d, target_value):
    """Recursively checks if a dictionary contains a specific exact string value."""
    if isinstance(d, dict):
        for v in d.values():
            if dict_contains_value(v, target_value):
                return True
    elif isinstance(d, list):
        for item in d:
            if dict_contains_value(item, target_value):
                return True
    elif isinstance(d, str):
        if d == target_value:
            return True
    return False

def find_and_delete_dependent_profiles(et_name):
    """
    Proactively scans Service and Compute profiles across ALL projects.
    If they use the target Environment Template, it deletes their instances and the profile.
    """
    # Fetch all accessible projects
    response = make_v3_api("GET", config["urls"]["GET_PROJECTS_V3"], None, None)
    if response.status_code != 200:
        print("    [Proactive Scan] Warning: Could not fetch project list. Defaulting to base project.")
        projects = [config["PROJECT_NAME"]]
    else:
        projects = [p['metadata']['name'] for p in yaml.safe_load(response.content).get('items', [])]

    # Loop through every project in the org
    for proj in projects:
        # 1. Scan Service Profiles in this project
        sp_url = config["urls"]["URL_SPROFILE"].replace("$PROJECT_NAME$", proj)
        resp = make_v3_api("GET", sp_url, None, None)
        if resp.status_code == 200:
            data = yaml.safe_load(resp.content)
            for item in data.get("items", []):
                sp_name = item.get("metadata", {}).get("name")
                spec = item.get("spec", {})
                
                # If the ET name is exactly referenced anywhere in the spec
                if sp_name and dict_contains_value(spec, et_name):
                    print(f"    [Proactive Scan] Service Profile '{sp_name}' (in {proj}) uses Environment Template '{et_name}'. Auto-deleting...")
                    try:
                        delete_service_instances(sp_name, target_project=proj)
                        delete_service_profile(sp_name, target_project=proj)
                    except Exception as e:
                        print(f"\033[31m    [Proactive Scan Error] Failed to delete Service Profile '{sp_name}' in {proj}: {e}\033[0m")
                        print("    Continuing...")
                    
        # 2. Scan Compute Profiles in this project
        cp_url = config["urls"]["URL_CPROFILE"].replace("$PROJECT_NAME$", proj)
        resp = make_v3_api("GET", cp_url, None, None)
        if resp.status_code == 200:
            data = yaml.safe_load(resp.content)
            for item in data.get("items", []):
                cp_name = item.get("metadata", {}).get("name")
                spec = item.get("spec", {})
                
                if cp_name and dict_contains_value(spec, et_name):
                    print(f"    [Proactive Scan] Compute Profile '{cp_name}' (in {proj}) uses Environment Template '{et_name}'. Auto-deleting...")
                    try:
                        delete_compute_instances(cp_name, target_project=proj)
                        delete_compute_profile(cp_name, target_project=proj)
                    except Exception as e:
                        print(f"\033[31m    [Proactive Scan Error] Failed to delete Compute Profile '{cp_name}' in {proj}: {e}\033[0m")
                        print("    Continuing...")

# ==============================================================================
# REFACTORED RESOURCE DELETION FUNCTIONS (With target_project support)
# ==============================================================================

def delete_environment_templates(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_ENVIRONMENT"].replace("$PROJECT_NAME$", proj)
    
    # 1. Fetch base first to check ownership
    deleteurl = f"{env_url}/{name}"
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
        raise FileNotFoundError(f"environment templates {name} not found")
        
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    # If this is a shared child resource, reroute deletion to the actual owner
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_environment_templates(name, target_project=owner_proj)

    print(f"Processing Environment Template: {name} (Project: {proj})")
    
    # =================================================================
    # NEW STEP: PROACTIVELY DELETE DEPENDENT PROFILES AND INSTANCES
    # =================================================================
    find_and_delete_dependent_profiles(name)

    # 2. Delete Versions
    versions_url = f"{env_url}/{name}/versions"
    v_response = make_v3_api("GET", versions_url, None, None)
    
    if v_response.status_code == 200:
        items = yaml.safe_load(v_response.content).get("items", [])
        for item in items:
            ver = item.get("spec", {}).get("version") or item.get("metadata", {}).get("name")
            if ver:
                delete_ver_url = f"{env_url}/{name}/versions/{ver}"
                smart_delete(delete_ver_url, name, ver)
    
    # 3. Unshare Base
    if data.get("spec", {}).get("sharing", {}).get("enabled"):
        data['spec']['sharing'] = {}
        data['spec']['sharing']['enabled'] = False
        posturl = config["urls"]["URL_ENVIRONMENT"].replace("$PROJECT_NAME$", proj)
        make_v3_api("POST", posturl, None, yaml.dump(data))
        
    # 4. Delete Base
    smart_delete(deleteurl, name)

def delete_resource_templates(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_RESOURCE"].replace("$PROJECT_NAME$", proj)
    
    deleteurl = f"{env_url}/{name}"
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
        raise FileNotFoundError(f"resourcetemplate {name} not found")
        
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_resource_templates(name, target_project=owner_proj)

    print(f"Processing Resource Template: {name} (Project: {proj})")
    
    versions_url = f"{env_url}/{name}/versions"
    v_response = make_v3_api("GET", versions_url, None, None)
    
    if v_response.status_code == 200:
        items = yaml.safe_load(v_response.content).get("items", [])
        for item in items:
            ver = item.get("spec", {}).get("version") or item.get("metadata", {}).get("name")
            if ver:
                delete_ver_url = f"{env_url}/{name}/versions/{ver}"
                smart_delete(delete_ver_url, name, ver)

    if data.get("spec", {}).get("sharing", {}).get("enabled"):
        data['spec']['sharing'] = {}
        data['spec']['sharing']['enabled'] = False
        posturl = config["urls"]["URL_RESOURCE"].replace("$PROJECT_NAME$", proj)
        make_v3_api("POST", posturl, None, yaml.dump(data))
        
    smart_delete(deleteurl, name)

def delete_workflow_handlers(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_WRKFLW"].replace("$PROJECT_NAME$", proj)
    deleteurl = f"{env_url}/{name}"
    
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
        raise FileNotFoundError(f"workflow handler {name} not found")
        
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_workflow_handlers(name, target_project=owner_proj)

    print(f"Processing Workflow Handler: {name} (Project: {proj})")
    
    if data.get("spec", {}).get("sharing", {}).get("enabled"):
        data['spec']['sharing']['enabled'] = False
        if 'projects' in data['spec']['sharing']:
            del data['spec']['sharing']['projects']
        make_v3_api("POST", env_url, None, yaml.dump(data))
    
    smart_delete(deleteurl, name)

def delete_service_profile(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_SPROFILE"].replace("$PROJECT_NAME$", proj)
    deleteurl = f"{env_url}/{name}"
    
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
        raise FileNotFoundError(f"service profile {name} not found")
        
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_service_profile(name, target_project=owner_proj)
        
    print(f"Processing Service Profile: {name} (Project: {proj})")
    smart_delete(deleteurl, name)

def delete_compute_profile(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_CPROFILE"].replace("$PROJECT_NAME$", proj)
    deleteurl = f"{env_url}/{name}"
    
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
       raise FileNotFoundError(f"compute profile {name} not found")
       
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_compute_profile(name, target_project=owner_proj)
        
    print(f"Processing Compute Profile: {name} (Project: {proj})")
    smart_delete(deleteurl, name)

def delete_config_context(name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_CONFIGCONTEXT"].replace("$PROJECT_NAME$", proj)
    deleteurl = f"{env_url}/{name}"
    
    response = make_v3_api("GET", deleteurl, None, None)
    
    if response.status_code != 200:
        raise FileNotFoundError(f"config context {name} not found")
        
    data = yaml.safe_load(response.content)
    owner_proj = data.get("metadata", {}).get("project")
    
    if owner_proj and owner_proj != proj:
        print(f"    [Redirect] {name} is owned by '{owner_proj}'. Rerouting deletion...")
        return delete_config_context(name, target_project=owner_proj)

    print(f"Processing Config Context: {name} (Project: {proj})")
    
    if data.get("spec", {}).get("sharing", {}).get("enabled"):
        data['spec']['sharing']['enabled'] = False
        if 'projects' in data['spec']['sharing']:
            del data['spec']['sharing']['projects']
        make_v3_api("POST", env_url, None, yaml.dump(data))
    
    smart_delete(deleteurl, name)


# ==============================================================================
# INSTANCE DELETION FUNCTIONS
# ==============================================================================

def delete_service_instances(target_profile_name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_SPROFILE_INS"].replace("$PROJECT_NAME$", proj)
    response = make_v3_api("GET", env_url, None, None)
    if response.status_code != 200:
        raise Exception(f"Unable to fetch service instances: {response.content}")
    else:
        data = yaml.safe_load(response.content)
        items = data.get("items", [])
        if not items:
            return

        for item in items:
            name = item.get("metadata", {}).get("name")
            if not name:
                continue  

            spec = item.get("spec", {})
            instance_profile = spec.get("serviceProfile", {}).get("name")
            if instance_profile != target_profile_name:
                continue

            print(f"\nTrying to delete service instance: {name} (Matches Profile: {target_profile_name})")
            deleteurl = f"{env_url}/{name}?auto-destroy=true&force=true"
            del_response = make_v3_api("DELETE", deleteurl, None, None)
            
            if del_response.status_code != 200:
                raise Exception(f"Failed to delete service instance {name}")
            else:
                print(f"Waiting for backend destruction to complete for {name}...")
                check_url = f"{env_url}/{name}"
                max_retries = 60      
                sleep_time = 15 
                is_deleted = False
                
                for attempt in range(max_retries):
                    check_response = make_v3_api("GET", check_url, None, None)
                    if check_response.status_code == 404 or check_response.status_code == 502:
                        print(f"\nSuccessfully destroyed service instance {name} on backend.")
                        is_deleted = True
                        break
                    if check_response.status_code == 200:
                        try:
                            check_data = yaml.safe_load(check_response.content)
                            current_status = check_data.get("status", {}).get("status", "unknown")
                            if "fail" in current_status.lower():
                                reason = check_data.get("status", {}).get("reason", "Unknown reason")
                                raise Exception(f"Backend destruction failed for instance {name} with status '{current_status}': {reason}")
                            sys.stdout.write(f"\r  [{attempt+1}/{max_retries}] Still deleting... (Status: {current_status})")
                            sys.stdout.flush()
                        except yaml.YAMLError:
                            sys.stdout.write(f"\r  [{attempt+1}/{max_retries}] Still deleting... (Parsing status...)")
                            sys.stdout.flush()
                    time.sleep(sleep_time)
                print() 
                if not is_deleted:
                    raise Exception(f"Timeout: Service instance {name} did not fully destroy after {max_retries * sleep_time} seconds.")

def delete_compute_instances(target_profile_name, target_project=None):
    proj = target_project or config["PROJECT_NAME"]
    env_url = config["urls"]["URL_CPROFILE_INS"].replace("$PROJECT_NAME$", proj)
    response = make_v3_api("GET", env_url, None, None)
    if response.status_code != 200:
        raise Exception(f"Unable to fetch compute instances: {response.content}")
    else:
        data = yaml.safe_load(response.content)
        items = data.get("items", [])
        if not items:
            return

        for item in items:
            name = item.get("metadata", {}).get("name")
            if not name:
                continue  
            spec = item.get("spec", {})
            instance_profile = spec.get("computeProfile", {}).get("name")
            if instance_profile != target_profile_name:
                continue

            print(f"\nTrying to delete compute instance: {name} (Matches Profile: {target_profile_name})")
            deleteurl = f"{env_url}/{name}?auto-destroy=true&force=true"
            del_response = make_v3_api("DELETE", deleteurl, None, None)
            
            if del_response.status_code != 200:
                raise Exception(f"Failed to delete compute instance {name}")
            else:
                print(f"Waiting for backend destruction to complete for {name}...")
                check_url = f"{env_url}/{name}"
                max_retries = 60      
                sleep_time = 15 
                is_deleted = False
                
                for attempt in range(max_retries):
                    check_response = make_v3_api("GET", check_url, None, None)
                    if check_response.status_code == 404 or check_response.status_code == 502:
                        print(f"\nSuccessfully destroyed compute instance {name} on backend.")
                        is_deleted = True
                        break
                    if check_response.status_code == 200:
                        try:
                            check_data = yaml.safe_load(check_response.content)
                            current_status = check_data.get("status", {}).get("status", "unknown")
                            if "fail" in current_status.lower():
                                reason = check_data.get("status", {}).get("reason", "Unknown reason")
                                raise Exception(f"Backend destruction failed for instance {name} with status '{current_status}': {reason}")
                            sys.stdout.flush()
                        except yaml.YAMLError:
                            sys.stdout.write(f"\r  [{attempt+1}/{max_retries}] Still deleting... (Parsing status...)")
                            sys.stdout.flush()
                    time.sleep(sleep_time)
                print() 
                if not is_deleted:
                    raise Exception(f"Timeout: compute instance {name} did not fully destroy after {max_retries * sleep_time} seconds.")

if __name__ == "__main__":
    try:
        read_values(values_file="values-delete.yaml")
    except Exception as e:
        print(f"\n\033[31mFATAL ERROR: {type(e).__name__}: {e}\033[0m")
        sys.exit(1)