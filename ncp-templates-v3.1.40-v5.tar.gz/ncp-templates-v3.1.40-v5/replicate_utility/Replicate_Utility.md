# Environment Management Replication Utility

## Overview

A utility for replicating environment management objects (workflow handlers, config contexts, resource templates, environment templates, compute profiles, and service profiles) between source and target environment. The tool supports replication from/to API endpoints or local file systems, with automatic data cleaning.

This script targets a top-level object (such as a Service Profile, Compute Profile, or Environment Template), the script parses the object's JSON payload to discover nested references to underlying dependencies (like Resource Templates, Workflow Handlers, and Config Contexts). It recursively traverses and fetches entire dependencies from the source. Then it replicates these objects to the destination.

## Prerequisites:

    \- Python 3

    \- Dependencies: requests, urllib3, pyyaml

## Setting up the Config

The values-replicate.yaml file needs to be set up for the replicate utility.

Edit the values-replicate.yaml (which will look like below):

source_url: <>
scr_project: system-catalog
source_org_id : <>
source_api_key : <>
target_url: <>
target_project: <>
target_org_id: <>
target_api_key: <>
type: serviceprofiles
registry_replace: True

The following fields need to be updated:

* \<source\_url\> \- with *console url* (Example: https://console.\<example.com\>)  
* \<target\_url\> \- with *console url* (Example: https://console.\<example.com\>)  
* \<type\> \- with environmenttemplates or computeprofiles or serviceprofiles  
* It replaces the image registry with the value specified in registry\_replace from values-replicate.yaml if provided; otherwise, no replacement is performed.  
* \<source\_api\_key\> with Partner API key of the source environment.  
* \<target\_api\_key\> with Partner API key of the target environment.  
* \<source\_org\_id\> with Organization ID of the source environment.  
* \<target\_org\_id\> with Organization ID of the target environment.

## Usage

Place replicate-envs.py and your configured values-replicate.yaml in the same directory and execute the below script.

### Step1: Discover Source Items

Scan your source project to identify all available versions of the specified object type. This will    automatically update your values-replicate.yaml with a list under the selected\_items key.

```py
python3 replicate-envs.py --mode list
```

### Step2: Selection

Open values-replicate.yaml in a text editor. Review the selected\_items list and delete any rows for templates or versions that you do not want to migrate. Save the file when finished.

### Step3: Execute Replication

Run the script in replicate mode to begin the migration. The utility will handle dependency resolution, data cleaning, and ordered creation on the target.

```py
python3 replicate-envs.py --mode replicate
```

## Replication Workflow

The script can be executed in either \--mode list or \--mode replicate.

In list mode, it retrieves all available versions of the specified object type (Environment Templates, Compute Profiles, or Service Profiles) from the source and writes them into the values-replicate.yaml file under the selected\_items key. This enables users to review and manually modify the list before proceeding with the migration.

In replicate mode, it reads the selected list from values-replicate.yaml for migration.  
For every selected object, the script parses the JSON payload to identify nested references (e.g., specific Workflow Handlers, Resource Templates, or Config Contexts). It automatically fetches and adds these sub-components to the migration.

It checks the target API to see if the specific version already exists. If found, it skips the object to prevent overwriting or duplication errors.

Before pushing to the destination, the script strips out environment-specific metadata (like id, createdAt, modifiedBy). 

It also dynamically updates:

* **Controller Endpoints:** Updates endpoint URLs if migrating to a new host environment.  
* **Image Registries:** It replaces the image registry with the value specified in registry\_replace from values-replicate.yaml if provided; otherwise, no replacement is performed.

It checks the target environment to see if the exact object/version already exists. If it does, it skips it. Otherwise, it pushes the objects to the target API (or saves them to disk) in the strict creation order required by the API so that dependencies exist before the parent object is created.

If creation fails because the object already exists in another project, the script captures the error, determines the project where the object resides, and redirects the operation to that project. It then updates the object with sharing enabled if the specified version already exists; otherwise, it creates the missing version in the same project.

After processing all organizations, the script provides a categorized summary:

*  **Successes**: Objects successfully migrated.

*  **Skipped**: Objects that are skipped.

*  **Failures**: Objects that failed to migrate due to unexpected errors.