#!/usr/bin/env python3
import os
import sys
import yaml
import copy
import requests
import urllib3
import argparse
import urllib.parse
from pathlib import Path

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Configuration ---
ALLOWED_TYPES = ["environmenttemplates", "computeprofiles", "serviceprofiles"]
CREATION_ORDER = [
    "configcontexts", "workflowhandlers", "resourcetemplates",
    "environmenttemplates", "computeprofiles", "serviceprofiles"
]

# Items containing these strings will be skipped entirely (No API calls, no replication)
EXCLUSION_KEYWORDS = ["wfh-context", "input"]

API_NAMESPACE_MAP = {
    "workflowhandlers": "eaas.envmgmt.io",
    "configcontexts": "eaas.envmgmt.io",
    "resourcetemplates": "eaas.envmgmt.io",
    "environmenttemplates": "eaas.envmgmt.io",
    "computeprofiles": "paas.envmgmt.io",
    "serviceprofiles": "paas.envmgmt.io"
}
VERIFY_SSL = False

# --- Helper Functions ---

def update_controller_endpoint(obj, object_type, host_env):
    if not host_env: return obj
    if object_type == "environmenttemplates":
        contexts = obj.get("spec", {}).get("contexts", [])
        for context in contexts:
            envs = context.get("data", {}).get("envs", [])
            for env_var in envs:
                if env_var.get("key") == "Controller Endpoint": 
                    env_var["value"] = host_env
    elif object_type in ["computeprofiles", "serviceprofiles"]:
        env_vars = obj.get("spec", {}).get("envVars", [])
        for env_var in env_vars:
            if env_var.get("key") == "Controller Endpoint": 
                env_var["value"] = host_env
    return obj

def replace_custom_registry(obj, target_registry):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "image" and isinstance(v, str):
                parts = v.split('/')
                if len(parts) > 1 and ('.' in parts[0] or ':' in parts[0]):
                    parts[0] = target_registry
                    obj[k] = '/'.join(parts)
                else: 
                    obj[k] = f"{target_registry}/{v}"
            else: 
                replace_custom_registry(v, target_registry)
    elif isinstance(obj, list):
        for item in obj: 
            replace_custom_registry(item, target_registry)
    return obj

def find_existing_project(base_url, obj_type, name, api_key, org_id):
    headers = {"Content-Type": "application/json", "X-API-KEY": api_key, "X-ORGANIZATION-ID": org_id}
    endpoints = [
        "/apis/system.k8smgmt.io/v3/projects",
        "/apis/core.k8smgmt.io/v3/projects"
    ]
    
    projects = []
    for ep in endpoints:
        resp = requests.get(f"{base_url.rstrip('/')}{ep}", headers=headers, verify=VERIFY_SSL)
        if resp.status_code == 200:
            projects = [p['metadata']['name'] for p in resp.json().get('items', [])]
            break
            
    for proj in projects:
        if check_exists_on_target(base_url, proj, obj_type, name, None, api_key, org_id):
            return proj
            
    return "defaultproject"

def extract_host_env(target_url):
    try: return urllib.parse.urlparse(target_url).netloc
    except: return None

def build_api_url(base_url, project, object_type):
    ns = API_NAMESPACE_MAP.get(object_type, "eaas.envmgmt.io")
    return f"{base_url.rstrip('/')}/apis/{ns}/v1/projects/{project}/{object_type}"

def fetch_summary_list(url, api_key, org_id):
    headers = {"Content-Type": "application/json", "X-API-KEY": api_key, "X-ORGANIZATION-ID": org_id}
    resp = requests.get(f"{url}?limit=100", headers=headers, verify=VERIFY_SSL)
    resp.raise_for_status()
    return resp.json().get("items", [])

def fetch_versions_list(base_url, project, obj_type, name, api_key, org_id):
    headers = {"X-API-KEY": api_key, "X-ORGANIZATION-ID": org_id}
    url = f"{build_api_url(base_url, project, obj_type)}/{name}/versions"
    resp = requests.get(url, headers=headers, verify=VERIFY_SSL)
    return resp.json().get("items", []) if resp.status_code == 200 else []

def check_exists_on_target(base_url, project, obj_type, name, version, api_key, org_id):
    headers = {"X-API-KEY": api_key, "X-ORGANIZATION-ID": org_id}
    if obj_type in ["computeprofiles", "serviceprofiles", "workflowhandlers", "configcontexts"]:
        url = f"{build_api_url(base_url, project, obj_type)}/{name}"
        return requests.get(url, headers=headers, verify=VERIFY_SSL).status_code == 200
    v_url = f"{build_api_url(base_url, project, obj_type)}/{name}/versions"
    resp = requests.get(v_url, headers=headers, verify=VERIFY_SSL)
    if resp.status_code == 200:
        return any(v.get('spec', {}).get('version') == version for v in resp.json().get("items", []))
    return False

def find_dependencies(obj):
    deps = []
    mapping = {"environmentTemplate": "environmenttemplates", "resources": "resourcetemplates",
               "context": "configcontexts", "inputs": "configcontexts", "workflowHandler": "workflowhandlers"}
    def search(data):
        if isinstance(data, dict):
            for k, v in data.items():
                if k in mapping:
                    items = v if isinstance(v, list) else [v]
                    for item in items:
                        if isinstance(item, str): deps.append((mapping[k], item, None))
                        elif isinstance(item, dict) and "name" in item:
                            ver = item.get("version") or item.get("resourceOptions", {}).get("version")
                            deps.append((mapping[k], item["name"], ver))
                search(v)
        elif isinstance(data, list):
            for item in data: search(item)
    search(obj)
    return deps

def clean_payload(obj, target_project):
    cleaned = copy.deepcopy(obj)
    meta = cleaned.get("metadata", {})
    for field in ["id", "modifiedAt", "createdAt", "projectID", "createdBy", "modifiedBy"]:
        meta.pop(field, None)
    meta["project"] = target_project
    cleaned["metadata"] = meta
    cleaned.pop("status", None)
    if "spec" in cleaned: cleaned["spec"].pop("agents", None)
    if "sharing" not in cleaned["spec"]:
        cleaned["spec"]["sharing"] = {
                "enabled": True,
                "projects": [{"name": "*"}]
            }
    return cleaned

# --- Main Logic ---

def main():
    parser = argparse.ArgumentParser(description="Replicate Rafay Environments")
    parser.add_argument("--mode", choices=["list", "replicate"], required=True, help="Mode of operation")
    args = parser.parse_args()

    if not os.path.exists("values-replicate.yaml"):
        print("❌ Error: values-replicate.yaml not found."); sys.exit(1)

    with open("values-replicate.yaml", "r") as f:
        config = yaml.safe_load(f) or {}

    selected_type = config.get('type')
    if isinstance(selected_type, list): selected_type = selected_type[0]
    
    src_url, target_url = config['source_url'], config['target_url']
    src_key, target_key = config['source_api_key'], config['target_api_key']
    src_org, target_org = config['source_org_id'], config['target_org_id']
    src_proj, target_proj = config['scr_project'], config['target_project']

    if args.mode == "list":
        print(f"🔍 Fetching all {selected_type} and versions...")
        base_items = fetch_summary_list(build_api_url(src_url, src_proj, selected_type), src_key, src_org)
        flat_list = []
        for item in base_items:
            name = item['metadata']['name']
            if selected_type in ["computeprofiles", "serviceprofiles"]:
                flat_list.append({"name": name, "version": "latest"})
            else:
                versions = fetch_versions_list(src_url, src_proj, selected_type, name, src_key, src_org)
                for v in versions:
                    flat_list.append({"name": name, "version": v.get('spec', {}).get('version', 'N/A')})

        config['selected_items'] = flat_list
        with open("values-replicate.yaml", "w") as f:
            yaml.dump(config, f, default_flow_style=False)
        print(f"✅ Successfully written {len(flat_list)} items to values-replicate.yaml. Trim the list then run --mode replicate.")

    elif args.mode == "replicate":
        selected_items = config.get('selected_items', [])
        if not selected_items:
            print("❌ Error: 'selected_items' is empty in values-replicate.yaml."); sys.exit(1)

        print(f"🚀 Starting replication for {len(selected_items)} selected items...")
        reg_replace = config.get('registry_replace', False)
        target_host_env = extract_host_env(target_url)

        all_objects = {}
        queue = [(selected_type, item['name'], item['version'], None) for item in selected_items]

        while queue:
            o_type, name, ver, data = queue.pop(0)
            
            # --- SKIP EXCLUDED ITEMS BEFORE FETCHING ---
            if any(kw in name for kw in EXCLUSION_KEYWORDS):
                continue

            key = (o_type, name, ver)
            if key in all_objects: continue
            
            headers = {"X-API-KEY": src_key, "X-ORGANIZATION-ID": src_org}
            if data is None:
                if o_type in ["computeprofiles", "serviceprofiles", "workflowhandlers", "configcontexts"]:
                    url = f"{build_api_url(src_url, src_proj, o_type)}/{name}"
                    resp = requests.get(url, headers=headers, verify=VERIFY_SSL)
                    if resp.status_code == 200: data = resp.json()
                else:
                    v_list = fetch_versions_list(src_url, src_proj, o_type, name, src_key, src_org)
                    data = next((v for v in v_list if v.get('spec', {}).get('version') == ver), None)

            if not data: 
                print(f"  ⚠️ Warning: Could not find dependency {o_type}/{name}"); continue
            
            exists = check_exists_on_target(target_url, target_proj, o_type, name, ver, target_key, target_org)
            all_objects[key] = {"obj": data, "deps": find_dependencies(data), "ver": ver, "type": o_type, "exists": exists}
            
            for d_type, d_name, d_ver in all_objects[key]["deps"]:
                queue.append((d_type, d_name, d_ver, None))

        for o_type in CREATION_ORDER:
            for key, info in all_objects.items():
                if info['type'] != o_type: continue
                if any(kw in key[1] for kw in EXCLUSION_KEYWORDS): continue
                
                # Initial skip if already found in the target_project
                if info['exists']:
                    print(f"  ⏭️  Exists: {o_type}/{key[1]} (v: {info['ver']})")
                    continue

                current_project = target_proj
                headers = {"Content-Type": "application/json", "X-API-KEY": target_key, "X-ORGANIZATION-ID": target_org}
                success = False
                attempts = 0

                while not success and attempts < 2:
                    attempts += 1
                    
                    # 1. Align payload
                    clean_obj = clean_payload(info['obj'], current_project)
                    clean_obj = update_controller_endpoint(clean_obj, o_type, target_host_env)
                    if reg_replace and str(reg_replace).strip() != "":
                        clean_obj = replace_custom_registry(clean_obj, reg_replace)
                        
                    # 2. VERSION-SPECIFIC CHECK (The Fix)
                    
                    # Before posting, check if THIS specific version exists in 'current_project'

                    # 3. API Execution
                    base_url = build_api_url(target_url, current_project, o_type)
                    resp = requests.post(base_url, json=clean_obj, headers=headers, verify=VERIFY_SSL)

                    if resp.status_code in [200, 201]:
                        print(f"  ✅ Success: {o_type}/{key[1]} (v: {info['ver']}) in '{current_project}'")
                        success = True
                    else:
                        try:
                            err_json = resp.json()
                            err_msg = err_json.get('message', err_json.get('internal', str(err_json)))
                        except:
                            err_msg = resp.text

                        if ("already exists in project" in err_msg or "already exists in another project" in err_msg) and attempts == 1:
                            if "already exists in project " in err_msg:
                                new_proj = err_msg.split("already exists in project ")[-1].strip().rstrip('.').replace("'", "").replace('"', '')
                            else:
                                print(f"  🔍 '{key[1]}' exists in an unknown project. Scanning organization...")
                                new_proj = find_existing_project(target_url, o_type, key[1], target_key, target_org)
                            print(f"  🔄 Redirecting to '{new_proj}' and retrying...")
                            current_project = new_proj
                            # Loop continues to 'Step 2' to check version in the NEW project
                        else:
                            print(f"  ❌ Failed: {o_type}/{key[1]} (v: {info['ver']}) | Error: {err_msg}")
                            break

if __name__ == "__main__":
    main()