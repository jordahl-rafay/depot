import os
import json
import base64
import secrets
import yaml
import requests
import warnings
import tarfile
import re
import sys
import subprocess
import argparse
from pathlib import Path
import shutil

warnings.filterwarnings('ignore')
DEFAULT_REGISTRY = "registry.rafay-edge.net"

# Global configuration and error tracking
config = {}
error_list = []

# ==========================================
# FILE & IMAGE UTILITIES
# ==========================================

def move_and_rename_file(src_file_path, dest_dir_or_file):
    try:
        if not os.path.isfile(src_file_path):
            raise FileNotFoundError(f"Source file not found: {src_file_path}")
        shutil.move(src_file_path, dest_dir_or_file)
        return dest_dir_or_file
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

def run_radm_template_images(domain: str):
    try:
        workdir = Path(os.getcwd()) / "catalog-templates"
        binary_path = workdir / "radm-template-images"
        
        if not os.path.isfile(binary_path):
             print(f"\033[31mError: Binary not found: {binary_path}\033[0m")
             return

        print(f"=======  Loading images =======")
        cmd = ["./radm-template-images", "cluster", "-f", domain]

        process = subprocess.Popen(
            cmd, cwd=workdir, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        error_detected = False
        output = []
        error_keywords = ["error execution phase", "no such file or directory", "error:", "failed"]

        for line in process.stdout:
            print(line, end="")
            output.append(line)
            if any(k in line.lower() for k in error_keywords):
                error_detected = True

        process.wait()
        if process.returncode != 0 or error_detected:
            raise RuntimeError("radm-template-images failed:\n" + "".join(output))
    except Exception as e:
        handle_error(e, "run_radm_template_images", error_type="IMAGE_ERROR")

def derive_star_domain(hostenv: str) -> str:
    if not hostenv: return ""
    prefix = "console."
    return hostenv[len(prefix):] if hostenv.startswith(prefix) else hostenv

def load_images():
    try:
        if config.get("FQDN") is None: return
        host_env = config.get("HOST_ENV")
        if not host_env:
            print("\033[33mWarning: HOST_ENV missing, skip loading images\033[0m")
            return
        star_domain = derive_star_domain(host_env)
        run_radm_template_images(domain=star_domain,)
    except Exception as e:
        handle_error(e, "load_images", error_type="IMAGE_ERROR")

def replace_registry_fqdn(target_dir: str, registry_fqdn: str, search_values=None):
    try:
        if search_values is None:
            search_values = [b"registry.dev.rafay-edge.net", b"registry.rafay-edge.net"]
        if not os.path.exists(target_dir): return

        image_tag_map = config.get("IMAGE_TAG_MAP", {})
        # Clean up any trailing slashes to prevent double-slashes in URLs
        target_registry = (registry_fqdn or DEFAULT_REGISTRY).rstrip('/')
        replacement = target_registry.encode()

        for root, _, files in os.walk(target_dir):
            for name in files:
                if not name.endswith((".yaml", ".yml")): continue
                path = os.path.join(root, name)

                try:
                    with open(path, "rb") as f: data = f.read()
                    new_data = data

                    # 1. Base explicit replacements
                    for search in search_values:
                        new_data = new_data.replace(search, replacement)

                    # 2. Foolproof dynamic tag and path replacement
                    if image_tag_map:
                        text = new_data.decode("utf-8", errors="ignore")
                        original = text
                        
                        for image_path, tags in image_tag_map.items():
                            if isinstance(tags, str): tags = tags.split()
                            
                            # Extract just the base image name (e.g. pytorch-2.1-ubuntu...)
                            image_name = image_path.split('/')[-1]
                            clean_path = image_path.lstrip('/')
                            
                            # Match boundary + any prefix path + image_name + old tag
                            pattern = rf"([\s\"'>]|^)(?:[^\s\"'>]+/)*{re.escape(image_name)}:[^\s\"'>]+"
                            
                            # Find all occurrences in the ORIGINAL text
                            matches = list(re.finditer(pattern, original))
                            
                            if len(tags) == 1:
                                # Safe literal string replacement
                                for match in matches:
                                    old_str = match.group(0)
                                    boundary = match.group(1) # Keep the space or quote
                                    new_str = f"{boundary}{target_registry}/{clean_path}:{tags[0]}"
                                    text = text.replace(old_str, new_str)
                            else:
                                # Safe literal string replacement for multiple tags
                                for idx, match in enumerate(matches):
                                    if idx >= len(tags): break
                                    old_str = match.group(0)
                                    boundary = match.group(1)
                                    new_str = f"{boundary}{target_registry}/{clean_path}:{tags[idx]}"
                                    text = text.replace(old_str, new_str, 1)
                                    
                        if text != original: new_data = text.encode()

                    if new_data != data:
                        with open(path, "wb") as f: f.write(new_data)
                except Exception as file_error:
                    handle_error(file_error, f"Processing file {path}", error_type="FILE_ERROR")
    except Exception as e:
        handle_error(e, f"replace_registry_fqdn in {target_dir}", error_type="REGISTRY_ERROR")

def replace_img_fqdn():
    if config.get("UPDATE_IMAGE_REGISTRY") is False:
        print("======= Skipping image FQDN replacement (update_image_registry: False) =======")
        return
    
    # Use explicit target from config.yaml, otherwise fallback to FQDN
    target_registry = config.get("TARGET_IMAGE_REGISTRY") or config.get("FQDN")
    
    replace_registry_fqdn(
        target_dir="catalog-templates",
        registry_fqdn=target_registry,
    )

def untar(tar_path, dest_dir):
    try:
        if not config["UNTAR"]: return
        target_folder = os.path.join(dest_dir, "catalog-templates")
        if config.get("PATCH") and os.path.exists(target_folder):
            print(f"=======  Patch Mode: Local '{target_folder}' detected =======")
            return
        print(f"=======  untaring the templates and images =======")
        if not os.path.isfile(tar_path): raise FileNotFoundError(f"{tar_path} not found")
        os.makedirs(dest_dir, exist_ok=True)
        with tarfile.open(tar_path, "r:*") as tar: tar.extractall(dest_dir)
    except Exception as e:
        handle_error(e, f"untar {tar_path}", error_type="FILE_ERROR")

def get_yaml_files(directory):
    yaml_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                yaml_files.append(os.path.join(root, file))
    return yaml_files

def validate_template_file(template_file_path, root_dir):
    with open(template_file_path, "r") as f:
        data = yaml.safe_load(f)
        if not data: return False
    return True

def handle_error(error, context="", error_type="GENERAL"):
    global error_list
    error_msg = str(error)
    error_entry = {"type": error_type, "context": context, "message": error_msg}
    full_log_msg = f"[{error_type}] {context}: {error_msg}" if context else f"[{error_type}] {error_msg}"

    # Treat OVERRIDE as implicitly allowing the script to continue on errors
    if config.get("CONTINUE_ON_ERROR", False) or config.get("OVERRIDE", False) or config.get("HARD_OVERRIDE", False):
        error_list.append(error_entry)
        print(f"\n\033[33mWARNING: {full_log_msg}\033[0m")
        print("Continuing with next item...\n")
        return True
    else:
        raise error


# ==========================================
# COLLISION & API LOGIC
# ==========================================

def check_resource_exists(kind, name):
    """
    Checks if a resource exists globally. Attempts target project first, then default-catalog.
    """
    base_url = config["urls"]["BASE_URL"]
    headers = {
        "Content-Type": "application/yaml",
        "X-API-KEY": config.get("API_KEY", ""),
        "X-ORGANIZATION-ID": config.get("ORG_HASH", ""),
    }
    
    target_proj = config.get("PROJECT_NAME")
    projects_to_check = [target_proj]
    
    for p in ["default-catalog", "system-catalog"]:
        if p not in projects_to_check:
            projects_to_check.append(p)
        
    for proj in projects_to_check:
        url_map = {
            "SecretSealer": f"{base_url}/apis/integrations.k8smgmt.io/v3/projects/{proj}/secretsealers",
            "Agent": f"{base_url}/apis/gitops.k8smgmt.io/v3/projects/{proj}/agents",
            "Repository": f"{base_url}/apis/integrations.k8smgmt.io/v3/projects/{proj}/repositories",
            "ConfigContext": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/configcontexts",
            "ResourceTemplate": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/resourcetemplates",
            "Resource": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/resources",
            "EnvironmentTemplate": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/environmenttemplates",
            "Driver": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/drivers",
            "WorkflowHandler": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{proj}/workflowhandlers",
            "ComputeProfile": f"{base_url}/apis/paas.envmgmt.io/v1/projects/{proj}/computeprofiles",
            "ServiceProfile": f"{base_url}/apis/paas.envmgmt.io/v1/projects/{proj}/serviceprofiles",
        }
        
        if kind not in url_map: return False, None
        check_url = f"{url_map[kind]}/{name}"
        
        try:
            response = requests.request("GET", check_url, headers=headers, verify=False, timeout=10)
            if response.status_code == 200:
                try: resp_data = response.json()
                except: resp_data = yaml.safe_load(response.text) or {}

                if isinstance(resp_data, dict):
                    if "error" in resp_data or resp_data.get("status") == "error" or resp_data.get("kind") == "Status": 
                        continue
                    is_list = str(resp_data.get("kind", "")).endswith("List")
                    if is_list:
                        if "items" in resp_data and isinstance(resp_data["items"], list):
                            for item in resp_data["items"]:
                                if isinstance(item, dict) and item.get("metadata", {}).get("name") == name:
                                    return True, item.get("metadata", {}).get("project", proj)
                    else:
                        if resp_data.get("metadata", {}).get("name") == name:
                            return True, resp_data.get("metadata", {}).get("project", proj)
        except Exception:
            pass
            
    return False, None

def find_server_dependents(kind, name, project):
    """
    Finds all resources on the server that depend on the given resource, recursively.
    """
    base_url = config["urls"]["BASE_URL"]
    headers = {
        "Content-Type": "application/yaml",
        "X-API-KEY": config.get("API_KEY", ""),
        "X-ORGANIZATION-ID": config.get("ORG_HASH", ""),
    }
    
    all_dependents = []
    queue = [(kind, name)]
    visited = set()
    
    while queue:
        curr_kind, curr_name = queue.pop(0)
        if (curr_kind, curr_name) in visited: continue
        visited.add((curr_kind, curr_name))
        
        found_in_this_step = []
        
        # 1. If it's a WFH or Driver, find RTs using it
        if curr_kind in ["WorkflowHandler", "Driver"]:
            url = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project}/resourcetemplates"
            try:
                response = requests.get(url, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for rt in data.get("items", []):
                        tasks = rt.get("spec", {}).get("providerOptions", {}).get("custom", {}).get("tasks", [])
                        for task in tasks:
                            if curr_kind == "WorkflowHandler" and task.get("type") == "workflowHandler" and task.get("workflowHandler", {}).get("name") == curr_name:
                                found_in_this_step.append({"kind": "ResourceTemplate", "name": rt["metadata"]["name"]})
                            elif curr_kind == "Driver" and task.get("type") == "driver" and task.get("driver", {}).get("name") == curr_name:
                                found_in_this_step.append({"kind": "ResourceTemplate", "name": rt["metadata"]["name"]})
            except Exception: pass

        # 2. If it's an RT, find ETs using it
        elif curr_kind == "ResourceTemplate":
            url = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project}/environmenttemplates"
            try:
                response = requests.get(url, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for et in data.get("items", []):
                        for res in et.get("spec", {}).get("resources", []):
                            if res.get("kind", "").lower() == "resourcetemplate" and res.get("name") == curr_name:
                                found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"]})
            except Exception: pass

        # 3. If it's a Context, find ETs, WFHs, or Drivers using it
        elif curr_kind == "ConfigContext":
            # Check ETs
            url_et = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project}/environmenttemplates"
            try:
                response = requests.get(url_et, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for et in data.get("items", []):
                        # Check spec.contexts
                        for ctx in et.get("spec", {}).get("contexts", []):
                            if ctx.get("name") == curr_name:
                                found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"]})
                        # Check spec.actions[].context.name
                        for action in et.get("spec", {}).get("actions", []):
                            if action.get("context", {}).get("name") == curr_name:
                                found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"]})
            except Exception: pass
            
            # Check WFHs
            url_wfh = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project}/workflowhandlers"
            try:
                response = requests.get(url_wfh, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for wfh in data.get("items", []):
                        for inp in wfh.get("spec", {}).get("inputs", []):
                            if inp.get("name") == curr_name:
                                found_in_this_step.append({"kind": "WorkflowHandler", "name": wfh["metadata"]["name"]})
            except Exception: pass

            # Check Drivers
            url_dr = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project}/drivers"
            try:
                response = requests.get(url_dr, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for dr in data.get("items", []):
                        for inp in dr.get("spec", {}).get("inputs", []):
                            if inp.get("name") == curr_name:
                                found_in_this_step.append({"kind": "Driver", "name": dr["metadata"]["name"]})
            except Exception: pass

        # 4. If it's an ET, find Profiles using it
        elif curr_kind == "EnvironmentTemplate":
            # ComputeProfiles
            url_cp = f"{base_url}/apis/paas.envmgmt.io/v1/projects/{project}/computeprofiles"
            try:
                response = requests.get(url_cp, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for cp in data.get("items", []):
                        if cp.get("spec", {}).get("environmentTemplate", {}).get("name") == curr_name:
                            found_in_this_step.append({"kind": "ComputeProfile", "name": cp["metadata"]["name"]})
            except Exception: pass
            
            # ServiceProfiles
            url_sp = f"{base_url}/apis/paas.envmgmt.io/v1/projects/{project}/serviceprofiles"
            try:
                response = requests.get(url_sp, headers=headers, verify=False, timeout=15)
                if response.status_code == 200:
                    data = response.json()
                    for sp in data.get("items", []):
                        if sp.get("spec", {}).get("environmentTemplate", {}).get("name") == curr_name:
                            found_in_this_step.append({"kind": "ServiceProfile", "name": sp["metadata"]["name"]})
            except Exception: pass

        # Add unique findings to results and queue
        for item in found_in_this_step:
            item["project"] = project
            if not any(d["kind"] == item["kind"] and d["name"] == item["name"] for d in all_dependents):
                all_dependents.append(item)
                queue.append((item["kind"], item["name"]))
                
    return all_dependents

def extract_api_error_reason(raw):
    """Pull the human-readable cause out of an API error body.

    Handles JSON bodies like {"error": "..."} / {"message": "..."} and
    unwraps gRPC-style envelopes such as
    'rpc error: code = FailedPrecondition desc = <the real reason>'.
    Returns "" when nothing meaningful can be extracted.
    """
    if not raw:
        return ""
    msg = raw.strip()
    try:
        payload = json.loads(msg)
        if isinstance(payload, dict):
            for key in ("error", "message", "msg", "detail", "details"):
                val = payload.get(key)
                if isinstance(val, str) and val.strip():
                    msg = val.strip()
                    break
    except (ValueError, TypeError):
        pass
    # Unwrap gRPC envelope: '... desc = <reason>' -> '<reason>'
    marker = "desc = "
    idx = msg.rfind(marker)
    if idx != -1:
        msg = msg[idx + len(marker):].strip()
    return msg

def make_rest_api_call(method, url, headers, params, data):
    response = None
    try:
        if config.get("DEBUG", False):
            print("\n" + "="*80)
            print("DEBUG: API REQUEST")
            print("="*80)
            print(f"Method: {method}")
            print(f"URL: {url}")
            print(f"Headers: {headers}")
            if params: print(f"Params: {params}")
            print(f"Request Body:\n{data if data else '(empty)'}")
            print("="*80)

        response = requests.request(method, url, headers=headers, params=params, data=data, verify=False, timeout=30)
        
        if config.get("DEBUG", False):
            print("\n" + "="*80)
            print("DEBUG: API RESPONSE")
            print("="*80)
            print(f"Status Code: {response.status_code}")
            try: response_body = response.content.decode('utf-8', errors='ignore')
            except: response_body = str(response.content)
            print(f"Response Body:\n{response_body}")
            print("="*80 + "\n")

        response.raise_for_status()
    except requests.exceptions.Timeout as e:
        error_msg = f"API Timeout: The server at {url} took too long to respond (Limit: 30s)."
        print(f"\033[31m{error_msg}\033[0m")
        raise RuntimeError(error_msg) from e
    except requests.exceptions.ConnectionError as e:
        error_msg = f"API Connection Error: Could not connect to {url}. Please check your internet or VPN."
        print(f"\033[31m{error_msg}\033[0m")
        raise RuntimeError(error_msg) from e
    except requests.exceptions.HTTPError as e:
        error_msg = f"API HTTP Error: {method} {url} returned {response.status_code}"
        if response is not None and response.content:
            raw = ""
            try: raw = response.content.decode('utf-8', errors='ignore')
            except: pass
            reason = extract_api_error_reason(raw)
            if reason:
                error_msg += f"\nReason: {reason}"
            if raw:
                error_msg += f"\nResponse: {raw}"
        print(f"\033[31m{error_msg}\033[0m")
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Unexpected Error in API call: {e}"
        print(f"\033[31m{error_msg}\033[0m")
        raise RuntimeError(error_msg) from e
    return response

def make_v1_api(method, url, params, data):
    headers = {
        "Content-Type": "application/yaml",
        "X-RAFAY-API-KEYID": config.get("API_KEY"),
        "X-ORGANIZATION-ID": config.get("ORG_HASH"),
    }
    return make_rest_api_call(method, url, headers, params, data)

def make_v3_api(method, url, params, data):
    headers = {
        "Content-Type": "application/yaml",
        "X-API-KEY": config["API_KEY"],
        "X-ORGANIZATION-ID": config["ORG_HASH"],
    }
    return make_rest_api_call(method, url, headers, params, data)

def make_console_json_api(method, url, body_dict):
    api_key = config.get("API_KEY")
    if not api_key: raise RuntimeError("API_KEY is required for global settings API")
    headers = {"Content-Type": "application/json", "X-API-KEY": api_key}
    if config.get("ORG_HASH"): headers["X-ORGANIZATION-ID"] = config["ORG_HASH"]
    data = json.dumps(body_dict) if body_dict is not None else None
    return make_rest_api_call(method, url, headers, None, data)

def get_all_workflows_and_drivers(project_name):
    base_url = config["urls"]["BASE_URL"]
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-API-KEY": config["API_KEY"],
        "X-ORGANIZATION-ID": config["ORG_HASH"]
    }
    
    fetched_names = set()
    endpoints = ["drivers", "workflowhandlers"]
    
    for endpoint in endpoints:
        limit = 100
        offset = 0
        while True:
            url = f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/{endpoint}?limit={limit}&offset={offset}"
            try:
                response = requests.get(url, headers=headers, verify=False, timeout=20)
                if response.status_code == 200:
                    try: data = response.json()
                    except: data = yaml.safe_load(response.text)
                    
                    items = data.get("items") or data.get("results") or []
                    for item in items:
                        name = item.get("metadata", {}).get("name")
                        if name: fetched_names.add(name)
                    
                    if len(items) < limit: break 
                    offset += limit
                else: break
            except Exception as e:
                print(f"\n  [Warning] Failed to fetch {endpoint} list from {project_name}: {e}")
                break
    return list(fetched_names)

def build_project_urls(project_name):
    host_env = config["HOST_ENV"]
    base_url = f"https://{host_env}"
    ops_env = config.get("OPS_CONSOLE_HOST")
    ops_url = f"https://{ops_env}" if ops_env else base_url
    return {
        "BASE_URL": base_url,
        "GET_PROJECTS": f"{base_url}/v1/auth/projects",
        "CREATE_PROJECT": f"{base_url}/apis/system.k8smgmt.io/v3/projects",
        "GET_USERS": f"{base_url}/auth/v1/users/-/current/",
        "GET_PROJECT_DETAIL": f"{base_url}/apis/system.k8smgmt.io/v3/projects/{project_name}",
        "ADD_SECRETSEALER": f"{base_url}/apis/integrations.k8smgmt.io/v3/projects/{project_name}/secretsealers",
        "ADD_AGENT": f"{base_url}/apis/gitops.k8smgmt.io/v3/projects/{project_name}/agents",
        "ADD_REPO": f"{base_url}/apis/integrations.k8smgmt.io/v3/projects/{project_name}/repositories",
        "ADD_CONFIGCONTEXT": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/configcontexts",
        "ADD_RESOURCE": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/resourcetemplates",
        "ADD_CUSTOM_RESOURCE": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/resources",
        "ADD_ENVIRONMENT": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/environmenttemplates",
        "ADD_DRIVER": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/drivers",
        "GET_ORGS_V1": f"{ops_url}/auth/v1/organizations/?limit=200&offset=0",
        "ADD_CPROFILE": f"{base_url}/apis/paas.envmgmt.io/v1/projects/{project_name}/computeprofiles",
        "ADD_SPROFILE": f"{base_url}/apis/paas.envmgmt.io/v1/projects/{project_name}/serviceprofiles",
        "ADD_WRKFLW": f"{base_url}/apis/eaas.envmgmt.io/v1/projects/{project_name}/workflowhandlers",
    }

def set_project_context(project_name):
    config["PROJECT_NAME"] = project_name
    config["urls"] = build_project_urls(project_name)

def get_ncp_server_api_key():
    key = config.get("_NCP_SERVER_API_KEY")
    if not key:
        key = f"ncp.{secrets.token_urlsafe(48)}"
        config["_NCP_SERVER_API_KEY"] = key
    return key


# ==========================================
# GLOBAL SETTINGS UTILS
# ==========================================

def build_global_settings_url():
    host_env = config.get("HOST_ENV")
    if not host_env: raise RuntimeError("hostenv is required for global settings API")
    return f"https://{host_env}/apis/system.k8smgmt.io/v3/globalsettings"

def detect_catalog_version():
    explicit = config.get("CATALOG_VERSION")
    if explicit: return str(explicit).strip()
    version_re = re.compile(r"^v[\d.]+$")
    for base in (config.get("_CONFIG_DIR"), os.getcwd()):
        if not base: continue
        base = os.path.abspath(base)
        for name in (os.path.basename(base), os.path.basename(os.path.dirname(base))):
            m = re.match(r"^ncp-templates-(v[\d.]+)", name, re.IGNORECASE)
            if m:
                ver = m.group(1)
                return ver if ver.startswith("v") else f"v{ver}"
    config_dir = config.get("_CONFIG_DIR") or os.getcwd()
    env_root = os.path.join(config_dir, "catalog-templates", "env-templates")
    if os.path.isdir(env_root):
        versions = sorted(d for d in os.listdir(env_root) if version_re.match(d) and os.path.isdir(os.path.join(env_root, d)))
        if versions: return versions[-1]
    raise RuntimeError("Could not detect catalog version from ncp-templates path")

def read_global_settings_template():
    tpl_name = config.get("GLOBAL_SETTINGS_TEMPLATE", "global-settings.yaml")
    config_dir = config.get("_CONFIG_DIR") or os.getcwd()
    path = tpl_name if os.path.isabs(tpl_name) else os.path.join(config_dir, tpl_name)
    if not os.path.isfile(path): raise FileNotFoundError(f"Global settings template not found: {path}")
    with open(path, encoding="utf-8") as f: return f.read()

def resolve_global_settings_agents():
    agents = config.get("AGENTS")
    if agents is None: agents = ["paas-agent"]
    elif isinstance(agents, str): agents = [agents]
    result = [str(a).strip() for a in agents if a is not None and str(a).strip()]
    if not result: raise RuntimeError("At least one agent is required")
    return result

def build_agents_yaml_snippet():
    return "\n".join(["agents:"] + [f"- {name}" for name in resolve_global_settings_agents()])

def build_global_settings_yaml():
    content = read_global_settings_template()
    dc_id = resolve_datacenter_inventory_id()
    if not dc_id: raise RuntimeError("Datacenter ID could not be resolved for global settings")
    version = detect_catalog_version()
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    partner_key = config.get("API_KEY")
    if not ops_host: raise RuntimeError("opsenv is required for global settings")
    if not partner_key: raise RuntimeError("apikey is required for global settings")
    replacements = {
        "<UPDATE_AGENTS>": build_agents_yaml_snippet(),
        "<UPDATE_DATACENTER_ID>": dc_id,
        "<UPDATE_TEMPLATE_VERSION>": version,
        "<UPDATE_OPS_ENDPOINT>": ops_host,
        "<UPDATE_PARTNER_API_KEY>": partner_key,
    }
    for token, value in replacements.items(): content = content.replace(token, str(value))
    if "<UPDATE" in content: raise RuntimeError("Unresolved placeholder(s) remain in global settings")
    return content

def build_global_settings_api_payload(yaml_content, existing_item=None):
    target_file_name = "settings.yaml"
    new_file = {
        "name": target_file_name,
        "options": {
            "description": "Global Setting",
            "override": {"type": "allowed"},
            "required": True,
        },
    }

    payload = {
        "apiVersion": "system.k8smgmt.io/v3",
        "kind": "GlobalSettings",
        "metadata": {"name": "globalsettings"},
        "spec": {"files": []},
    }

    # Helper to deep merge yaml dictionaries and append unique list items
    def merge_dicts(d1, d2):
        for k, v in d2.items():
            if k in d1 and isinstance(d1[k], dict) and isinstance(v, dict):
                merge_dicts(d1[k], v)
            elif k in d1 and isinstance(d1[k], list) and isinstance(v, list):
                for item in v:
                    if item not in d1[k]:
                        d1[k].append(item)
            else:
                d1[k] = v
        return d1

    # If existing settings are found, preserve other files and merge the target file
    if existing_item and "spec" in existing_item and "files" in existing_item["spec"]:
        for f in existing_item["spec"]["files"]:
            if f.get("name") == target_file_name:
                try:
                    # Decode old YAML, merge with new YAML
                    existing_yaml_str = base64.b64decode(f.get("data", "")).decode("utf-8")
                    existing_dict = yaml.safe_load(existing_yaml_str) or {}
                    new_dict = yaml.safe_load(yaml_content) or {}
                    
                    merged_dict = merge_dicts(existing_dict, new_dict)
                    yaml_content = yaml.dump(merged_dict, default_flow_style=False)
                except Exception as e:
                    pass # Fallback to overwriting if merge fails
            else:
                # Keep other unrelated files exactly as they are
                payload["spec"]["files"].append(f)

    # Encode the final YAML and append it
    new_file["data"] = base64.b64encode(yaml_content.encode("utf-8")).decode("ascii")
    payload["spec"]["files"].append(new_file)
    
    # Carefully extract ONLY necessary metadata to avoid codec errors like "count"
    if existing_item and "metadata" in existing_item:
        payload["metadata"]["name"] = existing_item["metadata"].get("name", "globalsettings")
        # K8s PUT operations often require the latest resourceVersion
        if "resourceVersion" in existing_item["metadata"]:
            payload["metadata"]["resourceVersion"] = existing_item["metadata"]["resourceVersion"]

    return payload

def build_tenant_onboarding_payload():
    """Build JSON payload for /v2/sentry/partner/tenant-onboarding."""
    dc_id = resolve_datacenter_inventory_id()
    if not dc_id: raise RuntimeError("Datacenter ID could not be resolved for tenant onboarding")
    version = detect_catalog_version()
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    partner_key = config.get("API_KEY")
    if not ops_host: raise RuntimeError("opsenv is required for tenant onboarding")
    if not partner_key: raise RuntimeError("apikey is required for tenant onboarding")
    return {
        "addTenantTemplate": {
            "name": "system-vmaas-tenant-onboarding",
            "version": version,
            "overrides": {
                "variables": {
                    "Datacenter ID": dc_id,
                    "Provider": "IPAM/PaaS",
                    "Public IP Enabled": False,
                    "NFV Disabled": True,
                    "Ops Console Endpoint": ops_host,
                    "Partner API Key": partner_key,
                }
            }
        }
    }

def build_node_onboarding_payload():
    """Build JSON payload for /v2/sentry/partner/node-onboarding."""
    version = detect_catalog_version()
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    partner_key = config.get("API_KEY")
    if not ops_host: raise RuntimeError("opsenv is required for node onboarding")
    if not partner_key: raise RuntimeError("apikey is required for node onboarding")
    return {
        "template": {
            "name": "system-vmaas-node-onboarding",
            "version": version,
            "overrides": {
                "variables": {
                    "Partner API Key": partner_key,
                    "Ops Console Endpoint": ops_host,
                    "Processing Type": "inventory-page",
                }
            }
        }
    }

def build_agent_mappings_payload(agent_name):
    """Build JSON payload for a single /v2/sentry/agent-mappings."""
    return {
        "metadata": {
            # Create a unique resource name based on the agent's name
            "name": f"mapping-{agent_name}" 
        },
        "spec": {
            # Pass the single string directly
            "agentName": agent_name,
            "scope": "global"
        }
    }

def build_tenant_onboarding_url():
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    if not ops_host: raise RuntimeError("opsenv is required for tenant onboarding API")
    return f"https://{ops_host}/v2/sentry/partner/tenant-onboarding"

def build_node_onboarding_url():
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    if not ops_host: raise RuntimeError("opsenv is required for node onboarding API")
    return f"https://{ops_host}/v2/sentry/partner/node-onboarding"

def build_agent_mappings_url():
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    if not ops_host: raise RuntimeError("opsenv is required for agent mappings API")
    return f"https://{ops_host}/v2/sentry/agent-mappings"

def make_ops_console_json_api(method, url, body_dict):
    """Ops Console v2/sentry endpoints use X-RAFAY-API-KEYID (same as infrainventory)."""
    api_key = config.get("API_KEY")
    if not api_key: raise RuntimeError("API_KEY is required for ops console API")
    headers = {"Content-Type": "application/json", "X-RAFAY-API-KEYID": api_key}
    data = json.dumps(body_dict) if body_dict is not None else None
    return make_rest_api_call(method, url, headers, None, data)

def apply_tenant_onboarding():
    """Push tenant onboarding config to Ops Console."""
    url = build_tenant_onboarding_url()
    payload = build_tenant_onboarding_payload()
    print(f"  -> Pushing tenant onboarding via POST...")
    try:
        response = make_ops_console_json_api("POST", url, payload)
        print(f"  ✓ Tenant onboarding applied successfully (HTTP {response.status_code})")
    except Exception as e:
        print(f"  [Error] Failed to apply tenant onboarding: {e}")

def apply_node_onboarding():
    """Push node onboarding config to Ops Console."""
    url = build_node_onboarding_url()
    payload = build_node_onboarding_payload()
    print(f"  -> Pushing node onboarding via POST...")
    try:
        response = make_ops_console_json_api("POST", url, payload)
        print(f"  ✓ Node onboarding applied successfully (HTTP {response.status_code})")
    except Exception as e:
        print(f"  [Error] Failed to apply node onboarding: {e}")

def apply_agent_mappings():
    """Check existing agent mappings, and create missing ones individually."""
    url = build_agent_mappings_url()
    configured_agents = resolve_global_settings_agents()
    
    print(f"  -> Checking existing agent mappings via GET...")
    existing_agents = set()
    
    try:
        response = make_ops_console_json_api("GET", url, None)
        
        if hasattr(response, 'status_code') and response.status_code == 200:
            data = response.json()
            
            # Extract existing agents so we don't push duplicates
            items = data.get("items", data) if isinstance(data, dict) else data
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict) and "spec" in item:
                        name = item["spec"].get("agentName")
                        if name:
                            existing_agents.add(name)
            
            if existing_agents:
                print(f"  ✓ Found existing agent mappings for: {list(existing_agents)}")
            else:
                print("  ✓ No existing agents found.")
        else:
            status = getattr(response, 'status_code', 'Unknown')
            print(f"  [-] Could not retrieve existing mappings (HTTP {status}). Proceeding to push configs.")
            
    except Exception as e:
        print(f"  [-] Failed to fetch existing agent mappings: {e}. Proceeding to push configs.")

    # Iterate through the list and POST each agent individually
    for agent in configured_agents:
        if agent in existing_agents:
            print(f"  -> Agent mapping for '{agent}' already exists. Skipping POST.")
            continue
            
        print(f"  -> Pushing agent mapping for '{agent}' via POST...")
        # Notice we pass the single 'agent' string to the builder here
        payload = build_agent_mappings_payload(agent) 
        
        try:
            response = make_ops_console_json_api("POST", url, payload)
            status = getattr(response, 'status_code', 'Unknown')
            print(f"  ✓ Agent mapping '{agent}' applied successfully (HTTP {status})")
        except Exception as e:
            print(f"  [Error] Failed to apply agent mapping '{agent}': {e}")

def apply_global_settings():
    """Wrapper that applies all three settings blocks separately."""
    if config.get("LOAD_GLOBAL_SETTINGS") is False:
        print("Skipping global settings (load_global_settings=false)")
        return

    print("\n======= Phase: Applying global settings =======")
    version = detect_catalog_version()
    dc_id = resolve_datacenter_inventory_id()
    print(f"  catalog version: {version}")
    print(f"  datacenter id: {dc_id}")
    print(f"  ops endpoint: {normalize_ops_host(config.get('OPS_CONSOLE_HOST'))}")
    print(f"  agents: {', '.join(resolve_global_settings_agents())}")

    apply_agent_mappings()
    apply_tenant_onboarding()
    apply_node_onboarding()

# ==========================================
# CUSTOM PROFILE & DATACENTER PATCHING
# ==========================================

def normalize_ops_host(ops_env):
    if not ops_env: return ""
    host = str(ops_env).strip()
    for prefix in ("https://", "http://"):
        if host.startswith(prefix): host = host[len(prefix):]
    return host.rstrip("/")

def build_infrainventory_datacenters_url():
    ops_host = normalize_ops_host(config.get("OPS_CONSOLE_HOST"))
    if not ops_host: raise RuntimeError("opsenv required to resolve datacenter ID")
    return f"https://{ops_host}/v2/sentry/paas/infrainventory/datacenters"

def fetch_infrainventory_datacenters():
    api_key = config.get("API_KEY")
    if not api_key: raise RuntimeError("apikey is required to resolve datacenter ID")
    url = build_infrainventory_datacenters_url()
    headers = {"X-RAFAY-API-KEYID": api_key}
    response = make_rest_api_call("GET", url, headers, None, None)
    payload = response.json()
    if isinstance(payload, dict) and isinstance(payload.get("data"), list): return payload["data"]
    if isinstance(payload, list): return payload
    raise RuntimeError(f"Unexpected response shape from {url}")

def get_infrainventory_datacenters_cache():
    cached = config.get("_INFRAINVENTORY_DATACENTERS_CACHE")
    if cached is None:
        cached = fetch_infrainventory_datacenters()
        config["_INFRAINVENTORY_DATACENTERS_CACHE"] = cached
    return cached

def lookup_datacenter_id_by_name(datacenter_name, datacenters=None):
    needle = str(datacenter_name).strip()
    if not needle: return None
    entries = datacenters if datacenters is not None else get_infrainventory_datacenters_cache()
    if not isinstance(entries, list): entries = []
    by_name = [dc for dc in entries if isinstance(dc, dict) and str(dc.get("name", "")).strip() == needle]
    if len(by_name) == 1:
        dc_id = str(by_name[0].get("id", "")).strip()
        if dc_id: return dc_id
    elif len(by_name) > 1: raise RuntimeError(f"Multiple datacenters named {needle!r}")
    by_id = [dc for dc in entries if isinstance(dc, dict) and str(dc.get("id", "")).strip() == needle]
    if len(by_id) == 1: return needle
    available = sorted({str(dc.get("name")).strip() for dc in entries if isinstance(dc, dict) and dc.get("name")})
    raise RuntimeError(f"Datacenter {needle!r} not found. Available names: {', '.join(available)}")

def resolve_datacenter(profile_entry=None, category_cat=None):
    entry = profile_entry or {}
    dc = entry.get("datacenter") or entry.get("datacenter_id")
    if dc is None and category_cat: dc = category_cat.get("datacenter") or category_cat.get("datacenter_id")
    if dc is None: dc = config.get("DATACENTER")
    return str(dc).strip() if dc else None

def resolve_datacenter_inventory_id(profile_entry=None, category_cat=None):
    name = resolve_datacenter(profile_entry, category_cat)
    if not name: return None
    if config.get("DATACENTER_RESOLVE_VIA_API") is False: return name
    return lookup_datacenter_id_by_name(name)

def patch_datacenter_id_variable(spec, profile_entry=None, cat=None):
    dc_name = resolve_datacenter(profile_entry, cat)
    if not dc_name: return
    dc_id = resolve_datacenter_inventory_id(profile_entry, cat)
    if not dc_id: return
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Datacenter ID": continue
        var["value"] = dc_id
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True
        dm.setdefault("alias", "Datacenter")
        break

def resolve_profile_icon_url(cat, profile_entry, category=None):
    entry = profile_entry or {}
    icon_url = entry.get("iconURL") or entry.get("icon_url")
    if icon_url is None or (isinstance(icon_url, str) and not icon_url.strip()):
        variant = entry.get("variant")
        if variant:
            icon_variants = cat.get("icon_variants") or {}
            icon_url = icon_variants.get(variant)
        if icon_url is None or (isinstance(icon_url, str) and not icon_url.strip()):
            icon_url = cat.get("iconURL") or cat.get("icon_url")
        if (icon_url is None or (isinstance(icon_url, str) and not icon_url.strip())) and category == "vmaas" and variant != "flex":
            bmaas_cat = (config.get("CATEGORIES") or {}).get("bmaas") or {}
            icon_url = bmaas_cat.get("iconURL") or bmaas_cat.get("icon_url")
    return str(icon_url) if icon_url else None

def resolve_profile_system_catalog(cat, profile_entry):
    entry = profile_entry or {}
    val = entry.get("systemCatalog")
    if val is None: val = entry.get("system_catalog")
    if val is None: val = cat.get("systemCatalog") or cat.get("system_catalog")
    return val

def resolve_profile_tags(cat, profile_entry):
    entry = profile_entry or {}
    if entry.get("tags") is not None: return str(entry["tags"])
    variant = entry.get("variant")
    if variant:
        tag_variants = cat.get("tag_variants") or {}
        if variant in tag_variants: return str(tag_variants[variant])
    tag_variant = entry.get("tag_variant")
    if tag_variant == "gpu": return cat.get("gpu_node_tags")
    if tag_variant == "cpu": return cat.get("cpu_node_tags")
    return cat.get("tags")


# ---------------- BMAAS ----------------
BMAAS_USER_EDITABLE_VARIABLES = frozenset({"ssh_key", "user_data", "user_password"})
BMAAS_VARIABLE_ALIASES = {"ssh_key": "SSH public key", "user_data": "User data", "user_password": "Password"}
BMAAS_DISPLAY_LAYOUT = {
    "ssh_key": {"section": "Login & access", "weight": 30, "sectionDescription": "How you connect to the bare metal host"},
    "user_password": {"section": "Login & access", "weight": 31},
    "user_data": {"section": "Advanced", "weight": 40, "sectionDescription": "Optional customization"},
}

def patch_bmaas_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if name in BMAAS_USER_EDITABLE_VARIABLES else "notallowed"

def patch_bmaas_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = BMAAS_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_bmaas_display_layout(spec, profile_entry=None):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        layout = BMAAS_DISPLAY_LAYOUT.get(var.get("name"))
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        if layout.get("sectionDescription"): dm["sectionDescription"] = layout["sectionDescription"]


# ---------------- VMAAS ----------------
VMAAS_USER_EDITABLE_VARIABLES = frozenset({"Guest CPU Count", "Guest Memory Size", "Guest Disk Size", "Guest GPU Count", "Assign Public IP to Guest", "SSH Public Keys", "User Data", "Guest Password"})
VMAAS_SKU_LOCKED_DISPLAY_VARIABLES = frozenset({"Guest CPU Count", "Guest Memory Size", "Guest Disk Size", "Guest GPU Count"})
VMAAS_VARIABLE_ALIASES = {"Guest CPU Count": "vCPUs", "Guest Memory Size": "Memory (MB)", "Guest Disk Size": "Disk size (GB)", "Guest GPU Count": "GPUs", "Assign Public IP to Guest": "Public IP", "SSH Public Keys": "SSH public key", "User Data": "User data", "Guest Password": "Password"}
VMAAS_DISPLAY_LAYOUT = {
    "Guest GPU Count": {"section": "Instance size", "weight": 10}, "Guest CPU Count": {"section": "Instance size", "weight": 11},
    "Guest Memory Size": {"section": "Instance size", "weight": 12}, "Guest Disk Size": {"section": "Instance size", "weight": 13},
    "Assign Public IP to Guest": {"section": "Network", "weight": 20, "sectionDescription": "Public connectivity"},
    "SSH Public Keys": {"section": "Login & access", "weight": 30, "sectionDescription": "How you connect to the VM"},
    "Guest Password": {"section": "Login & access", "weight": 31},
    "User Data": {"section": "Advanced", "weight": 40, "sectionDescription": "Optional customization"},
}
VMAAS_INSTANCE_SIZE_SECTION_DESCRIPTION = {"flex": "Adjust CPU, memory, GPU, and disk for a custom workload.", "default": "Resources for this GPU VM profile. Values are fixed for this SKU."}
VMAAS_INSTANCE_SIZE_VARIABLES = frozenset({"Guest GPU Count", "Guest CPU Count", "Guest Memory Size", "Guest Disk Size"})
VMAAS_PUBLIC_IP_DISPLAY_METADATA = {"alias": "Public IP", "radioOptions": [{"label": "True", "value": "True"}, {"label": "False", "value": "False"}], "section": "Network Details", "type": "radio", "weight": 231}
VMAAS_FLEX_SIZING_VARIANTS = ("small", "medium", "large", "xlarge")
VMAAS_FLEX_SIZING_CONFIG_KEYS = {"Guest CPU Count": "guest_cpu_count", "Guest Memory Size": "guest_memory_size", "Guest GPU Count": "guest_gpu_count"}
VMAAS_FLEX_SIZING_ALIASES = {"Guest Memory Size": "Memory (GB)"}
VMAAS_FLEX_DISK_DISPLAY_METADATA = {"incrementDecrementLabel": "Disk Size", "incrementDecrementMax": "2000", "incrementDecrementMin": "100", "incrementDecrementStep": "100", "section": "Instance size", "sectionDescription": "Adjust CPU, memory, GPU, and disk for a custom workload.", "type": "incrementDecrement", "weight": 13}

def patch_vmaas_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if var.get("name") in VMAAS_USER_EDITABLE_VARIABLES else "notallowed"

def patch_vmaas_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = VMAAS_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_vmaas_display_layout(spec, profile_entry=None):
    variant = (profile_entry or {}).get("variant")
    instance_desc = VMAAS_INSTANCE_SIZE_SECTION_DESCRIPTION["flex" if variant == "flex" else "default"]
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        layout = VMAAS_DISPLAY_LAYOUT.get(name)
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        if name in VMAAS_INSTANCE_SIZE_VARIABLES: dm["sectionDescription"] = instance_desc
        elif layout.get("sectionDescription"): dm["sectionDescription"] = layout["sectionDescription"]

def patch_vmaas_public_ip_display_metadata(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Assign Public IP to Guest": continue
        var.setdefault("options", {}).setdefault("displayMetadata", {}).update(VMAAS_PUBLIC_IP_DISPLAY_METADATA)
        break

def patch_vmaas_sku_locked_display_metadata(spec, profile_entry=None):
    if (profile_entry or {}).get("variant") == "flex": return
    for var in spec.get("variables", []):
        if isinstance(var, dict) and var.get("name") in VMAAS_SKU_LOCKED_DISPLAY_VARIABLES:
            var.setdefault("options", {}).setdefault("displayMetadata", {})["disabled"] = True

def memory_mb_to_gb_label(memory_mb):
    mb_str = str(memory_mb).strip()
    try: mb = int(mb_str)
    except ValueError: return f"{mb_str} MB"
    if mb <= 0: return "0 GB"
    if mb % 1024 == 0: return f"{mb // 1024} GB"
    return f"{mb} MB"

def patch_vmaas_fixed_sku_memory_display_metadata(spec, profile_entry=None):
    if (profile_entry or {}).get("variant") == "flex": return
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Guest Memory Size": continue
        memory_mb = var.get("value")
        if memory_mb is None: continue
        mb_str = str(memory_mb).strip()
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["alias"] = "Memory (GB)"
        dm["type"] = "dropdown"
        dm["dropdownValues"] = [{"label": memory_mb_to_gb_label(mb_str), "value": mb_str}]
        break

def build_vmaas_flex_sizing_dropdowns(cat):
    sku_variants = (cat or {}).get("sku_variants") or {}
    options = {name: [] for name in VMAAS_FLEX_SIZING_CONFIG_KEYS}
    seen = {name: set() for name in VMAAS_FLEX_SIZING_CONFIG_KEYS}
    for variant in VMAAS_FLEX_SIZING_VARIANTS:
        cfg = sku_variants.get(variant) or {}
        if not isinstance(cfg, dict): continue
        for var_name, cfg_key in VMAAS_FLEX_SIZING_CONFIG_KEYS.items():
            raw = cfg.get(cfg_key)
            if raw is None: continue
            value = str(raw).strip()
            if not value or value in seen[var_name]: continue
            seen[var_name].add(value)
            label = memory_mb_to_gb_label(value) if var_name == "Guest Memory Size" else value
            options[var_name].append({"label": label, "value": value})
    return options

def patch_vmaas_flex_sizing_display_metadata(spec, profile_entry=None, cat=None):
    if (profile_entry or {}).get("variant") != "flex": return
    cat = cat or (config.get("CATEGORIES") or {}).get("vmaas") or {}
    dropdowns = build_vmaas_flex_sizing_dropdowns(cat)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        entries = dropdowns.get(name)
        if not entries: continue
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        ov["type"] = "allowed"
        ov["restrictedValues"] = [entry["value"] for entry in entries]
        dm = opts.setdefault("displayMetadata", {})
        if name in VMAAS_FLEX_SIZING_ALIASES: dm["alias"] = VMAAS_FLEX_SIZING_ALIASES[name]
        dm["type"] = "dropdown"
        dm["dropdownValues"] = entries
        dm.pop("disabled", None)
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Guest Disk Size": continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed"
        dm = opts.setdefault("displayMetadata", {})
        dm.update(VMAAS_FLEX_DISK_DISPLAY_METADATA)
        dm.pop("alias", None); dm.pop("disabled", None)
        disk_val = var.get("value")
        if disk_val is not None:
            try:
                disk_gb = int(str(disk_val).strip())
                min_gb = int(VMAAS_FLEX_DISK_DISPLAY_METADATA["incrementDecrementMin"])
                max_gb = int(VMAAS_FLEX_DISK_DISPLAY_METADATA["incrementDecrementMax"])
                step = int(VMAAS_FLEX_DISK_DISPLAY_METADATA["incrementDecrementStep"])
                clamped = min(max(disk_gb, min_gb), max_gb)
                if step > 0: clamped = min_gb + ((clamped - min_gb) // step) * step
                var["value"] = str(clamped)
            except ValueError: pass
        break

def resolve_vmaas_guest_config(cat, profile_entry):
    entry = profile_entry or {}
    variant_cfg = {}
    variant = entry.get("variant")
    if variant:
        sku_variants = cat.get("sku_variants") or cat.get("variants") or {}
        if isinstance(sku_variants, dict): variant_cfg = sku_variants.get(variant) or {}
    resolved = {}
    for key in ("guest_cpu_count", "guest_memory_size", "guest_disk_size", "guest_gpu_count"):
        val = entry.get(key)
        if val is None: val = variant_cfg.get(key)
        if val is None: val = cat.get(key)
        if val is not None: resolved[key] = str(val)
    return resolved


# ---------------- DEVPODS / PLATFORM COMMON ----------------
DEVPODS_PLATFORM_VARIABLE_KEYS = {"Host Cluster Name": "host_cluster_name", "Hostname Suffix": "hostname_suffix", "Ingress Class Name": "ingress_class_name"}
COMMON_PLATFORM_GLOBAL_KEYS = {"host_cluster_name": "HOST_CLUSTER_NAME", "kubeconfig_file": "KUBECONFIG_FILE", "kubeconfig_path": "KUBECONFIG_FILE", "hostname_suffix": "HOSTNAME_SUFFIX", "ingress_class_name": "INGRESS_CLASS_NAME"}
PLATFORM_VARIABLES_CLEAR_IF_UNSET = frozenset({"Host Cluster Name", "Hostname Suffix"})

def resolve_common_platform_value(cfg_key, profile_entry=None, category_cat=None):
    entry = profile_entry or {}; cat = category_cat or {}
    keys_to_try = (cfg_key,)
    if cfg_key == "kubeconfig_file": keys_to_try = ("kubeconfig_file", "kubeconfig_path")
    elif cfg_key == "kubeconfig_path": keys_to_try = ("kubeconfig_path", "kubeconfig_file")
    for source in (entry, cat):
        if not isinstance(source, dict): continue
        for key in keys_to_try:
            val = source.get(key)
            if val is not None and str(val).strip(): return str(val).strip()
    global_key = COMMON_PLATFORM_GLOBAL_KEYS.get(cfg_key)
    if global_key:
        global_val = config.get(global_key)
        if global_val is not None and str(global_val).strip(): return str(global_val).strip()
    return None

def patch_platform_variables(spec, profile_entry=None, cat=None, key_map=None):
    key_map = key_map or DEVPODS_PLATFORM_VARIABLE_KEYS; cat = cat or {}
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in key_map: continue
        cfg_key = key_map[name]
        val = resolve_common_platform_value(cfg_key, profile_entry, cat)
        if val is not None: var["value"] = val
        elif name in PLATFORM_VARIABLES_CLEAR_IF_UNSET: var["value"] = ""
        else: continue
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"

def resolve_devpods_kubeconfig_file(cat, profile_entry):
    return resolve_common_platform_value("kubeconfig_file", profile_entry, cat)

def load_devpods_kubeconfig_contents(cat, profile_entry):
    path = resolve_devpods_kubeconfig_file(cat, profile_entry)
    if not path: return None
    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        base_dir = config.get("_CONFIG_DIR") or os.getcwd()
        path = os.path.join(base_dir, path)
    if not os.path.isfile(path):
        host_name = resolve_common_platform_value("host_cluster_name", profile_entry, cat)
        raise FileNotFoundError(f"kubeconfig_file not found: {path} (host_cluster_name: {host_name or 'n/a'})")
    with open(path, "r", encoding="utf-8") as kube_file: contents = kube_file.read()
    if not contents.strip(): raise ValueError(f"devpods kubeconfig_file is empty: {path}")
    return contents

def patch_kubeconfig_variable(spec, profile_entry=None, cat=None, section_description=None, weight=14):
    cat = cat or {}
    platform_cat = cat if isinstance(cat, dict) and "kubeconfig_file" in cat else notebook_platform_category(cat, profile_entry)
    kubeconfig = load_devpods_kubeconfig_contents(platform_cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Kubeconfig": continue
        opts = var.setdefault("options", {})
        if kubeconfig is not None:
            var["value"] = kubeconfig
            opts["sensitive"] = True
            opts["required"] = True
            opts["mask"] = True
        else:
            var["value"] = ""
            #opts.pop("sensitive", None)
            opts["sensitive"] = True
            opts.pop("mask", None)
            opts["required"] = False
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["section"] = "Cluster & networking"
        if section_description: dm["sectionDescription"] = section_description
        dm["weight"] = weight
        dm["disabled"] = True
        dm["alias"] = "Kubeconfig"
        break

def resolve_common_node_type_dropdown_options():
    raw = config.get("NODE_TYPES")
    if isinstance(raw, list) and raw:
        options = []
        for item in raw:
            if isinstance(item, dict):
                value = item.get("value") or item.get("label")
                label = item.get("label") or value
            else:
                value = str(item).strip()
                label = value
            if value: options.append({"label": str(label), "value": str(value)})
        if options: return options
    node_type = config.get("NODE_TYPE")
    if node_type is not None and str(node_type).strip():
        value = str(node_type).strip()
        return [{"label": value, "value": value}]
    return []

def resolve_common_node_type(profile_entry=None, category_cat=None):
    entry = profile_entry or {}; cat = category_cat or {}
    for source in (entry, cat):
        if isinstance(source, dict):
            val = source.get("node_type")
            if val is not None and str(val).strip(): return str(val).strip()
    global_val = config.get("NODE_TYPE")
    if global_val is not None and str(global_val).strip(): return str(global_val).strip()
    options = resolve_common_node_type_dropdown_options()
    if options: return options[0]["value"]
    return None

def patch_locked_node_type_variable(spec, profile_entry=None, cat=None):
    node_type = resolve_common_node_type(profile_entry, cat)
    dropdown_values = resolve_common_node_type_dropdown_options()
    if not node_type or not dropdown_values: return
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Node Type": continue
        var["value"] = node_type
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        ov["type"] = "allowed"
        ov["restrictedValues"] = [entry["value"] for entry in dropdown_values]
        dm = opts.setdefault("displayMetadata", {})
        dm["type"] = "dropdown"
        dm["dropdownValues"] = dropdown_values
        dm["disabled"] = False
        break

DEVPODS_USER_EDITABLE_VARIABLES = frozenset({"CPU", "Memory", "GPU Count", "Node Type", "Autogenerate SSH Key", "Public Key", "Pod Image", "Env Vars"})
DEVPODS_LOCKED_FEATURE_FLAGS = {"Enable SSH Access": "enable_ssh_access", "Enable Web Access": "enable_web_access"}
DEVPODS_VARIABLE_ALIASES = {"CPU": "vCPUs", "Memory": "Memory (GB)", "GPU Count": "GPUs", "Autogenerate SSH Key": "Autogenerate SSH key", "Public Key": "SSH public key", "Pod Image": "Pod image", "Host Cluster Name": "Kubernetes cluster", "Hostname Suffix": "Domain name", "Ingress Class Name": "Ingress class", "Node Type": "GPU node type", "Env Vars": "Environment variables"}
DEVPODS_DISPLAY_LAYOUT = {
    "Host Cluster Name": {"section": "Cluster & networking", "weight": 10}, "Hostname Suffix": {"section": "Cluster & networking", "weight": 11}, "Ingress Class Name": {"section": "Cluster & networking", "weight": 12}, "Node Type": {"section": "Cluster & networking", "weight": 13},
    "GPU Count": {"section": "Pod size", "weight": 20}, "CPU": {"section": "Pod size", "weight": 21}, "Memory": {"section": "Pod size", "weight": 22},
    "Pod Image": {"section": "Container", "weight": 30, "sectionDescription": "Image and runtime for the pod"},
    "Autogenerate SSH Key": {"section": "Login & access", "weight": 40, "sectionDescription": "How you connect to the pod"},
    "Public Key": {"section": "Login & access", "weight": 41},
    "Env Vars": {"section": "Advanced", "weight": 50, "sectionDescription": "Optional environment configuration"},
}
DEVPODS_POD_SIZE_SECTION_DESCRIPTION = "Choose CPU, memory, and GPU for your developer pod."
DEVPODS_PLATFORM_SECTION_DESCRIPTION = "Cluster, ingress, and GPU node placement for developer pods."
DEVPODS_GPU_DROPDOWN_OPTIONS = {"standard": [{"label": "0", "value": "0"}, {"label": "1", "value": "1"}, {"label": "2", "value": "2"}, {"label": "4", "value": "4"}, {"label": "8", "value": "8"}], "fractional": [{"label": "0.25", "value": "0.25"}, {"label": "0.50", "value": "0.50"}, {"label": "0.75", "value": "0.75"}, {"label": "1", "value": "1"}]}
DEVPODS_SIZING_VARIABLE_KEYS = {"CPU": "cpu", "Memory": "memory", "GPU Count": "gpu_count"}
DEVPODS_CPU_DROPDOWN_OPTIONS = [{"label": "8", "value": "8000"}, {"label": "16", "value": "16000"}, {"label": "24", "value": "24000"}, {"label": "32", "value": "32000"}]

def resolve_devpods_config(cat, profile_entry):
    entry = profile_entry or {}
    variant_cfg = {}
    variant = entry.get("variant")
    if variant:
        sku_variants = cat.get("sku_variants") or {}
        if isinstance(sku_variants, dict): variant_cfg = sku_variants.get(variant) or {}
    resolved = {}
    for var_name, cfg_key in DEVPODS_SIZING_VARIABLE_KEYS.items():
        val = entry.get(cfg_key)
        if val is None: val = variant_cfg.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None: resolved[var_name] = str(val)
    return resolved

def _devpods_bool_to_str(val):
    if isinstance(val, bool): return "true" if val else "false"
    return str(val).strip().lower()

def resolve_devpods_locked_feature_flags(cat, profile_entry):
    entry = profile_entry or {}; resolved = {}
    for var_name, cfg_key in DEVPODS_LOCKED_FEATURE_FLAGS.items():
        val = entry.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None: resolved[var_name] = _devpods_bool_to_str(val)
    return resolved

def patch_devpods_kubeconfig_variable(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("devpods") or {}
    patch_kubeconfig_variable(spec, profile_entry=profile_entry, cat=cat, section_description=DEVPODS_PLATFORM_SECTION_DESCRIPTION, weight=14)

def build_devpods_cpu_dropdowns(cat):
    tiers = cat.get("cpu_tiers")
    if isinstance(tiers, list) and tiers:
        options = []
        for tier in tiers:
            if not isinstance(tier, dict): continue
            label = str(tier.get("label", tier.get("vcpus", ""))).strip()
            value = tier.get("millicores") or tier.get("value")
            if label and value is not None: options.append({"label": label, "value": str(value)})
        if options: return options
    return list(DEVPODS_CPU_DROPDOWN_OPTIONS)

def build_devpods_resource_dropdowns(cat):
    vmaas_cat = (config.get("CATEGORIES") or {}).get("vmaas") or {}
    sku_variants = vmaas_cat.get("sku_variants") or cat.get("resource_tiers") or {}
    cpu_options = build_devpods_cpu_dropdowns(cat)
    memory_options = []
    seen_mem = set()
    for tier in VMAAS_FLEX_SIZING_VARIANTS:
        cfg = sku_variants.get(tier) or {}
        if not isinstance(cfg, dict): continue
        mem = str(cfg.get("guest_memory_size", "")).strip()
        if mem and mem not in seen_mem:
            seen_mem.add(mem)
            memory_options.append({"label": memory_mb_to_gb_label(mem), "value": mem})
    return cpu_options, memory_options

def patch_devpods_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if name in DEVPODS_USER_EDITABLE_VARIABLES else "notallowed"

def patch_devpods_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = DEVPODS_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_devpods_display_layout(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        layout = DEVPODS_DISPLAY_LAYOUT.get(name)
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        if name in DEVPODS_PLATFORM_VARIABLE_KEYS: dm["sectionDescription"] = DEVPODS_PLATFORM_SECTION_DESCRIPTION
        elif name in ("CPU", "Memory", "GPU Count"): dm["sectionDescription"] = DEVPODS_POD_SIZE_SECTION_DESCRIPTION
        elif layout.get("sectionDescription"): dm["sectionDescription"] = layout["sectionDescription"]

def patch_devpods_ssh_key_display_metadata(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Autogenerate SSH Key": continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["radioOptions"] = [{"label": "Yes", "value": "true"}, {"label": "No", "value": "false"}]
        dm["type"] = "radio"
        break

def patch_devpods_platform_variables(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("devpods") or {}
    patch_platform_variables(spec, profile_entry, cat, DEVPODS_PLATFORM_VARIABLE_KEYS)

def patch_devpods_locked_feature_flags(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("devpods") or {}
    flags = resolve_devpods_locked_feature_flags(cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in flags: continue
        var["value"] = flags[name]
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"

def patch_devpods_flex_sizing_display_metadata(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("devpods") or {}
    variant = (profile_entry or {}).get("variant") or "standard"
    cpu_options, memory_options = build_devpods_resource_dropdowns(cat)
    gpu_options = DEVPODS_GPU_DROPDOWN_OPTIONS.get(variant) or DEVPODS_GPU_DROPDOWN_OPTIONS["standard"]
    sizing_dropdowns = {"CPU": cpu_options, "Memory": memory_options, "GPU Count": gpu_options}
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        entries = sizing_dropdowns.get(name)
        if not entries: continue
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        ov["type"] = "allowed"
        ov["restrictedValues"] = [entry["value"] for entry in entries]
        dm = opts.setdefault("displayMetadata", {})
        dm["type"] = "dropdown"
        dm["dropdownValues"] = entries
        dm.pop("disabled", None)

def patch_devpods_pod_image_display_metadata(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Pod Image": continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        if not dm.get("dropdownValues"):
            dm["dropdownValues"] = [
                {"label": "Ubuntu 22-04", "value": "registry.rafay-edge.net/ubuntu-22-04-ssh-pod:v1"},
                {"label": "Ubuntu 24-04", "value": "registry.rafay-edge.net/ubuntu-24-04-ssh-pod:v1"},
                {"label": "Pytorch-2.1 CUDA11.8", "value": "registry.rafay-edge.net/dev/pytorch-2.1-ubuntu-22-04-ssh:20250804221258"},
                {"label": "Pytorch-2.2 CUDA 12.1", "value": "registry.rafay-edge.net/dev/pytorch-2.2-ubuntu-22-04-ssh:20250805041333"},
                {"label": "Pytorch-2.4 CUDA 12.4", "value": "registry.rafay-edge.net/dev/pytorch-2-4-ubuntu-24-04-ssh:20250731185301"},
                {"label": "Pytorch-2.7 CUDA 12.8", "value": "registry.rafay-edge.net/dev/pytorch-2.7-ubuntu-22-04-ssh:20250805015309"},
            ]
        dm["type"] = "dropdown"
        break

def patch_devpods_compute_profile(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("devpods") or {}
    devpods_sizing = resolve_devpods_config(cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") in devpods_sizing: var["value"] = devpods_sizing[var.get("name")]
    patch_devpods_platform_variables(spec, profile_entry, cat=cat)
    patch_devpods_kubeconfig_variable(spec, profile_entry, cat=cat)
    patch_devpods_locked_feature_flags(spec, profile_entry, cat=cat)
    patch_devpods_variable_overrides(spec)
    patch_locked_node_type_variable(spec, profile_entry, cat=cat)
    patch_devpods_variable_aliases(spec)
    patch_devpods_display_layout(spec)
    patch_devpods_flex_sizing_display_metadata(spec, profile_entry, cat=cat)
    patch_devpods_pod_image_display_metadata(spec)
    patch_devpods_ssh_key_display_metadata(spec)


# ---------------- MKS ----------------
MKS_USER_EDITABLE_VARIABLES = frozenset({"Cluster Kubernetes Version", "Blueprint Name", "HA Enabled", "Dedicated Control Plane", "Labels", "CNI Provider", "Pod Network Cidr range", "Service Cidr range", "Control Plane Node Spec", "Master Nodes", "Worker Node SKU", "Public Key", "Extra Args"})
MKS_CONFIG_LOCKED_DISPLAY_VARIABLES = frozenset({"Blueprint Version", "Installer Certificate TTL", "Proxy Config", "Kubernetes Upgrade Options", "System Components Placement", "Node OS", "Allocate Public IP to Control Plane Nodes", "Allocate Public IP to Worker Nodes", "Extra Cloud init args"})
MKS_CONFIG_DEFAULT_KEYS = {"Cluster Kubernetes Version": "cluster_kubernetes_version", "Blueprint Name": "blueprint_name", "Blueprint Version": "blueprint_version", "CNI Provider": "cni_provider", "Control Plane Node Spec": "master_node_sku", "Master Nodes": "master_nodes", "Node OS": "node_os", "HA Enabled": "ha_enabled", "Dedicated Control Plane": "is_master_dedicated", "Allocate Public IP to Control Plane Nodes": "allocate_public_ip_master", "Allocate Public IP to Worker Nodes": "allocate_public_ip_worker", "Pod Network Cidr range": "pod_network_cidr", "Service Cidr range": "service_cidr", "Labels": "labels", "Extra Args": "extra_args", "Installer Certificate TTL": "installer_certificate_ttl", "Proxy Config": "proxy_config", "System Components Placement": "system_components_placement", "Kubernetes Upgrade Options": "kubernetes_upgrade", "Extra Cloud init args": "extra_cloud_init_args"}
MKS_LOCKED_PLATFORM_VARIABLES = {"Project Name": "project_name", "Is Enterprise use case": "enterprise_use_case", "Self Signed Controller": "self_signed_controller", "Self Hosted Controller": "self_hosted_controller"}
MKS_INTERNAL_NOT_EDITABLE = frozenset({"Action", "Username", "Cluster Name", "Workspace Name", "Device Detail Flag", "device_details", "No Of Nodes", "GPU Type"})
MKS_VARIABLE_ALIASES = {"Cluster Kubernetes Version": "Kubernetes version", "Blueprint Name": "Blueprint", "Blueprint Version": "Blueprint version", "HA Enabled": "High availability", "Dedicated Control Plane": "Dedicated masters", "CNI Provider": "CNI plugin", "Pod Network Cidr range": "Pod network CIDR", "Service Cidr range": "Service CIDR", "Control Plane Node Spec": "Control Plane Node Spec", "Master Nodes": "Master node count", "Node OS": "Node operating system", "Worker Node SKU": "Worker pools", "Allocate Public IP to Control Plane Nodes": "Public IP (masters)", "Allocate Public IP to Worker Nodes": "Public IP (workers)", "Public Key": "SSH public key", "Extra Args": "Kubelet extra args", "Extra Cloud init args": "Cloud-init scripts", "Labels": "Cluster labels", "Installer Certificate TTL": "Installer cert TTL (days)", "Proxy Config": "Outbound proxy", "System Components Placement": "System placement", "Kubernetes Upgrade Options": "Upgrade strategy"}
MKS_DISPLAY_LAYOUT = {"Cluster Kubernetes Version": {"section": "Cluster", "weight": 10}, "Blueprint Name": {"section": "Cluster", "weight": 11}, "Blueprint Version": {"section": "Cluster", "weight": 12}, "HA Enabled": {"section": "Cluster", "weight": 13}, "Dedicated Control Plane": {"section": "Cluster", "weight": 14}, "Labels": {"section": "Cluster", "weight": 15}, "Installer Certificate TTL": {"section": "Cluster", "weight": 16}, "Proxy Config": {"section": "Cluster", "weight": 17}, "Kubernetes Upgrade Options": {"section": "Cluster", "weight": 18}, "System Components Placement": {"section": "Cluster", "weight": 19}, "CNI Provider": {"section": "Networking", "weight": 20}, "Pod Network Cidr range": {"section": "Networking", "weight": 21}, "Service Cidr range": {"section": "Networking", "weight": 22}, "Control Plane Node Spec": {"section": "Nodes", "weight": 30}, "Master Nodes": {"section": "Nodes", "weight": 31}, "Node OS": {"section": "Nodes", "weight": 32}, "Worker Node SKU": {"section": "Nodes", "weight": 33}, "Allocate Public IP to Control Plane Nodes": {"section": "Nodes", "weight": 34}, "Allocate Public IP to Worker Nodes": {"section": "Nodes", "weight": 35}, "Public Key": {"section": "Access", "weight": 40}, "Extra Args": {"section": "Advanced", "weight": 50}, "Extra Cloud init args": {"section": "Advanced", "weight": 51}}
MKS_CLUSTER_SECTION_DESCRIPTION = "Core Kubernetes cluster settings."
MKS_NETWORKING_SECTION_DESCRIPTION = "Pod and service network configuration."
MKS_NODES_SECTION_DESCRIPTION = "Master and worker node sizing and connectivity."
MKS_ACCESS_SECTION_DESCRIPTION = "SSH access to cluster nodes."
MKS_ADVANCED_SECTION_DESCRIPTION = "Optional tuning for kubelet, upgrades, and cloud-init."
MKS_K8S_VERSION_OPTIONS = [{"label": "v1.34.1", "value": "v1.34.1"}, {"label": "v1.33.5", "value": "v1.33.5"}, {"label": "v1.32.9", "value": "v1.32.9"}, {"label": "v1.31.13", "value": "v1.31.13"}]
MKS_BLUEPRINT_NAME_OPTIONS = [{"label": "minimal", "value": "minimal"}, {"label": "default", "value": "default"}, {"label": "default-gpu", "value": "default-gpu"}]
MKS_CNI_OPTIONS = [{"label": "Calico 3.26.1", "value": "Calico-3.26.1"}, {"label": "Calico 3.28.1", "value": "Calico-3.28.1"}, {"label": "Cilium 1.14.1", "value": "Cilium-1.14.1"}, {"label": "Cilium 1.15.7", "value": "Cilium-1.15.7"}]
MKS_NODE_OS_OPTIONS = [{"label": "Ubuntu 22.04", "value": "Ubuntu22.04"}]
MKS_MASTER_NODES_OPTIONS = [{"label": "1", "value": "1"}, {"label": "3", "value": "3"}, {"label": "5", "value": "5"}]
MKS_VMAAS_NODE_SKU_OPTIONS = [{"label": "Small GPU VM (1 GPU)", "value": "vmaas-gpu-small"}, {"label": "Medium GPU VM (2 GPU)", "value": "vmaas-gpu-medium"}, {"label": "Large GPU VM (4 GPU)", "value": "vmaas-gpu-large"}, {"label": "xLarge GPU VM (8 GPU)", "value": "vmaas-gpu-xlarge"}]
MKS_WORKER_POOL_NODE_COUNTS = [1, 2, 3, 4, 5, 6, 7, 8]
MKS_BOOLEAN_RADIO_FIELDS = frozenset({"HA Enabled", "Dedicated Control Plane"})
MKS_LOCKED_BOOLEAN_RADIO_FIELDS = frozenset({"Allocate Public IP to Control Plane Nodes", "Allocate Public IP to Worker Nodes"})

def _mks_bool_to_str(val):
    if isinstance(val, bool): return "true" if val else "false"
    return str(val).strip().lower()

def resolve_mks_config(cat, profile_entry):
    entry = profile_entry or {}; resolved = {}
    for var_name, cfg_key in MKS_CONFIG_DEFAULT_KEYS.items():
        val = entry.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None:
            if cfg_key in ("ha_enabled", "is_master_dedicated", "allocate_public_ip_master", "allocate_public_ip_worker", "self_signed_controller", "self_hosted_controller"):
                resolved[var_name] = _mks_bool_to_str(val)
            else: resolved[var_name] = str(val) if not isinstance(val, (dict, list)) else val
    return resolved

def resolve_mks_platform_config(cat, profile_entry):
    entry = profile_entry or {}; resolved = {}
    for var_name, cfg_key in MKS_LOCKED_PLATFORM_VARIABLES.items():
        val = entry.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None:
            if cfg_key in ("enterprise_use_case", "self_signed_controller", "self_hosted_controller"): resolved[var_name] = _mks_bool_to_str(val)
            else: resolved[var_name] = str(val)
    return resolved

def patch_mks_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if var.get("name") in MKS_USER_EDITABLE_VARIABLES else "notallowed"

def patch_mks_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = MKS_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_mks_display_layout(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        layout = MKS_DISPLAY_LAYOUT.get(name)
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        section = layout["section"]
        if section == "Cluster": dm["sectionDescription"] = MKS_CLUSTER_SECTION_DESCRIPTION
        elif section == "Networking": dm["sectionDescription"] = MKS_NETWORKING_SECTION_DESCRIPTION
        elif section == "Nodes": dm["sectionDescription"] = MKS_NODES_SECTION_DESCRIPTION
        elif section == "Access": dm["sectionDescription"] = MKS_ACCESS_SECTION_DESCRIPTION
        elif section == "Advanced": dm["sectionDescription"] = MKS_ADVANCED_SECTION_DESCRIPTION

def patch_mks_boolean_radio_fields(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") not in MKS_BOOLEAN_RADIO_FIELDS: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["radioOptions"] = [{"label": "Yes", "value": "true"}, {"label": "No", "value": "false"}]
        dm["type"] = "radio"

def vmaas_node_sku_options(cat):
    skus = (cat or {}).get("vmaas_node_skus")
    if isinstance(skus, list) and skus: return skus
    return list(MKS_VMAAS_NODE_SKU_OPTIONS)

def build_mks_worker_sku_json_schema(cat):
    sku_options = vmaas_node_sku_options(cat)
    skuname_enum = [{"key": o["label"], "value": o["value"]} for o in sku_options]
    node_counts = (cat or {}).get("worker_pool_node_counts") or MKS_WORKER_POOL_NODE_COUNTS
    return json.dumps({
        "title": "Worker SKU List", "type": "array",
        "items": {
            "type": "object", "title": "Worker SKU Entry",
            "properties": {
                "poolname": {"type": "string", "title": "Name(Unique)", "description": "Pool Name"},
                "skuname": {"type": "string", "title": "SKU Name", "description": "Worker VMAAS SKU", "enum": skuname_enum},
                "noOfSku": {"type": "string", "title": "No of Nodes", "description": "Allowed quantities for each SKU", "enum": node_counts},
            },
            "required": ["poolname", "skuname", "noOfSku"],
            "additionalProperties": False,
        },
    })

def patch_mks_worker_node_sku_schema(spec, cat):
    schema = build_mks_worker_sku_json_schema(cat)
    allowed_skus = [o["value"] for o in vmaas_node_sku_options(cat)]
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Worker Node SKU": continue
        opts = var.setdefault("options", {})
        dm = opts.setdefault("displayMetadata", {})
        dm["jsonSchema"] = schema
        dm.setdefault("type", "jsonSchema")
        if "Worker Node SKU" in MKS_USER_EDITABLE_VARIABLES:
            ov = opts.setdefault("override", {})
            ov["type"] = "allowed"
            ov["restrictedValues"] = allowed_skus
        break

def patch_mks_dropdown_fields(spec, cat):
    dropdowns = {
        "Cluster Kubernetes Version": cat.get("kubernetes_versions") or MKS_K8S_VERSION_OPTIONS,
        "Blueprint Name": cat.get("blueprint_names") or MKS_BLUEPRINT_NAME_OPTIONS,
        "CNI Provider": cat.get("cni_options") or MKS_CNI_OPTIONS,
        "Master Nodes": cat.get("master_nodes_options") or MKS_MASTER_NODES_OPTIONS,
        "Control Plane Node Spec": vmaas_node_sku_options(cat),
    }
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        options = dropdowns.get(name)
        if not options: continue
        opts = var.setdefault("options", {})
        dm = opts.setdefault("displayMetadata", {})
        dm["type"] = "dropdown"
        dm["dropdownValues"] = options
        if name in MKS_USER_EDITABLE_VARIABLES:
            ov = opts.setdefault("override", {})
            ov["type"] = "allowed"
            ov["restrictedValues"] = [o["value"] for o in options]

def patch_mks_locked_config_display(spec):
    node_os_labels = {o["value"]: o["label"] for o in MKS_NODE_OS_OPTIONS}
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in MKS_CONFIG_LOCKED_DISPLAY_VARIABLES: continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True
        if name in MKS_LOCKED_BOOLEAN_RADIO_FIELDS:
            dm["radioOptions"] = [{"label": "Yes", "value": "true"}, {"label": "No", "value": "false"}]
            dm["type"] = "radio"
        elif name == "Node OS":
            value = str(var.get("value", "")).strip()
            dm["type"] = "dropdown"
            dm["dropdownValues"] = [{"label": node_os_labels.get(value, value), "value": value}]
        elif name == "Blueprint Version":
            value = str(var.get("value", "latest")).strip()
            dm["type"] = "dropdown"
            dm["dropdownValues"] = [{"label": value, "value": value}]

def patch_mks_config_values(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("mks") or {}
    defaults = resolve_mks_config(cat, profile_entry)
    platform = resolve_mks_platform_config(cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name in defaults: var["value"] = defaults[name]
        elif name in platform: var["value"] = platform[name]
        elif name == "Project Name":
            proj = (platform.get("Project Name") or config.get("SYSTEM_CATALOG_PROJECT") or config.get("CATALOG_PROJECT_NAME") or config.get("PROJECT_NAME"))
            if proj:
                var["value"] = str(proj)
                var["valueType"] = "text"

def patch_mks_hide_internal_variables(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") not in MKS_INTERNAL_NOT_EDITABLE: continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True; dm["section"] = "Internal"; dm["weight"] = 900

def patch_mks_env_vars(spec, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("mks") or {}
    host_env = config.get("HOST_ENV")
    api_key = cat.get("admin_api_key") or config.get("API_KEY")
    for env_var in spec.get("envVars", []):
        if not isinstance(env_var, dict): continue
        key = env_var.get("key")
        opts = env_var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        if key == "Controller Endpoint" and host_env: env_var["value"] = str(host_env)
        elif key == "API Key" and api_key:
            env_var["value"] = str(api_key)
            opts["sensitive"] = True; opts["mask"] = True; opts["required"] = True


# ---------------- NOTEBOOK ----------------
NOTEBOOK_USER_EDITABLE_VARIABLES = frozenset({"CPU", "Memory", "GPU Count", "Node Type", "Pod Image", "Env Vars"})
NOTEBOOK_PLATFORM_VARIABLE_KEYS = {"Host Cluster Name": "host_cluster_name", "Hostname Suffix": "hostname_suffix", "Ingress Class Name": "ingress_class_name"}
NOTEBOOK_CONFIG_VALUE_KEYS = {"CPU": "cpu", "Memory": "memory", "GPU Count": "gpu_count", "GPU Type": "gpu_type", "GPU Profile": "gpu_profile", "Container Port": "container_port", "Pod Image": "pod_image", "Arguments": "arguments", "Commands": "commands", "Enable Storage": "enable_storage", "Enable Web Access": "enable_web_access", "Enable SSH Access": "enable_ssh_access", "Autogenerate SSH Key": "autogenerate_ssh_key", "SKU Type": "sku_type", "Volume Mounts": "volume_mounts"}
NOTEBOOK_EMPTY_STORAGE_VARIABLES = frozenset({"Access Mode", "Storage Class", "Storage Path", "Storage Size"})
NOTEBOOK_LOCKED_FEATURE_FLAGS = {"Enable SSH Access": "enable_ssh_access", "Enable Web Access": "enable_web_access", "Enable Storage": "enable_storage"}
NOTEBOOK_HIDDEN_VARIABLES = frozenset({"Action", "Device Details", "SKU Type", "KeyAlpha", "KeyBeta", "KeyGamma", "KeyX", "KeyY", "KeyZ", "Log Success Pattern", "Openshift", "Use Cert Manager", "Annotations", "Pod Scheduler Name", "Namespace", "Timeout Seconds", "Pending Timeout Seconds", "Access Mode", "Storage Class", "Storage Path", "Storage Size", "Is Private Registry", "Registry Email", "Registry Password", "Registry Server", "Registry Username", "SSL Certificate Private Key", "SSL Certificate Public Key", "Ingress Annotations", "Security Context", "Container Security Context", "Labels", "Node Selectors", "Tolerations"})
NOTEBOOK_VARIABLE_ALIASES = {"CPU": "vCPUs", "Memory": "Memory (MiB)", "GPU Count": "GPUs", "Pod Image": "Notebook image", "Host Cluster Name": "Kubernetes cluster", "Hostname Suffix": "Domain name", "Ingress Class Name": "Ingress class", "Node Type": "GPU node type", "Env Vars": "Environment variables"}
NOTEBOOK_DISPLAY_LAYOUT = {"Host Cluster Name": {"section": "Cluster & networking", "weight": 10}, "Hostname Suffix": {"section": "Cluster & networking", "weight": 11}, "Ingress Class Name": {"section": "Cluster & networking", "weight": 12}, "Node Type": {"section": "Cluster & networking", "weight": 13}, "Pod Image": {"section": "Notebook", "weight": 20}, "Container Port": {"section": "Notebook", "weight": 21}, "Commands": {"section": "Notebook", "weight": 22}, "Arguments": {"section": "Notebook", "weight": 23}, "GPU Count": {"section": "Resources", "weight": 30}, "CPU": {"section": "Resources", "weight": 31}, "Memory": {"section": "Resources", "weight": 32}, "GPU Type": {"section": "Resources", "weight": 33}, "GPU Profile": {"section": "Resources", "weight": 34}, "Enable Storage": {"section": "Storage", "weight": 40}, "Volume Mounts": {"section": "Storage", "weight": 41}, "Enable Web Access": {"section": "Web access", "weight": 50}, "Enable SSH Access": {"section": "Login & access", "weight": 60}, "Autogenerate SSH Key": {"section": "Login & access", "weight": 61}, "Public Key": {"section": "Login & access", "weight": 62}, "Env Vars": {"section": "Advanced", "weight": 70}}
NOTEBOOK_PLATFORM_SECTION_DESCRIPTION = "Target cluster, ingress, and GPU node placement for the notebook."
NOTEBOOK_RESOURCES_SECTION_DESCRIPTION = "CPU, memory, and GPU resources for the notebook pod."
NOTEBOOK_DEFAULT_IMAGE_OPTIONS = [{"label": "Minimal environment", "value": f"{DEFAULT_REGISTRY}/jupyter/minimal-notebook:2026-02-02"}, {"label": "Datascience environment", "value": f"{DEFAULT_REGISTRY}/jupyter/datascience-notebook:2026-02-02"}, {"label": "Spark environment", "value": f"{DEFAULT_REGISTRY}/jupyter/all-spark-notebook:2026-02-02"}, {"label": "Tensorflow environment", "value": f"{DEFAULT_REGISTRY}/jupyter/tensorflow-notebook:2026-02-02"}, {"label": "Tensorflow environment with CUDA", "value": f"{DEFAULT_REGISTRY}/jupyter/tensorflow-notebook:cuda-2026-02-02"}, {"label": "PyTorch environment with CUDA", "value": f"{DEFAULT_REGISTRY}/jupyter/pytorch-notebook:cuda12-2026-02-02"}]
NOTEBOOK_DEFAULT_GPU_OPTIONS = [{"label": "0", "value": "0"}, {"label": "1", "value": "1"}, {"label": "2", "value": "2"}, {"label": "4", "value": "4"}, {"label": "8", "value": "8"}]
NOTEBOOK_DEFAULT_COMMAND_SETTINGS = {"commands": '["start-notebook.sh"]', "arguments": '["--NotebookApp.token=generateToken()"]'}
NOTEBOOK_DEVPODS_PLATFORM_KEYS = ("host_cluster_name", "kubeconfig_file", "kubeconfig_path", "hostname_suffix", "ingress_class_name")

def _notebook_bool_to_str(val):
    if isinstance(val, bool): return "true" if val else "false"
    return str(val).strip().lower()

def _notebook_json_value(val):
    if isinstance(val, (dict, list)): return json.dumps(val, separators=(",", ":"))
    return str(val)

def _notebook_category_value(cat, profile_entry, cfg_key, fallback_cat=None):
    entry = profile_entry or {}
    val = entry.get(cfg_key)
    if val is None and cat: val = cat.get(cfg_key)
    if val is None and fallback_cat: val = fallback_cat.get(cfg_key)
    return val

def notebook_platform_category(cat, profile_entry):
    merged = {}
    for key in NOTEBOOK_DEVPODS_PLATFORM_KEYS:
        val = resolve_common_platform_value(key, profile_entry, cat)
        if val is not None: merged[key] = val
    return merged

def resolve_notebook_command_settings(cat, profile_entry):
    entry = profile_entry or {}
    merged = dict(NOTEBOOK_DEFAULT_COMMAND_SETTINGS)
    notebook_cmd = (cat or {}).get("command_settings")
    if isinstance(notebook_cmd, dict): merged.update(notebook_cmd)
    entry_cmd = entry.get("command_settings")
    if isinstance(entry_cmd, dict): merged.update(entry_cmd)
    for key in ("commands", "arguments"):
        val = entry.get(key)
        if val is None: val = (cat or {}).get(key)
        if val is not None: merged[key] = val
    return merged

def resolve_notebook_config(cat, profile_entry):
    cmd_settings = resolve_notebook_command_settings(cat, profile_entry)
    resolved = {}
    for var_name, cfg_key in NOTEBOOK_CONFIG_VALUE_KEYS.items():
        if cfg_key in ("commands", "arguments"): val = cmd_settings.get(cfg_key)
        else: val = _notebook_category_value(cat, profile_entry, cfg_key)
        if val is not None: resolved[var_name] = val
    return resolved

def resolve_notebook_locked_feature_flags(cat, profile_entry):
    entry = profile_entry or {}; resolved = {}
    for var_name, cfg_key in NOTEBOOK_LOCKED_FEATURE_FLAGS.items():
        val = entry.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None: resolved[var_name] = _notebook_bool_to_str(val)
    return resolved

def build_notebook_image_options(cat):
    images = (cat or {}).get("notebook_images")
    if isinstance(images, list) and images: return images
    return list(NOTEBOOK_DEFAULT_IMAGE_OPTIONS)

def build_notebook_gpu_options(cat):
    gpu_options = (cat or {}).get("gpu_count_options")
    if isinstance(gpu_options, list) and gpu_options:
        return [{"label": str(o["label"]), "value": str(o["value"])} for o in gpu_options if isinstance(o, dict)]
    return list(NOTEBOOK_DEFAULT_GPU_OPTIONS)

def patch_notebook_kubeconfig_variable(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("notebook") or {}
    patch_kubeconfig_variable(spec, profile_entry=profile_entry, cat=cat, section_description=NOTEBOOK_PLATFORM_SECTION_DESCRIPTION, weight=14)

def patch_notebook_config_values(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("notebook") or {}
    values = resolve_notebook_config(cat, profile_entry)
    json_fields = frozenset({"Arguments", "Commands", "Volume Mounts"})
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in values: continue
        val = values[name]
        if name in json_fields: var["value"] = _notebook_json_value(val)
        elif name in NOTEBOOK_LOCKED_FEATURE_FLAGS: var["value"] = _notebook_bool_to_str(val)
        else: var["value"] = str(val)

def patch_notebook_platform_variables(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("notebook") or {}
    patch_platform_variables(spec, profile_entry, cat, NOTEBOOK_PLATFORM_VARIABLE_KEYS)

def patch_notebook_locked_feature_flags(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("notebook") or {}
    flags = resolve_notebook_locked_feature_flags(cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in flags: continue
        var["value"] = flags[name]
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        if name in ("Enable Web Access", "Enable SSH Access", "Enable Storage"):
            dm["radioOptions"] = [{"label": "Yes", "value": "true"}, {"label": "No", "value": "false"}]
            dm["type"] = "radio"
            dm["disabled"] = True

def patch_notebook_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if name in NOTEBOOK_USER_EDITABLE_VARIABLES else "notallowed"

def patch_notebook_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = NOTEBOOK_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_notebook_display_layout(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        layout = NOTEBOOK_DISPLAY_LAYOUT.get(name)
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        if name in NOTEBOOK_PLATFORM_VARIABLE_KEYS: dm["sectionDescription"] = NOTEBOOK_PLATFORM_SECTION_DESCRIPTION
        elif name in ("CPU", "Memory", "GPU Count"): dm["sectionDescription"] = NOTEBOOK_RESOURCES_SECTION_DESCRIPTION

def patch_notebook_resource_dropdowns(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("notebook") or {}
    devpods_cat = (config.get("CATEGORIES") or {}).get("devpods") or {}
    cpu_options = build_devpods_cpu_dropdowns(devpods_cat or cat)
    
    # Notebook memory options
    vmaas_cat = (config.get("CATEGORIES") or {}).get("vmaas") or {}
    sku_variants = vmaas_cat.get("sku_variants") or {}
    memory_options = []
    seen_mem = set()
    for tier in VMAAS_FLEX_SIZING_VARIANTS:
        cfg = sku_variants.get(tier) or {}
        if not isinstance(cfg, dict): continue
        mem = str(cfg.get("guest_memory_size", "")).strip()
        if mem and mem not in seen_mem:
            seen_mem.add(mem)
            memory_options.append({"label": memory_mb_to_gb_label(mem), "value": mem})

    gpu_options = build_notebook_gpu_options(cat)
    image_options = build_notebook_image_options(cat)
    dropdowns = {"CPU": cpu_options, "Memory": memory_options, "GPU Count": gpu_options, "Pod Image": image_options}
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        entries = dropdowns.get(name)
        if not entries: continue
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        if name in NOTEBOOK_USER_EDITABLE_VARIABLES:
            ov["type"] = "allowed"
            ov["restrictedValues"] = [entry["value"] for entry in entries]
        dm = opts.setdefault("displayMetadata", {})
        dm["type"] = "dropdown"
        dm["dropdownValues"] = entries
        if name == "Pod Image": dm["alias"] = "Notebook image"
        dm.pop("disabled", None)

def patch_notebook_pod_image_display(spec, cat=None):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Pod Image": continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = "Notebook"
        dm["tooltip"] = "Image must be accessible from the cluster (public or via registry credentials)."
        break

def patch_notebook_clear_storage_variables(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") not in NOTEBOOK_EMPTY_STORAGE_VARIABLES: continue
        var["value"] = ""
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"

def patch_notebook_hide_internal_variables(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") not in NOTEBOOK_HIDDEN_VARIABLES: continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True; dm["section"] = "Internal"; dm["weight"] = 900


# ---------------- INFERENCE ----------------
INFERENCE_USER_EDITABLE_VARIABLES = frozenset({"KeyAlpha", "Node Type"})
INFERENCE_PLATFORM_VARIABLE_KEYS = NOTEBOOK_PLATFORM_VARIABLE_KEYS
INFERENCE_CONFIG_VALUE_KEYS = {"CPU": "cpu", "Memory": "memory", "GPU Count": "gpu_count", "GPU Type": "gpu_type", "GPU Profile": "gpu_profile", "Container Port": "container_port", "Pod Image": "pod_image", "Arguments": "arguments", "Commands": "commands", "Enable Storage": "enable_storage", "Enable Web Access": "enable_web_access", "Enable SSH Access": "enable_ssh_access", "Autogenerate SSH Key": "autogenerate_ssh_key", "SKU Type": "sku_type", "Log Success Pattern": "log_success_pattern", "Auto Rollback": "auto_rollback"}
INFERENCE_EMPTY_STORAGE_VARIABLES = NOTEBOOK_EMPTY_STORAGE_VARIABLES
INFERENCE_LOCKED_FEATURE_FLAGS = {"Enable SSH Access": "enable_ssh_access", "Enable Web Access": "enable_web_access", "Enable Storage": "enable_storage"}
INFERENCE_HIDDEN_VARIABLES = frozenset({"Action", "Device Details", "SKU Type", "KeyBeta", "KeyGamma", "KeyY", "KeyZ", "Openshift", "Use Cert Manager", "Annotations", "Pod Scheduler Name", "Namespace", "Timeout Seconds", "Pending Timeout Seconds", "Access Mode", "Storage Class", "Storage Path", "Storage Size", "Is Private Registry", "Registry Email", "Registry Password", "Registry Server", "Registry Username", "SSL Certificate Private Key", "SSL Certificate Public Key", "Ingress Annotations", "Security Context", "Container Security Context", "Labels", "Node Selectors", "Tolerations", "Autogenerate SSH Key", "Public Key", "Pod Image", "Env Vars"})
INFERENCE_VARIABLE_ALIASES = {"KeyAlpha": "HuggingFace token", "KeyX": "Model", "Host Cluster Name": "Kubernetes cluster", "Hostname Suffix": "Domain name", "Ingress Class Name": "Ingress class", "Node Type": "GPU node type", "CPU": "vCPUs", "Memory": "Memory (MiB)", "GPU Count": "GPUs"}
INFERENCE_DISPLAY_LAYOUT = {"KeyAlpha": {"section": "Model access", "weight": 10}, "KeyX": {"section": "Model", "weight": 11}, "Host Cluster Name": {"section": "Cluster & networking", "weight": 20}, "Hostname Suffix": {"section": "Cluster & networking", "weight": 21}, "Ingress Class Name": {"section": "Cluster & networking", "weight": 22}, "Node Type": {"section": "Cluster & networking", "weight": 23}, "CPU": {"section": "Resources", "weight": 30}, "Memory": {"section": "Resources", "weight": 31}, "GPU Count": {"section": "Resources", "weight": 32}, "GPU Type": {"section": "Resources", "weight": 33}, "GPU Profile": {"section": "Resources", "weight": 34}, "Enable Web Access": {"section": "Web access", "weight": 40}}
INFERENCE_PLATFORM_SECTION_DESCRIPTION = "Target cluster, ingress, and GPU node placement for inference."
INFERENCE_DEFAULT_COMMAND_SETTINGS = {"commands": '["/bin/sh", "-c"]', "arguments": '["vllm serve injectValue(KeyX) --trust-remote-code --enable-chunked-prefill --tensor-parallel-size injectValue(GPUCount) --gpu-memory-utilization 0.9 --distributed-executor-backend mp --api-key generateToken() injectValue(KeyY)"]'}
INFERENCE_DEFAULT_ENV_VARS = '["HUGGING_FACE_HUB_TOKEN=injectValue(KeyAlpha)", "VLLM_LOG_LEVEL=DEBUG"]'

def resolve_inference_model(profile_entry, cat):
    entry = profile_entry or {}
    variant = entry.get("variant")
    if not variant: return {}
    models = (cat or {}).get("models") or {}
    model = models.get(variant)
    if isinstance(model, dict): return model
    return {}

def resolve_inference_icon_url(cat, profile_entry):
    entry = profile_entry or {}
    icon_url = entry.get("iconURL") or entry.get("icon_url")
    if icon_url: return str(icon_url)
    model = resolve_inference_model(profile_entry, cat)
    icon_url = model.get("icon_url") or model.get("iconURL")
    if icon_url: return str(icon_url)
    return resolve_profile_icon_url(cat, profile_entry, category="inference")

def resolve_inference_command_settings(cat, profile_entry):
    entry = profile_entry or {}
    merged = dict(INFERENCE_DEFAULT_COMMAND_SETTINGS)
    cmd_cfg = (cat or {}).get("command_settings")
    if isinstance(cmd_cfg, dict): merged.update(cmd_cfg)
    entry_cmd = entry.get("command_settings")
    if isinstance(entry_cmd, dict): merged.update(entry_cmd)
    for key in ("commands", "arguments"):
        val = entry.get(key)
        if val is None: val = (cat or {}).get(key)
        if val is not None: merged[key] = val
    return merged

def resolve_inference_config(cat, profile_entry):
    cmd_settings = resolve_inference_command_settings(cat, profile_entry)
    resolved = {}
    for var_name, cfg_key in INFERENCE_CONFIG_VALUE_KEYS.items():
        if cfg_key in ("commands", "arguments"): val = cmd_settings.get(cfg_key)
        else: val = _notebook_category_value(cat, profile_entry, cfg_key)
        if val is not None: resolved[var_name] = val
    return resolved

def resolve_inference_locked_feature_flags(cat, profile_entry):
    entry = profile_entry or {}; resolved = {}
    for var_name, cfg_key in INFERENCE_LOCKED_FEATURE_FLAGS.items():
        val = entry.get(cfg_key)
        if val is None: val = cat.get(cfg_key)
        if val is not None: resolved[var_name] = _notebook_bool_to_str(val)
    return resolved

def patch_inference_metadata(metadata, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    model = resolve_inference_model(profile_entry, cat)
    display_name = model.get("display_name") or model.get("displayName")
    if display_name: metadata["displayName"] = str(display_name)
    model_id = model.get("model_id")
    if model_id: metadata["description"] = f"vLLM inference — {model_id}"

def patch_inference_kubeconfig_variable(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    patch_kubeconfig_variable(spec, profile_entry=profile_entry, cat=cat, section_description=INFERENCE_PLATFORM_SECTION_DESCRIPTION, weight=24)

def patch_inference_config_values(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    values = resolve_inference_config(cat, profile_entry)
    json_fields = frozenset({"Arguments", "Commands"})
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in values: continue
        val = values[name]
        if name in json_fields: var["value"] = _notebook_json_value(val)
        elif name in INFERENCE_LOCKED_FEATURE_FLAGS: var["value"] = _notebook_bool_to_str(val)
        else: var["value"] = str(val)
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "Env Vars": continue
        env_val = (cat or {}).get("env_vars")
        if env_val is None: env_val = INFERENCE_DEFAULT_ENV_VARS
        var["value"] = _notebook_json_value(env_val)
        break

def patch_inference_model_variable(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    model = resolve_inference_model(profile_entry, cat)
    model_id = model.get("model_id")
    if not model_id: return
    display_name = model.get("display_name") or model.get("displayName") or model_id
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "KeyX": continue
        var["value"] = str(model_id)
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        ov["type"] = "allowed"
        ov["restrictedValues"] = [str(model_id)]
        dm = opts.setdefault("displayMetadata", {})
        dm["alias"] = "Model"
        dm["type"] = "dropdown"
        dm["disabled"] = True
        dm["dropdownValues"] = [{"label": str(display_name), "value": str(model_id)}]
        dm["section"] = "Model"
        break

def patch_inference_platform_variables(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    patch_platform_variables(spec, profile_entry, cat, INFERENCE_PLATFORM_VARIABLE_KEYS)

def patch_inference_locked_feature_flags(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    flags = resolve_inference_locked_feature_flags(cat, profile_entry)
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in flags: continue
        var["value"] = flags[name]
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        if name in ("Enable Web Access", "Enable SSH Access", "Enable Storage"):
            dm["radioOptions"] = [{"label": "Yes", "value": "true"}, {"label": "No", "value": "false"}]
            dm["type"] = "radio"
            dm["disabled"] = True

def patch_inference_keyalpha_display(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "KeyAlpha": continue
        opts = var.setdefault("options", {})
        opts["sensitive"] = True
        opts["mask"] = True
        opts.setdefault("override", {})["type"] = "allowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["alias"] = "HuggingFace token"
        dm["type"] = "text"
        dm["section"] = "Model access"
        break

def patch_inference_variable_overrides(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name in ("KeyX", "GPU Count", "Node Type"): continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "allowed" if name in INFERENCE_USER_EDITABLE_VARIABLES else "notallowed"

def patch_inference_variable_aliases(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        alias = INFERENCE_VARIABLE_ALIASES.get(var.get("name"))
        if alias: var.setdefault("options", {}).setdefault("displayMetadata", {})["alias"] = alias

def patch_inference_display_layout(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        layout = INFERENCE_DISPLAY_LAYOUT.get(name)
        if not layout: continue
        dm = var.setdefault("options", {}).setdefault("displayMetadata", {})
        dm["section"] = layout["section"]
        dm["weight"] = layout["weight"]
        if name in INFERENCE_PLATFORM_VARIABLE_KEYS or name == "Node Type":
            dm["sectionDescription"] = INFERENCE_PLATFORM_SECTION_DESCRIPTION

def patch_inference_gpu_count_display(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    gpu_count = str(cat.get("gpu_count", "1"))
    for var in spec.get("variables", []):
        if not isinstance(var, dict) or var.get("name") != "GPU Count": continue
        var["value"] = gpu_count
        opts = var.setdefault("options", {})
        ov = opts.setdefault("override", {})
        ov["type"] = "allowed"
        ov["restrictedValues"] = [gpu_count]
        dm = opts.setdefault("displayMetadata", {})
        dm["alias"] = "GPUs"
        dm["type"] = "dropdown"
        dm["disabled"] = True
        dm["dropdownValues"] = [{"label": gpu_count, "value": gpu_count}]
        dm["section"] = "Resources"
        dm["tooltip"] = "Fixed for this SKU; used for pricing."
        break

def patch_inference_locked_resources(spec, profile_entry=None, cat=None):
    cat = cat or (config.get("CATEGORIES") or {}).get("inference") or {}
    locked_values = {"CPU": str(cat.get("cpu", "24000")), "Memory": str(cat.get("memory", "65536"))}
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name not in locked_values: continue
        var["value"] = locked_values[name]
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True
        if name == "CPU":
            dm["type"] = "dropdown"
            dm["dropdownValues"] = [{"label": str(int(locked_values[name]) // 1000), "value": locked_values[name]}]
        elif name == "Memory":
            dm["type"] = "dropdown"
            dm["dropdownValues"] = [{"label": memory_mb_to_gb_label(locked_values[name]), "value": locked_values[name]}]

def patch_inference_clear_storage_variables(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") not in INFERENCE_EMPTY_STORAGE_VARIABLES: continue
        var["value"] = ""
        var.setdefault("options", {}).setdefault("override", {})["type"] = "notallowed"

def patch_inference_hide_internal_variables(spec):
    for var in spec.get("variables", []):
        if not isinstance(var, dict): continue
        if var.get("name") not in INFERENCE_HIDDEN_VARIABLES: continue
        opts = var.setdefault("options", {})
        opts.setdefault("override", {})["type"] = "notallowed"
        dm = opts.setdefault("displayMetadata", {})
        dm["disabled"] = True; dm["section"] = "Internal"; dm["weight"] = 900


# ---------------- PATCH MASTER FUNCTIONS ----------------
def patch_service_profile_from_category(spec, category, profile_entry=None, metadata=None):
    if category == "notebook":
        cat = (config.get("CATEGORIES") or {}).get("notebook") or {}
        patch_notebook_config_values(spec, profile_entry, cat=cat)
        patch_notebook_platform_variables(spec, profile_entry, cat=cat)
        patch_notebook_kubeconfig_variable(spec, profile_entry, cat=cat)
        patch_notebook_locked_feature_flags(spec, profile_entry, cat=cat)
        patch_notebook_variable_overrides(spec)
        patch_locked_node_type_variable(spec, profile_entry, cat=cat)
        patch_notebook_variable_aliases(spec)
        patch_notebook_display_layout(spec)
        patch_notebook_resource_dropdowns(spec, profile_entry, cat=cat)
        patch_notebook_pod_image_display(spec, cat=cat)
        patch_notebook_clear_storage_variables(spec)
        patch_notebook_hide_internal_variables(spec)
        icon_url = resolve_profile_icon_url(cat, profile_entry, category="notebook")
        if icon_url is not None: spec["iconURL"] = icon_url
        system_catalog = resolve_profile_system_catalog(cat, profile_entry)
        if system_catalog is not None: spec["systemCatalog"] = system_catalog
    elif category == "inference":
        cat = (config.get("CATEGORIES") or {}).get("inference") or {}
        if metadata is not None: patch_inference_metadata(metadata, profile_entry, cat=cat)
        patch_inference_config_values(spec, profile_entry, cat=cat)
        patch_inference_platform_variables(spec, profile_entry, cat=cat)
        patch_inference_kubeconfig_variable(spec, profile_entry, cat=cat)
        patch_inference_locked_feature_flags(spec, profile_entry, cat=cat)
        patch_inference_locked_resources(spec, profile_entry, cat=cat)
        patch_inference_keyalpha_display(spec)
        patch_inference_variable_overrides(spec)
        patch_locked_node_type_variable(spec, profile_entry, cat=cat)
        patch_inference_model_variable(spec, profile_entry, cat=cat)
        patch_inference_gpu_count_display(spec, profile_entry, cat=cat)
        patch_inference_variable_aliases(spec)
        patch_inference_display_layout(spec)
        patch_inference_clear_storage_variables(spec)
        patch_inference_hide_internal_variables(spec)
        icon_url = resolve_inference_icon_url(cat, profile_entry)
        if icon_url is not None: spec["iconURL"] = icon_url
        system_catalog = resolve_profile_system_catalog(cat, profile_entry)
        if system_catalog is not None: spec["systemCatalog"] = system_catalog


def patch_compute_profile_from_category(spec, category, profile_entry=None, profile_name=""):
    cat = (config.get("CATEGORIES") or {}).get(category) or {}
    if not cat: return
    variables = spec.get("variables")
    if not variables: return
    entry = profile_entry or {}
    host_console = config.get("HOST_ENV")
    ops_host = config.get("OPS_CONSOLE_HOST")
    partner_key = config.get("API_KEY")
    prov = cat.get("baremetal_provisioner_name")
    hints = entry.get("root_device_hints")
    if hints is None: hints = cat.get("root_device_hints")
    tags_val = resolve_profile_tags(cat, entry)
    vmaas_guest = resolve_vmaas_guest_config(cat, entry) if category == "vmaas" else {}
    vmaas_guest_by_var = {"Guest CPU Count": "guest_cpu_count", "Guest Memory Size": "guest_memory_size", "Guest Disk Size": "guest_disk_size", "Guest GPU Count": "guest_gpu_count"}
    firewall_enable = None
    if category == "vmaas":
        firewall_enable = entry.get("firewall_enable")
        if firewall_enable is None: firewall_enable = cat.get("firewall_enable", "false")
    console_names = frozenset(("CONSOLE_ENDPOINT", "Console Endpoint"))
    ops_names = frozenset(("OPS_CONSOLE_ENDPOINT", "Ops Console Endpoint"))
    partner_names = frozenset(("PARTNER_API_KEY", "Partner API Key"))

    for var in variables:
        if not isinstance(var, dict): continue
        name = var.get("name")
        if name == "baremetal_provisioner_name" and prov is not None: var["value"] = str(prov)
        elif name == "root_device_hints" and hints is not None:
            var["value"] = json.dumps(hints, separators=(",", ":")) if isinstance(hints, dict) else str(hints)
        elif name in console_names and host_console: var["value"] = str(host_console)
        elif name in ops_names and ops_host: var["value"] = str(ops_host)
        elif name in partner_names and partner_key: var["value"] = str(partner_key)
        elif name == "NCP Server API Key": var["value"] = get_ncp_server_api_key()
        elif name == "tags" and tags_val is not None: var["value"] = str(tags_val)
        elif category == "vmaas" and name == "Firewall Enable" and firewall_enable is not None:
            var["value"] = "true" if firewall_enable else "false" if isinstance(firewall_enable, bool) else str(firewall_enable)
        elif category == "vmaas" and name in vmaas_guest_by_var:
            guest_key = vmaas_guest_by_var[name]
            if vmaas_guest.get(guest_key) is not None: var["value"] = vmaas_guest[guest_key]

    if category == "vmaas":
        patch_datacenter_id_variable(spec, profile_entry=entry, cat=cat)
        patch_vmaas_variable_overrides(spec)
        patch_vmaas_variable_aliases(spec)
        patch_vmaas_display_layout(spec, profile_entry)
        patch_vmaas_public_ip_display_metadata(spec)
        patch_vmaas_sku_locked_display_metadata(spec, profile_entry)
        patch_vmaas_fixed_sku_memory_display_metadata(spec, profile_entry)
        patch_vmaas_flex_sizing_display_metadata(spec, profile_entry, cat=cat)
    elif category == "bmaas":
        patch_bmaas_variable_overrides(spec)
        patch_bmaas_variable_aliases(spec)
        patch_bmaas_display_layout(spec, profile_entry)
    elif category == "devpods":
        patch_devpods_compute_profile(spec, profile_entry=profile_entry, cat=cat)
        return
    elif category == "mks":
        patch_mks_config_values(spec, profile_entry, cat=cat)
        patch_mks_variable_overrides(spec)
        patch_mks_variable_aliases(spec)
        patch_mks_display_layout(spec)
        patch_mks_boolean_radio_fields(spec)
        patch_mks_dropdown_fields(spec, cat)
        patch_mks_worker_node_sku_schema(spec, cat)
        patch_mks_locked_config_display(spec)
        patch_mks_hide_internal_variables(spec)
        patch_mks_env_vars(spec, cat=cat)
        
    icon_url = resolve_profile_icon_url(cat, entry, category=category)
    if icon_url is not None: spec["iconURL"] = icon_url
    system_catalog = resolve_profile_system_catalog(cat, entry)
    if system_catalog is not None: spec["systemCatalog"] = system_catalog
    
def find_server_dependents(kind, name, original_project):
    """
    Finds all resources on the server that depend on the given resource, recursively.
    Dynamically fetches ALL projects in the organization to ensure dependencies in 
    other projects (like 'nr') are not missed.
    """
    base_url = str(config["urls"]["BASE_URL"]).rstrip("/")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-API-KEY": config.get("API_KEY", ""),
        "X-ORGANIZATION-ID": config.get("ORG_HASH", ""),
    }
    
    target_proj = config.get("PROJECT_NAME")
    system_proj = config.get("SYSTEM_CATALOG_PROJECT", "system-catalog")
    
    # Start with base catalogs
    base_projects = []
    for p in [system_proj, "default-catalog", original_project, target_proj]:
        if p and p not in base_projects:
            base_projects.append(p)
            
    # --- FETCH ALL PROJECTS ---
    # Dynamically find every project in the org to ensure we don't miss custom ETs/Profiles in other projects
    if "_all_projects_fetched" not in config:
        try:
            limit, offset = 100, 0
            total_fetched = 0
            while True:
                
                proj_url = f"{base_url}/apis/system.k8smgmt.io/v3/projects?limit={limit}&offset={offset}"
                r = requests.get(proj_url, headers=headers, verify=False, timeout=15)
                if r.status_code == 200:
                    data = r.json()
                    chunk = data.get("items") or data.get("results") or []
                    total_fetched += len(chunk)
                    
                    for p_item in chunk:
                        total_fetched += 1
                        p_name = p_item.get("metadata", {}).get("name")
                        sys.stdout.write(f"\r\033[K[Phase 1] Fetching projects (Total: {total_fetched}) -> Reading: {str(p_name)[:30]}")
                        sys.stdout.flush()
                        if p_name and p_name not in base_projects:
                            base_projects.append(p_name)
                            
                    if len(chunk) < limit: break
                    offset += limit
                else: break
                
            config["_all_projects_list"] = base_projects
            config["_all_projects_fetched"] = True
        except Exception:
            pass
    else:
        for p in config.get("_all_projects_list", []):
            if p not in base_projects: base_projects.append(p)

    # --- CACHING STEP WITH PAGINATION AND FALLBACKS --- 
    if "_server_resources_cache" not in config:
        cache = {"rt": [], "et": [], "cp": [], "sp": [], "wfh": [], "dr": []}
        seen_keys = set()
        
        def fetch_paginated(endpoint):
            fetched_items = []
            limit, offset = 100, 0
            while True:
                try:
                    url = f"{base_url}/apis/{endpoint}?limit={limit}&offset={offset}"
                    r = requests.get(url, headers=headers, verify=False, timeout=15)
                    if r.status_code == 200:
                        data = r.json()
                        chunk = data.get("items") or data.get("results") or []
                        fetched_items.extend(chunk)
                        if len(chunk) < limit: break
                        offset += limit
                    else: break
                except Exception: break
            return fetched_items

        def add_to_cache(cat, items, queried_proj):
            for item in items:
                item_name = item.get("metadata", {}).get("name")
                if not item_name: continue
                
                # Treat origin project explicitly from metadata
                true_proj = item.get("metadata", {}).get("project") or queried_proj
                
                # Deduplicate based on category and name ONLY.
                key = (cat, item_name)
                if key not in seen_keys:
                    seen_keys.add(key)
                    item["_project"] = true_proj
                    cache[cat].append(item)

        # Loop through EVERY project in the org and cache the resources
        for proj in base_projects:
            add_to_cache("rt", fetch_paginated(f"eaas.envmgmt.io/v1/projects/{proj}/resourcetemplates"), proj)
            add_to_cache("et", fetch_paginated(f"eaas.envmgmt.io/v1/projects/{proj}/environmenttemplates"), proj)
            add_to_cache("cp", fetch_paginated(f"paas.envmgmt.io/v1/projects/{proj}/computeprofiles"), proj)
            add_to_cache("sp", fetch_paginated(f"paas.envmgmt.io/v1/projects/{proj}/serviceprofiles"), proj)
            add_to_cache("wfh", fetch_paginated(f"eaas.envmgmt.io/v1/projects/{proj}/workflowhandlers"), proj)
            add_to_cache("dr", fetch_paginated(f"eaas.envmgmt.io/v1/projects/{proj}/drivers"), proj)

        sys.stdout.write("\r\033[K")
        sys.stdout.flush()
        config["_server_resources_cache"] = cache
        
    cache = config["_server_resources_cache"]
    
    all_dependents = []
    queue = [(kind, name)]
    visited = set()
    
    while queue:
        curr_kind, curr_name = queue.pop(0)
        if (curr_kind, curr_name) in visited: continue
        visited.add((curr_kind, curr_name))
        
        found_in_this_step = []
        
        # 1. WFH / Driver -> RT
        if curr_kind in ["WorkflowHandler", "Driver"]:
            for rt in cache["rt"]:
                tasks = rt.get("spec", {}).get("providerOptions", {}).get("custom", {}).get("tasks", [])
                for task in tasks:
                    task_type = task.get("type", "").lower()
                    if curr_kind == "WorkflowHandler" and "workflowhandler" in task_type:
                        ref = str(task.get("workflowHandler", {}).get("name", "")).split('/')[-1]
                        if ref == curr_name: found_in_this_step.append({"kind": "ResourceTemplate", "name": rt["metadata"]["name"], "project": rt["_project"]})
                    elif curr_kind == "Driver" and "driver" in task_type:
                        ref = str(task.get("driver", {}).get("name", "")).split('/')[-1]
                        if ref == curr_name: found_in_this_step.append({"kind": "ResourceTemplate", "name": rt["metadata"]["name"], "project": rt["_project"]})
        
        # 2. RT -> ET
        elif curr_kind == "ResourceTemplate":
            for et in cache["et"]:
                for res in et.get("spec", {}).get("resources", []):
                    kind_str = str(res.get("kind", "") or res.get("type", "")).lower()
                    if "resourcetemplate" in kind_str:
                        rt_ref = res.get("resourceTemplate", {}).get("name") or res.get("name", "")
                        if str(rt_ref).split('/')[-1] == curr_name:
                            found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"], "project": et["_project"]})
                        
        # 3. Context -> ET / WFH / Driver
        elif curr_kind == "ConfigContext":
            for et in cache["et"]:
                for ctx in et.get("spec", {}).get("contexts", []):
                    ctx_ref = ctx.get("context", {}).get("name") or ctx.get("name", "")
                    if str(ctx_ref).split('/')[-1] == curr_name:
                        found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"], "project": et["_project"]})
                for action in et.get("spec", {}).get("actions", []):
                    ctx_ref = action.get("context", {}).get("name", "")
                    if str(ctx_ref).split('/')[-1] == curr_name:
                        found_in_this_step.append({"kind": "EnvironmentTemplate", "name": et["metadata"]["name"], "project": et["_project"]})
            
            for wfh in cache["wfh"]:
                for inp in wfh.get("spec", {}).get("inputs", []):
                    if str(inp.get("name", "")).split('/')[-1] == curr_name:
                        found_in_this_step.append({"kind": "WorkflowHandler", "name": wfh["metadata"]["name"], "project": wfh["_project"]})
            
            for dr in cache["dr"]:
                for inp in dr.get("spec", {}).get("inputs", []):
                    if str(inp.get("name", "")).split('/')[-1] == curr_name:
                        found_in_this_step.append({"kind": "Driver", "name": dr["metadata"]["name"], "project": dr["_project"]})

        # 4. ET -> Profiles
        elif curr_kind == "EnvironmentTemplate":
            for cp in cache["cp"]:
                et_ref = cp.get("spec", {}).get("environmentTemplate")
                et_name = (et_ref.get("name", "") if isinstance(et_ref, dict) else str(et_ref or "")).split('/')[-1]
                if et_name == curr_name:
                    found_in_this_step.append({"kind": "ComputeProfile", "name": cp["metadata"]["name"], "project": cp["_project"]})
            
            for sp in cache["sp"]:
                et_ref = sp.get("spec", {}).get("environmentTemplate")
                et_name = (et_ref.get("name", "") if isinstance(et_ref, dict) else str(et_ref or "")).split('/')[-1]
                if et_name == curr_name:
                    found_in_this_step.append({"kind": "ServiceProfile", "name": sp["metadata"]["name"], "project": sp["_project"]})

        # Process found elements
        for item in found_in_this_step:
            if not any(d["kind"] == item["kind"] and d["name"] == item["name"] and d["project"] == item["project"] for d in all_dependents):
                all_dependents.append(item)
                queue.append((item["kind"], item["name"]))
                
    return all_dependents

# ==========================================
# ENTITY CREATION (MERGED PHASE LOGIC)
# ==========================================

def create_entity(file_path, shr=True, load_mode="catalog", profile_entry=None):
    try:
        if not os.path.isfile(file_path): raise FileNotFoundError(f"Entity file not found: {file_path}")

        template_name = "Unknown"
        with open(file_path, "r") as entity:
            data = yaml.safe_load(entity)
            if not data or "kind" not in data: return False

            kind = data["kind"]
            metadata = data.get("metadata", {})
            if not metadata: data["metadata"] = {}
            metadata = data["metadata"]
            
            if load_mode == "custom":
                metadata["project"] = config.get("SYSTEM_CATALOG_PROJECT", "system-catalog")
            else:
                metadata["project"] = config.get("PROJECT_NAME")
                
            template_name = metadata.get("name", "Unknown")
            is_existing, actual_project = check_resource_exists(kind, template_name)

            # PHASE 1: Collect Existing Resources / Display Status Bar
            if config.get("CHECK_MODE", False):
                if kind != "Repository":
                    sys.stdout.write(f"\r\033[K[Phase 1] Checking ({kind}): {template_name}")
                    sys.stdout.flush()
                    if is_existing:
                        if "existing_resources" not in config: config["existing_resources"] = []
                        
                        # Add the resource itself
                        res_entry = {
                            "kind": kind, "name": template_name, 
                            "actual_project": actual_project,
                            "intended_project": metadata["project"]
                        }
                        if not any(r['kind'] == kind and r['name'] == template_name and r['actual_project'] == actual_project for r in config["existing_resources"]):
                            config["existing_resources"].append(res_entry)
                        
                        # Find and add server-side dependents (Now cross-project capable)
                        deps = find_server_dependents(kind, template_name, actual_project)
                        for dep in deps:
                            dep_entry = {
                                "kind": dep["kind"], "name": dep["name"],
                                "actual_project": dep["project"],
                                "intended_project": metadata["project"],
                                "is_dependent": True
                            }
                            if not any(r['kind'] == dep['kind'] and r['name'] == dep['name'] and r['actual_project'] == dep['project'] for r in config["existing_resources"]):
                                config["existing_resources"].append(dep_entry)
                return True

            # PHASE 2: Execute (Skip Cross-Project, Overwrite Same-Project)
            if is_existing and kind != "Repository":
                if actual_project and actual_project != metadata["project"]:
                    print(f"Skipping {kind} --> {template_name} (Exists globally in project '{actual_project}')")
                    
                    # Track skipped cross-project conflicts so they appear in the final summary table
                    global error_list
                    error_list.append({
                        "type": "CONFLICT",
                        "context": f"{kind}::{template_name}",
                        "message": f"Skipped due to cross-project conflict in '{actual_project}'"
                    })
                    
                    return True

            action_str = "Overwriting" if is_existing else "Creating"

            if "annotations" not in metadata: metadata["annotations"] = {}
            metadata["annotations"]["eaas.envmgmt.io/releaseversion"] = config.get("VERSION")

            spec = data.get("spec", {})
            host_env = config.get("HOST_ENV")
            
            if kind == "EnvironmentTemplate":
                for context in spec.get("contexts", []):
                    for env in context.get("data", {}).get("envs", []):
                        if env.get("key") == "Controller Endpoint": env["value"] = host_env
            
            elif kind == "ComputeProfile":
                profile_name = metadata.get("name", "")
                for env_var in spec.get("envVars", []):
                    if env_var.get("key") == "Controller Endpoint": env_var["value"] = host_env
                if load_mode == "custom" and profile_entry and profile_entry.get("category"):
                    patch_compute_profile_from_category(spec, profile_entry.get("category"), profile_entry=profile_entry, profile_name=profile_name)
                if load_mode == "custom":
                    config.setdefault("loaded_custom_profiles", set()).add((kind, template_name))

            elif kind == "ServiceProfile":
                for env_var in spec.get("envVars", []):
                    if env_var.get("key") == "Controller Endpoint": env_var["value"] = host_env
                if load_mode == "custom" and profile_entry and profile_entry.get("category"):
                    patch_service_profile_from_category(spec, profile_entry.get("category"), profile_entry=profile_entry, metadata=metadata)
                if load_mode == "custom":
                    config.setdefault("loaded_custom_profiles", set()).add((kind, template_name))

            if kind in ["ConfigContext", "ResourceTemplate", "EnvironmentTemplate", "Driver", "WorkflowHandler"] and shr:
                data["spec"]["sharing"] = {"enabled": True, "projects": [{"name": "*"}]}

            yaml_data = yaml.dump(data, default_flow_style=False)

            if kind == "SecretSealer":
                print(f"{action_str} SecretSealer --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_SECRETSEALER"], None, yaml_data)

            elif kind == "Agent":
                print(f"{action_str} Agent --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_AGENT"], None, yaml_data)

            elif kind == "Repository":
                print(f"{action_str} Repository --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_REPO"], None, yaml_data)

            elif kind == "ConfigContext":
                print(f"{action_str} ConfigContext --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_CONFIGCONTEXT"], None, yaml_data)

            elif kind == "ResourceTemplate":
                print(f"{action_str} ResourceTemplate --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_RESOURCE"], None, yaml_data)
            
            elif kind == "Resource":
                print(f"{action_str} Resource --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_CUSTOM_RESOURCE"], None, yaml_data)
            
            elif kind == "EnvironmentTemplate":
                print(f"{action_str} EnvironmentTemplate --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_ENVIRONMENT"], None, yaml_data)

            elif kind in ["Driver", "WorkflowHandler"]:
                print(f"{action_str} Driver/Workflow handler --> {template_name}")
                url = config["urls"]["ADD_WRKFLW"] if kind == "WorkflowHandler" else config["urls"]["ADD_DRIVER"]
                return make_v3_api("POST", url, None, yaml_data)

            elif kind == "ComputeProfile":
                print(f"{action_str} Compute Profile --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_CPROFILE"], None, yaml_data)

            elif kind == "ServiceProfile":
                print(f"{action_str} Service Profile --> {template_name}")
                return make_v3_api("POST", config["urls"]["ADD_SPROFILE"], None, yaml_data)

            else:
                raise ValueError(f"Invalid type '{kind}' for template '{template_name}'")
            
    except Exception as e:
        err_kind = kind if 'kind' in locals() else "Resource"
        err_name = template_name if 'template_name' in locals() else file_path
        handle_error(e, f"{err_kind}::{err_name}", error_type="ENTITY_ERROR")
        return False

def create_resource(source_path, resource_type):
    if config.get("PATCH"):
        files = config.get("PATCH_ITEMS", {}).get("repositories", [])
    else:
        directory_path = source_path + resource_type
        files = get_yaml_files(directory_path)
    for f in files:
        try:
            if validate_template_file(f, source_path): create_entity(f)
        except Exception as e:
            if handle_error(e, f"Error processing {f}"): continue

def create_resource_cprofile(source_path, resource_type):
    templates = config["CPROFILES"]
    if templates is None or config["LOAD_ALL_TEMPLATES"]: return
    for t in templates:
        try:
            if os.path.isfile(t) and validate_template_file(t, source_path): create_entity(t)
        except Exception as e:
            if handle_error(e, f"Error processing compute profile {t}"): continue

def create_resource_sprofile(source_path, resource_type):
    templates = config["SPROFILES"]
    if templates is None or config["LOAD_ALL_TEMPLATES"]: return
    for t in templates:
        try:
            if os.path.isfile(t) and validate_template_file(t, source_path): create_entity(t)
        except Exception as e:
            if handle_error(e, f"Error processing service profile {t}"): continue

def create_resource_context(source_path, resource_type):
    templates = config["CONTEXTS"]
    if templates is None or config["LOAD_ALL_TEMPLATES"]: return
    for t in templates:
        try:
            if os.path.isfile(t) and validate_template_file(t, source_path): create_entity(t)
        except Exception as e:
            if handle_error(e, f"Error processing config context {t}"): continue

def create_resource_res(source_path, resource_type):
    if config["LOAD_ALL_TEMPLATES"]:
        files = get_yaml_files(source_path + resource_type)
        for f in files:
            try:
                if validate_template_file(f, source_path): create_entity(f)
            except Exception as e:
                if handle_error(e, f"Error processing {f}"): continue
    else:
        templates = config["RESTEMPLATES"]
        if templates is None: return
        for t in templates:
            try:
                if os.path.isfile(t) and validate_template_file(t, source_path): create_entity(t)
            except Exception as e:
                if handle_error(e, f"Error processing resource template {t}"): continue

def create_environment_resource(source_path, resource_type):
    if config["LOAD_ALL_TEMPLATES"]:
        files = get_yaml_files(source_path + resource_type)
        for f in files:
            try:
                if validate_template_file(f, source_path): create_entity(f)
            except Exception as e:
                if handle_error(e, f"Error processing {f}"): continue
    else:
        templates = config["TEMPLATES"]
        if templates is None: return
        for t in templates:
            try:
                if os.path.isdir(t):
                    for file in get_yaml_files(t):
                        try:
                            if validate_template_file(file, source_path): create_entity(file)
                        except Exception as e:
                            if handle_error(e, f"Error processing {file}"): continue
                elif os.path.isfile(t):
                    if validate_template_file(t, source_path): create_entity(t)
            except Exception as e:
                if handle_error(e, f"Error processing environment template {t}"): continue

def create_shrenvironment_resource(source_path, resource_type):
    if config["LOAD_ALL_TEMPLATES"]:
        files = get_yaml_files(source_path + resource_type)
        for f in files:
            try:
                if validate_template_file(f, source_path): create_entity(f, shr=True)
            except Exception as e:
                if handle_error(e, f"Error processing {f}"): continue
    else:
        templates = config["SHRTEMPLATES"]
        if templates is None: return
        for t in templates:
            try:
                if os.path.isdir(t):
                    for file in get_yaml_files(t):
                        try:
                            if validate_template_file(file, source_path): create_entity(file, shr=True)
                        except Exception as e:
                            if handle_error(e, f"Error processing {file}"): continue
                elif os.path.isfile(t):
                    if validate_template_file(t, source_path): create_entity(t, shr=True)
            except Exception as e:
                if handle_error(e, f"Error processing environment template {t}"): continue

def create_resource_workflow_handlers(source_path, resource_type):
    templates = config["WRKFLW"]
    if templates is None or config["LOAD_ALL_TEMPLATES"]: return
    for t in templates:
        try:
            if os.path.isfile(t) and validate_template_file(t, source_path): create_entity(t)
        except Exception as e:
            if handle_error(e, f"Error processing workflow handler {t}"): continue

def load_all_resources():
    tRoot = os.getcwd() + "/catalog-templates/"
    try:
        create_resource(tRoot, "repository")
        create_resource_context(tRoot, "context")
        create_resource_workflow_handlers(tRoot, "workflow-handlers")
        create_resource_res(tRoot, "res-templates")
        create_environment_resource(tRoot, "env-templates")
        create_shrenvironment_resource(tRoot, "env-templates")
        create_resource_cprofile(tRoot, "compute-profiles")
        create_resource_sprofile(tRoot, "service-profiles")
    except Exception as e:
        handle_error(e, "load_all_resources", error_type="GLOBAL_ERROR")

def create_project():
    proj = config.get("PROJECT_NAME")
    try:
        make_v3_api("GET", config.get("urls", {}).get("GET_PROJECT_DETAIL"), None, None)
    except Exception as e:
        print(f"Project not found or check failed.. creating project {proj}")
        project_spec = f"apiVersion: system.k8smgmt.io/v3\nkind: Project\nmetadata:\n   name: {proj}\nspec:\n   default: false\n   driftWebhook:\n      enable: true"
        try:
            make_v3_api("POST", config.get("urls", {}).get("CREATE_PROJECT"), None, project_spec)
        except Exception as create_error:
             handle_error(create_error, f"Failed to create project {proj}", error_type="API_ERROR")

def save_existing_to_values_yaml(target_project, resources_list):
    opsenv = config.get("FQDN") or config.get("HOST_ENV", "").replace("console.", "ops-console.")
    output_lines = [
        "## environment", f"hostenv: {config.get('HOST_ENV', '')}", f"opsenv: {opsenv or ''}", "",
        "## API key", f"apikey: {config.get('API_KEY', '')} ", "",
        "##Project name", f"projectname: {target_project}", "",
        "##to enable debug", f"debug: {config.get('DEBUG', False)}", "",
        "##Load all template or only templates specified under templates",
        f"load_all_templates: {config.get('LOAD_ALL_TEMPLATES', False)}", "",
        "# Active and Approved orgs will be loaded", "delete_from_all_orgs: False", "",
        "##Load the org hash list", f"org_hash: {config.get('ORG_HASH', '')}", ""
    ]

    kind_map = {
        "ComputeProfile": "compute-profiles", "ServiceProfile": "service-profiles",
        "ConfigContext": "context", "EnvironmentTemplate": "templates",
        "ResourceTemplate": "res-templates", "WorkflowHandler": "workflow-handlers",
        "Driver": "workflow-handlers"
    }

    grouped_resources = {v: set() for v in set(kind_map.values())} 
    for res in resources_list:
        mapped_kind = kind_map.get(res["kind"])
        if mapped_kind: grouped_resources[mapped_kind].add(res["name"])

    all_wh_drivers = get_all_workflows_and_drivers(target_project)
    for item in all_wh_drivers: grouped_resources["workflow-handlers"].add(item)

    for key in ["compute-profiles", "service-profiles", "context", "templates", "res-templates", "workflow-handlers"]:
        if grouped_resources[key]:
            output_lines.append(f"{key}:")
            for item in sorted(list(grouped_resources[key])): output_lines.append(f"- {item}")
        else: output_lines.append(f"{key}: []")

    try:
        with open("values-delete.yaml", "w") as f: f.write("\n".join(output_lines) + "\n")
        print("  ✓ Saved successfully")
    except Exception as e:
        print(f"  ✗ Failed to save values-delete.yaml: {e}")


# ==========================================
# SETUP & CONFIGURATION READERS
# ==========================================

def _parse_bool_config(value, default=True):
    if value is None: return default
    if isinstance(value, str): return value.strip().lower() not in ("false", "0", "no", "off")
    return bool(value)

LOAD_CUSTOM_SKU_CATEGORIES = ("bmaas", "vmaas", "devpods", "mks", "notebook", "inference")

def parse_load_custom_skus(cfg):
    defaults = {cat: True for cat in LOAD_CUSTOM_SKU_CATEGORIES}
    raw = cfg.get("load_custom_skus")
    if raw is None: return defaults
    if not isinstance(raw, dict):
        print(f"Error: load_custom_skus must be a mapping. Got: {type(raw).__name__}")
        sys.exit(1)
    resolved = dict(defaults)
    for key, val in raw.items():
        if key not in LOAD_CUSTOM_SKU_CATEGORIES:
            print(f"\033[33mWarning: load_custom_skus unknown key '{key}' ignored\033[0m")
            continue
        resolved[key] = _parse_bool_config(val, default=True)
    if resolved.get("mks") is True and resolved.get("vmaas") is False:
        print("\033[31mFATAL ERROR: For MKS provisioning, VMaaS SKUs are required. Please set 'vmaas: true' under 'load_custom_skus' in config.yaml.\033[0m")
        sys.exit(1)
    return resolved

def is_custom_sku_category_enabled(category):
    flags = config.get("LOAD_CUSTOM_SKUS") or {}
    if not category or category not in LOAD_CUSTOM_SKU_CATEGORIES: return False
    return bool(flags.get(category, True))

def filter_enabled_custom_profiles(entries):
    enabled = []; skipped_unknown = 0; skipped_disabled = {}
    for entry in entries:
        if not isinstance(entry, dict):
            print(f"\033[33mWarning: custom_profiles entry is not a mapping: {entry!r}\033[0m")
            continue
        category = entry.get("category")
        if not category or category not in LOAD_CUSTOM_SKU_CATEGORIES:
            skipped_unknown += 1
            continue
        if not is_custom_sku_category_enabled(category):
            skipped_disabled[category] = skipped_disabled.get(category, 0) + 1
            continue
        enabled.append(entry)
    return enabled

CATALOG_SKU_DEFAULTS = {"TEMPLATES": [], "SHRTEMPLATES": [], "CPROFILES": [], "SPROFILES": [], "RESTEMPLATES": [], "CONTEXTS": [], "WRKFLW": [], "IMAGE_TAG_MAP": {}, "VERSION": "v1", "SHARING": False, "LOAD_ALL_TEMPLATES": False, "LOAD_ALL_ORGS": False}

def _merged_config_data(data):
    if not isinstance(data, dict): return {}
    merged = dict(data)
    custom = merged.pop("custom", None)
    if isinstance(custom, dict):
        for key, val in custom.items(): merged[key] = val
    return merged

def read_values(values_file):
    try:
        if not os.path.isfile(values_file):
            print(f"\033[31mError: Configuration file not found: {values_file}\033[0m")
            sys.exit(1)

        with open(values_file, "r") as f:
            data = yaml.safe_load(f)
            if not data:
                print(f"\033[31mError: Configuration file is empty: {values_file}\033[0m")
                sys.exit(1)

            cfg = _merged_config_data(data)
            env_block = cfg.get("environment") or {}
            host_env = cfg.get("hostenv") or env_block.get("hostenv")
            project_name = cfg.get("projectname")
            ops_env = cfg.get("opsenv") or env_block.get("opsenv")
            load_images_flag = cfg.get("load_images", False)

            if not host_env or len(host_env) <= 6:
                print(f"Error: hostenv seems to be missing or invalid. Got: {host_env}")
                sys.exit(1)
            if not project_name:
                print(f"Error: projectname seems to be missing. Got: {project_name}")
                sys.exit(1)

            agents = cfg.get("agents", ["paas-agent"])
            if isinstance(agents, str): agents = [agents]
            if not isinstance(agents, list) or not agents:
                print(f"Error: agents must be a non-empty list of agent names. Got: {agents!r}")
                sys.exit(1)

            categories = {}
            for cat_key in ("bmaas", "mks", "vmaas", "devpods", "notebook", "inference"):
                cat_val = cfg.get(cat_key)
                if isinstance(cat_val, dict): categories[cat_key] = cat_val
            # Determine Patch mode first
            is_patch_mode = _parse_bool_config(cfg.get("patch", False), default=False)
            if load_images_flag:
                update_image_flag = True
            elif is_patch_mode:
                update_image_flag = _parse_bool_config(cfg.get("update_image_registry", False), default=False)
            else:
                update_image_flag = True

            if is_patch_mode:
                untar_flag = True
            else:
                untar_flag = _parse_bool_config(cfg.get("untar", False), default=False)

            global config
            config = {
                "HOST_ENV": host_env,
                "OPS_CONSOLE_HOST": ops_env,
                "DATACENTER": cfg.get("datacenter", "default-dc"),
                "DATACENTER_RESOLVE_VIA_API": _parse_bool_config(cfg.get("datacenter_resolve_via_api", True), default=True),
                "CONSOLE_API_KEY": cfg.get("console_api_key"),
                "LOAD_GLOBAL_SETTINGS": _parse_bool_config(cfg.get("load_global_settings", True), default=True),
                "GLOBAL_SETTINGS_TEMPLATE": cfg.get("global_settings_template", "global-settings.yaml"),
                "AGENTS": agents,
                "NODE_TYPE": cfg.get("node_type"),
                "NODE_TYPES": cfg.get("node_types"),
                "HOST_CLUSTER_NAME": cfg.get("host_cluster_name"),
                "KUBECONFIG_FILE": cfg.get("kubeconfig_file"),
                "HOSTNAME_SUFFIX": cfg.get("hostname_suffix"),
                "INGRESS_CLASS_NAME": cfg.get("ingress_class_name"),
                "CATALOG_VERSION": cfg.get("catalog_version"),
                "API_KEY": cfg.get("apikey"),
                "CATALOG_PROJECT_NAME": project_name,
                "PROJECT_NAME": project_name,
                "SYSTEM_CATALOG_PROJECT": cfg.get("system_catalog_project", "system-catalog"),
                "CATEGORIES": categories,
                "CUSTOM_PROFILES": cfg.get("custom_profiles") or [],
                "LOAD_CUSTOM_SKUS": parse_load_custom_skus(cfg),
                "FQDN": ops_env if load_images_flag else None,
                "TARGET_IMAGE_REGISTRY": cfg.get("target_image_registry"),
                "DEBUG": cfg.get("DEBUG", cfg.get("debug", False)),
                "CONTINUE_ON_ERROR": cfg.get("CONTINUE_ON_ERROR", cfg.get("continue_on_error", False)),
                "UNTAR": untar_flag,
                "IMAGE_TAR_NAME": cfg.get("images_file_name"),
                "_CONFIG_DIR": os.path.dirname(os.path.abspath(values_file)),
                # --- NEW PATCH CONFIGURATION ---
                "PATCH": is_patch_mode,
                "PATCH_ITEMS": cfg.get("patch_items", {}),
                "UPDATE_IMAGE_REGISTRY": update_image_flag,
                "SKIP_TEMPLATES": _parse_bool_config(cfg.get("skip_templates", False), default=False),
                "LOAD_IMAGES": _parse_bool_config(cfg.get("load_images", False), default=False),
                "SKIP_PREFLIGHT": _parse_bool_config(cfg.get("skip_preflight", False), default=False),
            }
            config.update(CATALOG_SKU_DEFAULTS)
            config["urls"] = build_project_urls(project_name)

            if not config.get("API_KEY") or len(config["API_KEY"]) <= 6:
                print(f"Error: API_KEY seems to be missing or invalid. Got: {config.get('API_KEY')}")
                sys.exit(1)
            # When loading images, the target registry must not be a Rafay prod/dev registry
            # (images must be pushed to a local/custom registry, not the public Rafay one).
            if config.get("LOAD_IMAGES"):
                prod_registries = {"registry.rafay-edge.net"}
                target_reg = (config.get("TARGET_IMAGE_REGISTRY") or "").strip().rstrip("/").lower()
                if target_reg in prod_registries:
                    print(f"\033[31mError: load_images is true but target_image_registry is a Rafay registry ({target_reg}). Set target_image_registry to custom nexus registry.\033[0m")
                    sys.exit(1)


    except Exception as e:
        print(f"\033[31mFATAL ERROR reading values from {values_file}: {e}\033[0m")
        sys.exit(1)

def read_temp(values_file):
    try:
        if not os.path.isfile(values_file): return
        with open(values_file, "r") as f:
            data = yaml.safe_load(f)
            if not data: return

            sku_list = data.get("SKU", [])
            t, st, cp, sp, rt, cx, wh = [], [], [], [], [], [], []
            
            for sku in sku_list:
                if not isinstance(sku, dict): continue
                for _, sku_data in sku.items():
                    if not isinstance(sku_data, dict): continue
                    t.extend(sku_data.get("templates") or [])
                    st.extend(sku_data.get("shr-templates") or [])
                    cp.extend(sku_data.get("compute-profiles") or [])
                    sp.extend(sku_data.get("service-profiles") or [])
                    rt.extend(sku_data.get("res-templates") or [])
                    cx.extend(sku_data.get("context") or [])
                    wh.extend(sku_data.get("workflow-handlers") or [])
            
            image_tag_map = {path: str(cfg["tag"]) for path, cfg in data.get("images", {}).items() if "tag" in cfg}
            
            global config
            config.update ({
                "ORG_HASH": data.get("org_hash"),
                "LOAD_ALL_TEMPLATES": data.get("load_all_templates", False),
                "SHARING": data.get("sharing", False),
                "TEMPLATES": list(dict.fromkeys(t)),
                "SHRTEMPLATES": list(dict.fromkeys(st)),
                "VERSION": data.get("version", "v1"),
                "CPROFILES": list(dict.fromkeys(cp)),
                "SPROFILES": list(dict.fromkeys(sp)),
                "RESTEMPLATES": list(dict.fromkeys(rt)),
                "CONTEXTS": list(dict.fromkeys(cx)),
                "WRKFLW": list(dict.fromkeys(wh)),
                "IMAGE_TAG_MAP": image_tag_map
            })
    except Exception as e:
        handle_error(e, f"read_temp {values_file}", error_type="CONFIG_ERROR")


# ==========================================
# EXECUTION FLOW
# ==========================================

def load_default_org():
    try:
        response = make_v1_api("GET", config["urls"]["GET_ORGS_V1"], params=None, data=None)
        org_list, has_default_org, default_org_id = [], False, None

        while True:
            data = yaml.safe_load(response.content)
            for k in data["results"]:
                if k['active'] and k['approved'] and k['name'] not in ["RafayOperations", "RafayCommunity"]:
                    if k['is_default_org']:
                        has_default_org, default_org_id = True, k['id']
            if data['next'] == None: break
            response = make_v1_api("GET", data['next'], params=None, data=None)
            
        if has_default_org: org_list = [default_org_id]
        if len(org_list) != 1: raise RuntimeError(f"Default org not found. API key may be invalid.")
            
        for org_id in org_list:
            if org_id: load_for_org(org_id)
    except Exception as e:
        handle_error(e, "load_default_org", error_type="GLOBAL_ERROR")

def load_for_org(org_hash):
    global error_list
    error_list = [] 
    try:
        print(f"\n======= Loading templates for org {org_hash} =======")
        config["ORG_HASH"] = org_hash
        if config.get("PROJECT_NAME") == "default-catalog": create_project()

        # --- NEW LOGIC: Apply patch overrides if enabled ---
        if config.get("PATCH"):
            print(f"======= 🛠️ Running in PATCH mode (Selective Load) =======")
            # Disable broad loading behaviors
            config["LOAD_ALL_TEMPLATES"] = False
            config["LOAD_GLOBAL_SETTINGS"] = False
            config["CUSTOM_PROFILES"] = []
            
            # Map the explicitly requested patch_items
            patch_items = config.get("PATCH_ITEMS", {})
            config["CPROFILES"] = patch_items.get("compute-profiles", [])
            config["SPROFILES"] = patch_items.get("service-profiles", [])
            config["CONTEXTS"] = patch_items.get("context", [])
            config["TEMPLATES"] = patch_items.get("templates", [])
            config["RESTEMPLATES"] = patch_items.get("res-templates", [])
            config["WRKFLW"] = patch_items.get("workflow-handlers", [])
            config["SHRTEMPLATES"] = patch_items.get("shr-templates", [])
        
        entries = config.get("CUSTOM_PROFILES") or []
        enabled_entries = filter_enabled_custom_profiles(entries)

        if not config.get("SKIP_PREFLIGHT"):
            print(f"======= Phase 1: Checking Existing Sku's And Templates =======")
            config["CHECK_MODE"] = True
            config["existing_resources"] = []
            load_all_resources()

            if enabled_entries:
                system_project = config.get("SYSTEM_CATALOG_PROJECT", "system-catalog")
                catalog_project = config.get("CATALOG_PROJECT_NAME")
                set_project_context(system_project)
                for entry in enabled_entries:
                    path = entry.get("file")
                    if path and os.path.isfile(path): create_entity(path, load_mode="custom", profile_entry=entry)
                set_project_context(catalog_project)
            
            sys.stdout.write("\r\033[K")
            print(f"  ✓ Phase 1 Completed.\n")
        else:
            print("======= ⏩ Skipping Phase 1: Preflight Check =======")
        
        # Process collisions collected in Phase 1
        if config.get("existing_resources"):
            target_proj = str(config.get("PROJECT_NAME", "")).strip()
            project_groups = {}
            cross_project_conflicts = []
            
            for col in config['existing_resources']:
                actual_proj = str(col.get('actual_project') or target_proj).strip()
                intended_proj = str(col.get('intended_project') or target_proj).strip()
                
                col['actual_project'] = actual_proj
                col['intended_project'] = intended_proj
                
                # Compare where it IS vs where it is SUPPOSED to be
                if actual_proj != intended_proj: 
                    cross_project_conflicts.append(col)
                    
                if actual_proj not in project_groups: 
                    project_groups[actual_proj] = []
                project_groups[actual_proj].append(col)

            # Filter out duplicate Driver if WorkflowHandler with same name exists
            wfh_names = {x['name'] for x in config['existing_resources'] if x['kind'] == 'WorkflowHandler'}
            filtered_resources = [x for x in config['existing_resources'] if not (x['kind'] == 'Driver' and x['name'] in wfh_names)]

            print(f"\n===============================================================================================")
            print(f" ℹ️ PRE-FLIGHT INFO: {len(filtered_resources)} Existing Resource(s) Detected ")
            print(f"===============================================================================================")
            print(f" {'-RESOURCE TYPE-'.ljust(22)} {'-NAME-'.ljust(35)} {'-ORIGIN PROJECT-'}")
            print(f" {'-'*22} {'-'*35} {'-'*20}")
            
            # Define the exact sorting order requested
            kind_order = {
                "ConfigContext": 1,
                "WorkflowHandler": 2,
                "Driver": 2, # Treats standalone Drivers the same as WorkflowHandlers
                "ResourceTemplate": 3,
                "EnvironmentTemplate": 4,
                "ComputeProfile": 5,
                "ServiceProfile": 6
            }
            
            # Sort by the custom kind_order, then alphabetically by name
            grouped_resources = sorted(
                filtered_resources, 
                key=lambda x: (kind_order.get(x['kind'], 99), x['name'])
            )
            
            for col in grouped_resources:
                print(f" {col['kind'][:20].ljust(22)} {col['name'][:33].ljust(35)} {col['actual_project']}")
                
            print(f"===============================================================================================\n")

            if cross_project_conflicts and not (config.get("HARD_OVERRIDE") or config.get("OVERRIDE")):
                conflict_proj = cross_project_conflicts[0]["actual_project"]
                save_existing_to_values_yaml(conflict_proj, config["existing_resources"])
                print(f" ❌ Aborting Loading due to Cross-Project conflicts.")
                print(f" Please use --override to skip cross-project conflicts, or --hard-override to delete and load Sku's And Templates.\n")
                sys.exit(1)

            if config.get("HARD_OVERRIDE"):
                print(f" ⚠️ HARD OVERRIDE DETECTED: Executing delete-utility per project to wipe existing resources...\n")
                for proj, res_list in project_groups.items():
                    save_existing_to_values_yaml(proj, res_list)
                    try:
                        print(f"  -> Running delete-utility for project '{proj}'...")
                        subprocess.run([sys.executable, "./delete_utility/delete.py"], check=True)
                        print(f"  ✓ Resources in '{proj}' successfully deleted.\n")
                    except subprocess.CalledProcessError as e:
                        print(f"  ✗ Failed to execute delete-utility for '{proj}' (Exit code: {e.returncode}). Aborting.")
                        sys.exit(1)
                    except FileNotFoundError:
                        print(f"  ✗ delete.py not found in the current directory. Aborting.")
                        sys.exit(1)
            elif config.get("OVERRIDE"):
                print(f" ⚠️ OVERRIDE FLAG DETECTED: Cross-project resources will be SKIPPED, same-project resources will be OVERWRITTEN...\n")
            else:
                print(f" ⚠️ ALL EXISTING RESOURCES ARE IN THE TARGET PROJECT: Proceeding to safely overwrite them...\n")
                
        config["CHECK_MODE"] = False
        
        if not config.get("SKIP_TEMPLATES"):
            print(f"\n======= Phase 2: Executing Load & Update =======")
            load_all_resources()

            if enabled_entries:
                system_project = config.get("SYSTEM_CATALOG_PROJECT", "system-catalog")
                catalog_project = config.get("CATALOG_PROJECT_NAME")
                set_project_context(system_project)
                print(f"\n======= Phase 3: Loading custom profiles ({len(enabled_entries)}, project: {system_project}) =======")
                for entry in enabled_entries:
                    path = entry.get("file")
                    if path and os.path.isfile(path):
                        print(f"Custom profile --> {path}")
                        create_entity(path, load_mode="custom", profile_entry=entry)
                set_project_context(catalog_project)
        else:
            print("\n======= ⏩ Skipping Phase 2 & 3: Template Loading =======")

        # Apply Global Settings
        apply_global_settings()

        print(f"\n======= Completed loading templates for org {org_hash} =======")
        
        # Build the set of skipped / conflicting items (Base + Dependencies)
        failed_by_type = {}
        total_conflicts = 0

        # FIX: Only report skipped conflicts if we didn't just hard-delete them
        if not config.get("HARD_OVERRIDE"):
            # 1. Parse errors generated during Phase 2 (Base items skipped)
            for err in error_list:
                if err.get("type") == "CONFLICT":
                    context = err.get("context", "Unknown")
                    if "::" in context:
                        res_type, res_name = context.split("::", 1)
                    else:
                        res_type = "Other Operations"
                        res_name = context.replace("create_entity ", "").strip()
                        if "/" in res_name:
                            res_name = os.path.basename(res_name)
                            
                    proj = next((r["actual_project"] for r in config.get("existing_resources", []) if r["kind"] == res_type and r["name"] == res_name), "Unknown")
                    
                    if res_type not in failed_by_type: failed_by_type[res_type] = set()
                    item = (res_name, proj)
                    if item not in failed_by_type[res_type]:
                        failed_by_type[res_type].add(item)
                        total_conflicts += 1

            # 2. Add dependencies that cross boundaries (found in Phase 1).
            #    Only relevant when something actually failed or was skipped during
            #    Phase 2/3 — these cross-project resources are surfaced to explain the
            #    cascading failures. If everything loaded cleanly, there is nothing to
            #    resolve, so we skip this speculative scan entirely.
            had_load_failures = len(error_list) > 0
            loaded_custom = config.get("loaded_custom_profiles", set())
            if had_load_failures:
                for res in config.get("existing_resources", []):
                    if res.get("actual_project") and res.get("intended_project"):
                        if res["actual_project"] != res["intended_project"]:
                            res_type = res["kind"]
                            res_name = res["name"]
                            proj = res["actual_project"]

                            # Skip profiles we deliberately loaded into the system catalog
                            # in Phase 3 — those are not unresolved cross-project conflicts.
                            if (res_type, res_name) in loaded_custom:
                                continue

                            if res_type not in failed_by_type: failed_by_type[res_type] = set()
                            item = (res_name, proj)
                            if item not in failed_by_type[res_type]:
                                failed_by_type[res_type].add(item)
                                total_conflicts += 1

            # Only print the table if there are actual cross-project conflicts to resolve
            if total_conflicts > 0:
                print(f"\n\033[31mWARNING: {total_conflicts} template(s)/dependent(s) skipped due to cross-project conflicts:\033[0m")
                
                kind_order = {
                    "ConfigContext": 1,
                    "WorkflowHandler": 2,
                    "Driver": 2,
                    "ResourceTemplate": 3,
                    "EnvironmentTemplate": 4,
                    "ComputeProfile": 5,
                    "ServiceProfile": 6
                }
                
                # Sort the Resource Types by our custom order
                sorted_types = sorted(failed_by_type.keys(), key=lambda k: kind_order.get(k, 99))
                
                for res_type in sorted_types:
                    print(f"\n\033[36m  [{res_type}]\033[0m")
                    
                    # Sort alphabetically by template name
                    for res_name, proj in sorted(list(failed_by_type[res_type]), key=lambda x: x[0]):
                        print(f"\033[33m    {res_name} (Origin: {proj})\033[0m")
                        
                print("\n\033[36m💡 Suggestion: Please use the delete-utility in the specified project(s) to clean up conflicting resources.\033[0m\n")
        
        # Count the standard API failures (400, 502, etc.)
        api_errors = sum(1 for e in error_list if e.get("type") != "CONFLICT")
        if api_errors > 0:
            if total_conflicts > 0:
                print(f"\n\033[33mNote: {api_errors} other operation(s) failed with API errors. These are likely cascading failures caused because the {total_conflicts} conflicting templates skipped above were missing as dependencies. Resolving the conflicts should fix these automatically.\033[0m\n")
            else:
                print(f"\n\033[33mNote: {api_errors} operation(s) failed due to internal API errors.\033[0m\n")

    except SystemExit: raise
    except Exception as e: handle_error(e, f"load_for_org {org_hash}", error_type="GLOBAL_ERROR")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Rafay Template Loader")
    parser.add_argument("--override", action="store_true", help="Skip cross-project conflicts, overwrite same-project resources via POST.")
    parser.add_argument("--hard-override", action="store_true", help="Execute delete-utility to wipe existing resources before loading.")
    args, unknown = parser.parse_known_args()
    
    try:
        read_values(values_file="config.yaml")
        config["OVERRIDE"] = args.override
        config["HARD_OVERRIDE"] = args.hard_override
        
        if config["HARD_OVERRIDE"] and not os.path.isfile("./delete_utility/delete.py"):
            print("\n\033[31mFATAL ERROR: '--hard-override' requires 'delete-utility', but the file was not found in the current directory. Aborting.\033[0m")
            sys.exit(1)
        
        if os.path.exists("catalog-templates/rafay-cluster-images.tar.gz"):
            # Update to match team's hardcoded version if needed
            move_and_rename_file("catalog-templates/rafay-cluster-images.tar.gz", config["IMAGE_TAR_NAME"])
        untar("catalog-templates.tar.gz", ".")
        if config["FQDN"] is not None:
            if not config["IMAGE_TAR_NAME"]:
                print(f"Error: images_file_name seems to be missing. Got: {config['IMAGE_TAR_NAME']}")
                sys.exit(1)
            move_and_rename_file(config["IMAGE_TAR_NAME"], "catalog-templates/rafay-cluster-images.tar.gz")
            
        read_temp(values_file="catalog-templates/setup/values.yaml")
        print("")
        replace_img_fqdn()
        load_default_org()
        if config.get("LOAD_IMAGES"): load_images()
        else: print("======= ⏩ Skipping image loading =======")
        
    except SystemExit: sys.exit(1)
    except Exception as e:
        print(f"\n\033[31mFATAL ERROR: {e}\033[0m")
        import traceback
        traceback.print_exc()
        sys.exit(1)
