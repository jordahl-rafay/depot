## Changelog for v3.1.40 Release of Baseline SKU


### Tenant onboarding
* Added 'Router Host Details' to allow users to get router host details from the inventory

* 'Router Tags' variable is used to select the host for router containing the tags

* 'Router Virsh Pool Name' vyOS router now supports Libvirt storage pool on the NFV node that holds the router golden image

* 'Virsh Router Image Volume' - Source volume/image in that pool; cloned per deploy to {vm_name}-vd

* Router Virsh Pool Type - virsh = dir/FS pool (file copy); rbd = Ceph RBD (rbd cp). Default virsh

* Router QCOW2 Path - Local QCOW2 on the hypervisor; relative paths join Libvirt Image Folder

* Libvirt Image Folder - Base dir for disk files (default /var/lib/libvirt/images); hosts {vm_name}_boot.qcow2

	

### Node onboarding
* 


### VMaas VM onboarding
* Web Console support for VMs
* VM deployment logs exposed to environment
* Added contractterm as variable and billableparameters as extraconfig


### VMaas storage
* Added contractterm as a variable and modified billableparameters section

### VMaas firewall
*



### Netris
*


### BCM head node deploy
* 


### BMaaS - BCM
* Clean NVMe disk while deprovisioning Baremetal
* Enable/Disable public IP as part of Day2 operations
* Resource details in compute instance outputs
* Console access
* Modified memory, contract term variables and billable parameters
* Re Install OS on Baremetal
* Replace Instance in case of Hardware Failure
* User provided password support
* Handle concurrency to support multiple parallel BM provisioning
* Control over Node authentication to the end user to choose from password, SSH key or Both.
* Better management of GUIDs to eliminate potential security issues.
* Tags to IPAM for better tracking resource allocation.
 
### BMaaS - Non-bcm (Rafay native)
* Hyperfabric changes
* Console access
* Added contract term as variable and billable parameters as extraconfi

### SLURM
* Added contractterm as a variable and modified billableparameters section
* New BCM based SLURM Workflow handler
* Added Cluster topology deployments
* Integration of Firewall & Login-node SSH restrictor


### BCM install
*


### MKS OneClick
* Added contractterm as variable and billableparameters as extraconfig
* Two compute profile flows: cloud provisioning (v1) and pre-provisioned node OS (v2), each with distinct fields and visibility rules
* High Availability dropdown replaces separate `HA Enabled` boolean + `Master Nodes` count — options: Disabled (1 node), 3-Node HA, 5-Node HA, 7-Node HA; backend variable `master_node_count`
* Control Plane Node SKU dropdown (renamed from Master Node SKU): 8CPU|16GB RAM, 16CPU|32GB RAM, 32CPU|64GB RAM
* Worker Node Pool (renamed from Worker Node SKU): expanded JSON schema now includes GPU options H100, H200, L40S alongside CPU options; node count changed to open integer with minimum 0; added labels, annotations, taints per pool
* Platform Version dropdown: v0.1.0, v1.2.0, v1.3.0 (default v1.2.0)
* OIDC Configuration fields added: Enable OIDC Configuration, Service Account Issuer, API Audiences
* Enable Infiniband Configuration — true/false, backend variable `enable_infiniband`
* Firewall Rules — backend variable `firewall_rules`
* HSS Storage Configuration — backend variable `hss_storage_config`
* Object Storage Configuration — backend variable `object_storage_config`
* Control Plane Anti Affinity — boolean, default true
* Worker VM Batch Size — configurable parallel provisioning count, default 10
* Pre-provisioned flow (v2): added Control Plane Node Type, Worker Node Type, Worker Node Count fields for inventory-based node selection
* Kubernetes version default updated to v1.35.4; dropdown now covers v1.33.5–v1.36.0
* CNI Provider default updated to Calico 3.31.4; dropdown includes Calico, Cilium 1.19.1, Canal, CNI-via-Blueprint
* Fixed duplicate `RCTL_API_KEY` variable conflict at trigger time
* Fixed "Compute Profile Variable not found in template" error for Worker Node Count


### Pod as Service
* Added contractterm as a variable and modified billableparameters section


### Notebook as a Service
* Added contractterm as a variable and modified billableparameters section


### vLLm Inference as a Service
* Added contractterm as a variable and modified billableparameters section 
* Last feature we supported was Init Container


### Billing integration 
* Added a new ET push-paas-events to fetch the billing events for instances and making the events ready to be passed to the billing pipeline
* For ET push-paas-events: added RT res-push-paas-events and workflowhandler push-paas-events


### M360 integration
* Added 3 new ETs: system-process-paas-events, system-create-customer and system-extend-contract for the customers using M360 for billing
* For ET system-process-paas-events: added static resource res-placeholder and workflowhandler process-paas-event
* For ET system-extend-contract: added RT res-extend-contract and workflowhandler extend-contract
* For ET system-create-customer: added RT res-create-customer and workflowhandler create-customer


### bcm rack overview sync
* New 